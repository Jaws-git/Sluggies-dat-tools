import bpy
import functools
import os
import math
import struct
import traceback
import mathutils
from functools import lru_cache
from bpy.props import BoolProperty, StringProperty, CollectionProperty
from bpy_extras.io_utils import ImportHelper

from . import AnimScale
from . import AnmFormat
from . import BoneRoles
from . import CustomSubmeshImport
from . import StadiumCollisionExport
from . import FieldCodec
from . import HostBones
from . import ModelCheckCore
from . import SluggiePath


# Fallback tail length for a bone that gets no direction from the hierarchy,
# and the reference scale for clamping leaf-bone tails in build_armature.
LEAF_TAIL_FALLBACK = 0.05

# Reorient Bones: minimum length of a bone aimed at several children, and the
# armature-space direction for a bone whose children give it none (world -Y
# once the armature object's +90 deg X rotation is applied).
REORIENT_MIN_FORK_LENGTH = 0.15
REORIENT_FORWARD = mathutils.Vector((0.0, 0.0, 1.0))


def _game_srt_matrix(trans, quat, scale):
    """4x4 T @ R @ S from a game SRT; ``quat`` is the stored [-w, x, y, z].
    The quaternion is normalized first: an s16-quantized one is off unit
    length by up to 2e-4, which ``to_matrix`` would turn into a scale."""
    T = mathutils.Matrix.Translation(trans)
    R = mathutils.Quaternion((-quat[0], quat[1], quat[2], quat[3])).normalized().to_matrix().to_4x4()
    S = mathutils.Matrix.Diagonal((*scale, 1))
    return T @ R @ S


def game_rest_srt(bone):
    """(translation, stored quaternion [-w, x, y, z], scale) of *bone*'s game
    rest local. Imported bones carry it as game_* properties. An Add Bone bone
    has none: its rest is what the .sluggie export writes for it
    (ExportSluggies.encode_bone_hierarchy_edited), the Blender rest matrix
    relative to its parent's."""
    if bone.get('SluggiesUserAdded') and bone.parent is not None:
        t, r, s = (bone.parent.matrix_local.inverted() @ bone.matrix_local).decompose()
        return list(t), [-r.w, r.x, r.y, r.z], list(s)
    return (list(bone.get('game_translation', (0, 0, 0))),
            list(bone.get('game_quaternion', (-1, 0, 0, 0))),
            list(bone.get('game_scale', (1, 1, 1))))


def _anm_bone_corrections(arm_data):
    """{bone name: C} with C = inverse(game rest world) @ Blender rest matrix.

    Only for armatures imported with "Reorient Bones" on: build_armature aims
    each bone's tail at its children, so a Blender bone's axes differ from
    the game bone's. ANM keyframes are game locals; posing bone i to (game
    animated world) @ C_i deforms the mesh as the game does and leaves the
    rest pose untouched (the importer applies
    inverse(E_local) @ inverse(C_parent) @ L_anm @ C_bone).

    Game rest worlds come from the game_* bone properties and the parent chain
    (HeadPosition matches their translations). A bone with
    SluggiesInheritTransform off has no game parent; its animation still
    follows its Blender parent here (no stock model has such a child bone).
    """
    game_world = {}

    def world_of(bone):
        if bone.name not in game_world:
            local = _game_srt_matrix(*game_rest_srt(bone))
            if bone.parent is not None and bone.get('SluggiesInheritTransform', True):
                local = world_of(bone.parent) @ local
            game_world[bone.name] = local
        return game_world[bone.name]

    corrections = {}
    for bone in arm_data.bones:
        world = world_of(bone)
        # A collapsed (zero-scale) rest bone has no inverse: skip its correction.
        corrections[bone.name] = (world.inverted() @ bone.matrix_local
                                  if abs(world.determinant()) > 1e-12 else mathutils.Matrix.Identity(4))
    return corrections


def _to_bytes(data) -> bytes:
    """Decode a binary field: ``x:`` hex string (legacy: base64 or ``z:`` zlib) or a list of byte values."""
    return FieldCodec.decode_field(data)


def _texture_file_map(texture_descriptors):
    """Return {TextureIndex: filename} from sluggie metadata.

    Falls back to the legacy numeric file name when TextureFileName is absent.
    """
    mapping = {}
    for tex in texture_descriptors or []:
        tex_idx = tex.get("TextureIndex")
        if tex_idx is None:
            continue
        mapping[tex_idx] = tex.get("TextureFileName") or f"{tex_idx}.png"
    return mapping


def _assigned_surface_texture_files(model, texture_file_map):
    """{SurfaceId: PNG name} of the exported ``DesiredTextureAssignments``.

    An index below the donor descriptor count names a donor texture; a higher
    one an ``AdditionalTextureDescriptors`` entry (appended in that order by
    the export). The surface material then shows that PNG, so a re-import
    followed by an export assigns it again instead of dropping it."""
    assignments = model.get("DesiredTextureAssignments") or {}
    if not assignments:
        return {}
    donor_count = len(model.get("TextureDescriptors") or [])
    additions = model.get("AdditionalTextureDescriptors") or []
    files = {}
    for surface_id, index in assignments.items():
        try:
            index = int(index)
        except (TypeError, ValueError):
            continue
        if index < donor_count:
            name = (texture_file_map or {}).get(index)
        elif index - donor_count < len(additions):
            name = additions[index - donor_count].get("TextureFileName")
        else:
            name = None
        if name:
            files[str(surface_id)] = name
    return files


def _texture_file_map_from_sibling_sluggie(current_sluggie_path, model):
    """Return a fallback texture file map from a sibling .sluggie when needed.

    Some lowpoly (_L) exports have no local TextureDescriptors, but their sibling
    export folder still has the canonical hashed TextureFileName mapping.
    """
    current_dir = os.path.dirname(current_sluggie_path)
    parent_dir = os.path.dirname(current_dir)
    if not parent_dir or not os.path.isdir(parent_dir):
        return {}

    target_chunk = model.get("ChunkNumber")
    target_submesh_count = len(model.get("Submeshes", []))

    candidates = []
    for sibling_name in sorted(os.listdir(parent_dir)):
        sibling_dir = os.path.join(parent_dir, sibling_name)
        if not os.path.isdir(sibling_dir) or sibling_dir == current_dir:
            continue
        try:
            sluggies = [
                name for name in os.listdir(sibling_dir)
                if name.lower().endswith('.sluggie')
            ]
        except OSError:
            continue
        for slug_name in sluggies:
            candidates.append(os.path.join(sibling_dir, slug_name))

    # Variants saved under new names tie on the score below; the file named
    # like this one (else the exported one) wins the tie.
    partner = ModelCheckCore.pick_partner(candidates, current_sluggie_path)
    best_map = {}
    best_score = -1
    for candidate_path in candidates:
        try:
            candidate_root = FieldCodec.load_sluggie(candidate_path)
        except (OSError, ValueError):
            continue
        candidate_model = candidate_root.get("SluggiesModel", {})
        candidate_desc = candidate_model.get("TextureDescriptors", [])
        candidate_map = _texture_file_map(candidate_desc)
        if not candidate_map:
            continue

        score = 0
        if candidate_model.get("ChunkNumber") == target_chunk:
            score += 4
        if len(candidate_model.get("Submeshes", [])) >= target_submesh_count:
            score += 2
        if candidate_model.get("TEXHeader"):
            score += 1
        if candidate_path == partner:
            score += 0.5
        if score > best_score:
            best_score = score
            best_map = candidate_map

    return best_map


def _compute_bone_absolute_matrices(bone_list):
    """Return a {BoneId: mathutils.Matrix} dict of absolute world-space transforms.

    For non-skinned submeshes the game stores vertices in bone-local space and
    applies bone.absolute_transform (= S@R@T accumulated up the parent chain in
    row-vector convention) as a bind-shape matrix to map them to world space.
    We replicate that here in Blender column-vector convention:
      game row-vector:   local = S_row @ R_row @ T_row
      Blender col-vector: local = T_col @ R_col @ S_col  (reversed order)
      absolute_blender = parent_abs_blender @ child_local_blender
    """
    bone_map = {b['BoneId']: b for b in bone_list}
    abs_mats = {}  # BoneId -> mathutils.Matrix

    # Topological pass: resolve parents before children.  Guard against cycles.
    remaining = list(bone_map.keys())
    for _ in range(len(remaining) + 1):
        still_remaining = []
        for bone_id in remaining:
            bone     = bone_map[bone_id]
            parent_id = bone.get('ParentBoneId')
            if parent_id is not None and parent_id not in abs_mats:
                still_remaining.append(bone_id)
                continue
            trans = bone['Translation']
            scale = bone['Scale']
            quat  = bone['Quaternion']   # stored as [-game_qw, game_qx, game_qy, game_qz]
            T = mathutils.Matrix.Translation(trans)
            # Negate w to recover game_qw; the stored negation was an artefact of the
            # row-vector SRT convention.  With correct w, to_matrix() gives R_col.
            R = mathutils.Quaternion((-quat[0], quat[1], quat[2], quat[3])).to_matrix().to_4x4()
            S = mathutils.Matrix([
                [scale[0], 0,       0,       0],
                [0,        scale[1], 0,      0],
                [0,        0,       scale[2], 0],
                [0,        0,       0,        1],
            ])
            local_mat = T @ R @ S
            if parent_id is not None:
                abs_mats[bone_id] = abs_mats[parent_id] @ local_mat
            else:
                abs_mats[bone_id] = local_mat
        remaining = still_remaining
        if not remaining:
            break

    return abs_mats


GEO_ID_FREE = 0xFFFF


def _submesh_owner_bones(bone_list, submesh_index):
    """``(donor owner, effective owner)`` bone ids of a rigid submesh: the
    bone whose donor ``GeoId`` is the submesh, and the bone that owns it after
    the file's ``GeoIdEdited`` retargets (the same bone when there are none).
    Both are None for a skinned submesh."""
    donor = next(
        (int(bd['BoneId']) for bd in bone_list
         if not bd.get('Skinned') and bd.get('GeoId') == submesh_index),
        None,
    )
    edited = next(
        (int(bd['BoneId']) for bd in bone_list
         if bd.get('GeoIdEdited') is not None and int(bd['GeoIdEdited']) == submesh_index),
        None,
    )
    return donor, donor if edited is None else edited


def _apply_nonskinned_transform(obj, submesh_index, bone_list, abs_bone_mats, owner_bone_id=None):
    """Set *obj*.matrix_world to the absolute transform of the non-skinned bone
    that owns *submesh_index*, if one exists.  No-op for skinned submeshes.

    *owner_bone_id* names the bone to use; by default the effective owner
    (``GeoIdEdited`` first), so a retargeted mesh re-imports on its new bone."""
    if owner_bone_id is None:
        _donor, owner_bone_id = _submesh_owner_bones(bone_list, submesh_index)
    if owner_bone_id is None:
        return
    mat = abs_bone_mats.get(owner_bone_id)
    if mat is None:
        return
    if obj.parent is not None:
        # Relative to the armature, which carries the 90 degree import
        # rotation. Setting matrix_world instead depended on the armature's
        # world matrix not being evaluated yet: re-creating Add Bone bones
        # (an Edit Mode round trip) evaluated it first, and every mesh came
        # out without the rotation (2026-10-18).
        obj.matrix_parent_inverse = mathutils.Matrix.Identity(4)
        obj.matrix_basis = mat
    else:
        obj.matrix_world = mat


def decode_faces(submesh):
    """Decode encoded uint16 BE face data back to a list of [i,j,k] triplets."""
    faces_data = submesh.get("FacesData")
    face_count = submesh.get("FacesCount", 0)
    if not faces_data or not face_count:
        return []
    raw = _to_bytes(faces_data)
    flat = list(struct.unpack(f'>{face_count * 3}H', raw))
    return [flat[i*3:i*3+3] for i in range(face_count)]


def decode_vertex_buffer(vb):
    """Decode a VertexBuffer dict into (positions, normals) lists of tuples.

    For skinned meshes CompCount==6 the raw buffer interleaves [X,Y,Z,NX,NY,NZ]
    per vertex. For non-skinned meshes CompCount==3 only [X,Y,Z] is stored.
    Returns normals as an empty list when CompCount < 6.
    """
    raw = _to_bytes(vb["VertexBufferData"])
    quant = vb["VertexBufferQuantizeInfo"]
    comp_count = vb["VertexBufferCompCount"]
    fmt_nibble = quant >> 4
    divisor = 1 << (quant & 0xF)

    if fmt_nibble in [4, 7, 0xa]:
        comp_fmt, comp_size = '>f', 4
    else:  # 0, 3 -> signed int16
        comp_fmt, comp_size = '>h', 2

    stride = comp_count * comp_size
    num_verts = len(raw) // stride

    flat = _unpack_components(raw, num_verts, comp_count, comp_fmt, comp_size)
    starts = range(0, len(flat), comp_count)
    positions = [(flat[o] / divisor, flat[o + 1] / divisor, flat[o + 2] / divisor) for o in starts]
    normals = []
    if comp_count >= 6:
        normals = [(flat[o + 3] / divisor, flat[o + 4] / divisor, flat[o + 5] / divisor) for o in starts]

    return positions, normals


def _unpack_components(raw, records, comp_count, comp_fmt, comp_size, minimum=3):
    """The first *records* records of *raw* as one flat tuple of components
    (one ``struct.unpack`` for the buffer, not one call per component)."""
    if records and comp_count < minimum:
        raise IndexError(f'{comp_count} components per record, at least {minimum} expected')
    count = records * comp_count
    return struct.unpack(f'>{count}{comp_fmt[-1]}', raw[:count * comp_size])


def decode_normal_buffer(normal_buffer):
    """Decode a NormalBuffer dict (non-skinned standalone normal array) into a
    list of (nx, ny, nz) float tuples.

    Same quantization rules as the interleaved CompCount==6 vertex normals:
    high nibble picks float vs signed int16, low nibble is the right-shift
    exponent of the divisor.
    """
    raw = _to_bytes(normal_buffer["NormalBufferData"])
    quant = normal_buffer.get("NormalBufferQuantizeInfo", 0)
    comp_count = normal_buffer.get("NormalBufferCompCount", 3)
    fmt_nibble = quant >> 4
    divisor = 1 << (quant & 0xF)

    if fmt_nibble in [4, 7, 0xa]:
        comp_fmt, comp_size = '>f', 4
    else:  # 0, 3 -> signed int16
        comp_fmt, comp_size = '>h', 2

    stride = comp_count * comp_size
    num_normals = len(raw) // stride

    flat = _unpack_components(raw, num_normals, comp_count, comp_fmt, comp_size)
    return [(flat[o] / divisor, flat[o + 1] / divisor, flat[o + 2] / divisor)
            for o in range(0, len(flat), comp_count)]


def _facial_vertex_indices(attribute):
    indices = []
    for run in attribute.get("Runs", []):
        first = run.get("FirstVertex", 0)
        count = run.get("VertexCount", 0)
        indices.extend(range(first, first + count))
    return indices


def _decode_facial_pose(data, quant_info, component_count=3, component_size=2):
    """Decode one facial XYZ array using its matched GPL position quantization."""
    raw = _to_bytes(data)
    if component_size != 2 or component_count < 3:
        return []
    divisor = 1 << (quant_info & 0xF)
    stride = component_count * component_size
    return [
        tuple(struct.unpack_from('>3h', raw, offset)[axis] / divisor for axis in range(3))
        for offset in range(0, len(raw), stride)
    ]


def _facial_edit_lookup(facial_edited):
    lookup = {}
    for facial_object in (facial_edited or {}).get("Objects", []):
        object_index = facial_object.get("ObjectIndex")
        for pose_edit in facial_object.get("PositionPoseEdits", []):
            lookup[(object_index, pose_edit.get("PoseIndex"))] = pose_edit.get("PoseData")
    return lookup


def _decode_rebuild_facial_poses(rebuild_poses, quant_info, record_stride=12):
    """``SkinnedRebuild.FacialPoses`` (12-byte ``x y z nx ny nz`` records) or
    ``RigidRebuild.FacialPoses`` (6-byte ``x y z`` records) ->
    ``[(object_index, [[(vertex, (dx, dy, dz)), ...] per pose after pose
    zero])]``, deltas in the rebuild's vertex order and position format
    (the body's normal components are dropped; a rigid entry's normal
    lists are not read, Blender derives shape-key normals itself)."""
    divisor = 1 << (quant_info & 0xF)
    result = []
    for entry in rebuild_poses or []:
        raw = _to_bytes(entry.get("Vertices")) if entry.get("Vertices") else b""
        vertices = [value for (value,) in struct.iter_unpack('>H', raw)]
        poses = []
        for delta in entry.get("PoseDeltas") or []:
            raw_delta = _to_bytes(delta)
            if len(raw_delta) != len(vertices) * record_stride:
                poses.append([])
                continue
            poses.append([
                (vertex, tuple(struct.unpack_from('>3h', raw_delta, k * record_stride)[axis] / divisor for axis in range(3)))
                for k, vertex in enumerate(vertices)
            ])
        result.append((entry.get("ObjectIndex"), poses))
    return result


def _add_rebuild_facial_shape_keys(obj, rebuild_poses, record_stride=12):
    """Shape keys of a rebuilt submesh (``SkinnedRebuild.FacialPoses`` or
    ``RigidRebuild.FacialPoses``): the donor's run lists name donor
    vertices, so the keys come from the rebuild's own deltas, in its vertex
    order."""
    decoded = _decode_rebuild_facial_poses(rebuild_poses, obj.get("VertexBufferQuantizeInfo", 0), record_stride)
    if not any(poses for _object_index, poses in decoded):
        return 0
    basis_key = obj.shape_key_add(name="Basis", from_mix=False)
    shape_key_count = 0
    for object_index, poses in decoded:
        for pose_index, entries in enumerate(poses, start=1):
            key = obj.shape_key_add(name=f"facial_object_{object_index}_pose_{pose_index}", from_mix=False)
            key.value = 0.0
            for vertex_index, delta in entries:
                if vertex_index < len(key.data):
                    basis = basis_key.data[vertex_index].co
                    key.data[vertex_index].co = tuple(basis[axis] + delta[axis] for axis in range(3))
            shape_key_count += 1
    return shape_key_count


def add_facial_shape_keys(obj, submesh_index, facial_data, facial_edited=None, rebuild_poses=None,
                          rebuild_record_stride=12):
    """Add facial expression keys; Blender Basis represents pose zero.
    *rebuild_poses* (a rebuild's ``FacialPoses``, possibly empty) replaces
    the donor's poses on a rebuilt submesh, whose vertices the donor run
    lists no longer describe; *rebuild_record_stride* is 12 for the body's
    interleaved records and 6 for a rigid submesh's."""
    if rebuild_poses is not None:
        return _add_rebuild_facial_shape_keys(obj, rebuild_poses, rebuild_record_stride)
    if not facial_data:
        return 0
    facial_objects = [
        entry for entry in facial_data.get("Objects", [])
        if entry.get("SubmeshIndex") == submesh_index
    ]
    if not facial_objects:
        return 0

    expression_objects = [
        facial_object for facial_object in facial_objects
        if facial_object.get("PoseCount", facial_data.get("PoseCount", 0)) > 1
    ]
    if not expression_objects:
        return 0
    quant_info = obj.get("VertexBufferQuantizeInfo", 0)
    edited_lookup = _facial_edit_lookup(facial_edited)
    basis_key = obj.shape_key_add(name="Basis", from_mix=False)

    for facial_object in facial_objects:
        object_index = facial_object.get("ObjectIndex")
        position = facial_object.get("Position", {})
        pose_zero_edit = edited_lookup.get((object_index, 0))
        if pose_zero_edit is None:
            continue
        indices = _facial_vertex_indices(position)
        coordinates = _decode_facial_pose(
            pose_zero_edit, quant_info,
            position.get("ComponentCount", 3),
            position.get("ComponentSize", 2),
        )
        if len(indices) != len(coordinates):
            continue
        for vertex_index, coordinate in zip(indices, coordinates):
            if vertex_index < len(basis_key.data):
                basis_key.data[vertex_index].co = coordinate
                # The mesh's own vertices too, so Basis and the mesh agree in Object Mode.
                obj.data.vertices[vertex_index].co = coordinate

    shape_key_count = 0
    for facial_object in expression_objects:
        object_index = facial_object.get("ObjectIndex")
        position = facial_object.get("Position", {})
        indices = _facial_vertex_indices(position)
        original_poses = position.get("PoseData", [])
        pose_count = facial_object.get("PoseCount", facial_data.get("PoseCount", 0))
        for pose_index in range(1, pose_count):
            key = obj.shape_key_add(
                name=f"facial_object_{object_index}_pose_{pose_index}",
                from_mix=False,
            )
            key.value = 0.0
            position = facial_object.get("Position", {})
            pose_data = edited_lookup.get(
                (object_index, pose_index),
                original_poses[pose_index] if pose_index < len(original_poses) else None,
            )
            if pose_data is None:
                continue
            coordinates = _decode_facial_pose(
                pose_data, quant_info,
                position.get("ComponentCount", 3),
                position.get("ComponentSize", 2),
            )
            if len(indices) != len(coordinates):
                continue
            for vertex_index, coordinate in zip(indices, coordinates):
                if vertex_index < len(key.data):
                    basis = basis_key.data[vertex_index].co
                    key.data[vertex_index].co = tuple(
                        basis[axis] + coordinate[axis] for axis in range(3)
                    )
            shape_key_count += 1

    return shape_key_count


def decode_uv_channel(uv_channel):
    """Decode a UVChannel dict into:
    - coords: list of (s, t) float tuples decoded from the raw ST buffer
    - uv_faces: list of [i0, i1, i2] UV index triplets, aligned face-for-face with FacesData
    """
    raw = _to_bytes(uv_channel["UVChannelData"])
    quant = uv_channel["UVChannelQuantizeInfo"]
    comp_count = uv_channel["UVChannelCompCount"]
    fmt_nibble = quant >> 4
    divisor = 1 << (quant & 0xF)

    if fmt_nibble in [4, 7, 0xa]:
        comp_fmt, comp_size = '>f', 4
    else:  # 0, 3 -> signed int16
        comp_fmt, comp_size = '>h', 2

    stride = comp_count * comp_size
    num_coords = len(raw) // stride

    flat = _unpack_components(raw, num_coords, comp_count, comp_fmt, comp_size, minimum=2)
    coords = [(flat[o] / divisor, flat[o + 1] / divisor) for o in range(0, len(flat), comp_count)]

    # Decode per-face UV indices (uint16 BE triplets, same encoding as FacesData)
    uv_faces = []
    uv_faces_data = uv_channel.get("UVFacesData")
    if uv_faces_data:
        uv_raw = _to_bytes(uv_faces_data)
        n = len(uv_raw) // 2
        flat = list(struct.unpack(f'>{n}H', uv_raw))
        uv_faces = [flat[i * 3 : i * 3 + 3] for i in range(n // 3)]

    return coords, uv_faces


def _set_loop_color(entry, rgba):
    """Write one donor color into a BYTE_COLOR attribute without a curve change.

    The donor entries are raw normalized channel values, not scene-linear ones.
    ``entry.color`` applies an sRGB<->linear conversion on top of the 8-bit
    storage, which is not reversible: 73 of the 256 byte values come back from
    the export accessor shifted by one. ``color_srgb`` maps straight onto the
    stored bytes, so an untouched color attribute re-exports byte-for-byte.
    Mirrors ``_get_loop_color`` in ExportSluggies.
    """
    try:
        entry.color_srgb = rgba
    except AttributeError:
        entry.color = rgba


def decode_color_channel(color_channel):
    """Decode a ColorChannel dict into a list of (r, g, b[, a]) float tuples and
    a list of [i0, i1, i2] color index triplets aligned face-for-face with FacesData."""
    raw = _to_bytes(color_channel["ColorChannelData"])
    quant = color_channel["ColorChannelQuantizeInfo"]
    fmt = quant >> 4
    entry_sizes = {0: 2, 1: 3, 2: 4, 3: 2, 4: 3, 5: 4}
    entry_size = entry_sizes.get(fmt, 2)
    num_colors = len(raw) // entry_size

    colors = []
    for i in range(num_colors):
        num = int.from_bytes(raw[i * entry_size : i * entry_size + entry_size], 'big')
        if fmt == 0:  # RGB565
            b = (num & 0b11111) / 31.0
            g = ((num >> 5) & 0b111111) / 63.0
            r = ((num >> 11) & 0b11111) / 31.0
            colors.append((r, g, b, 1.0))
        elif fmt == 3:  # RGBA4444
            a = (num & 0xF) / 15.0
            b = ((num >> 4) & 0xF) / 15.0
            g = ((num >> 8) & 0xF) / 15.0
            r = ((num >> 12) & 0xF) / 15.0
            colors.append((r, g, b, a))
        elif fmt in (1, 4):  # RGB8
            r = ((num >> 16) & 0xFF) / 255.0
            g = ((num >> 8) & 0xFF) / 255.0
            b = (num & 0xFF) / 255.0
            colors.append((r, g, b, 1.0))
        elif fmt in (2, 5):  # RGBA8
            r = ((num >> 24) & 0xFF) / 255.0
            g = ((num >> 16) & 0xFF) / 255.0
            b = ((num >> 8) & 0xFF) / 255.0
            a = (num & 0xFF) / 255.0
            colors.append((r, g, b, a))
        else:
            colors.append((1.0, 1.0, 1.0, 1.0))

    color_faces = []
    faces_data = color_channel.get("ColorFacesData")
    if faces_data:
        cf_raw = _to_bytes(faces_data)
        n = len(cf_raw) // 2
        flat = list(struct.unpack(f'>{n}H', cf_raw))
        color_faces = [flat[i * 3 : i * 3 + 3] for i in range(n // 3)]

    return colors, color_faces


def decode_face_texture_indices(submesh, face_count):
    """Decode FaceTextureIndices into a list of int texture indices, one per face.

    Falls back to the TextureIndex of the first UV channel when the field is
    absent (e.g. files produced before this field was added).
    """
    data = submesh.get("FaceTextureIndices")
    if data:
        raw = _to_bytes(data)
        n = len(raw) // 2
        return list(struct.unpack(f'>{n}H', raw))
    fallback = (submesh.get("UVChannels") or [{}])[0].get("TextureIndex") or 0
    return [fallback] * face_count


def _has_edited_data(submesh):
    """Return True when *submesh* contains any edited mesh data."""
    vb = submesh.get("VertexBuffer") or {}
    normal_buffer = submesh.get("NormalBuffer")
    return bool(
        vb.get("VertexBufferDataEdited") or submesh.get("FacesDataEdited")
        or submesh.get("RigidRebuild") or submesh.get("SkinnedRebuild")
        or submesh.get("FaceSurfaceIdsEdited")
        or any(ch.get("UVChannelDataEdited") for ch in submesh.get("UVChannels") or [])
        or any(ch.get("ColorChannelDataEdited") for ch in submesh.get("ColorChannels") or [])
        or (isinstance(normal_buffer, dict) and normal_buffer.get("NormalBufferDataEdited"))
    )


_INPLACE_SKIN_EDIT_KEYS = ("BindPoseDataEdited", "WeightDataEdited", "VertexCntEdited",
                           "BoneIndexEdited", "DestIndexDataEdited")


def _submesh_vertex_ranges(model):
    """``[(global start, vertex count)]`` per submesh: the skinned position
    slots run on across the submeshes (as in the exporter's skin encoders)."""
    ranges, start = [], 0
    for submesh in model.get("Submeshes") or []:
        vb = submesh.get("VertexBuffer") or {}
        comp = 4 if (int(vb.get("VertexBufferQuantizeInfo", 0)) >> 4) in (4, 7, 0xa) else 2
        stride = int(vb.get("VertexBufferCompCount") or 3) * comp
        count = int(vb.get("VertexBufferLength") or 0) // stride if stride else 0
        ranges.append((start, count))
        start += count
    return ranges


def _skin_bytes(entry, key, edited):
    value = (entry.get(key + "Edited") if edited else None) or entry.get(key)
    return _to_bytes(value) if value else b""


def _decode_skin_totals(skin, edited):
    """``{global vertex: {bone: raw weight}}`` of a SkinData dict, the way
    the core parser sums SK1 (256), SK2 and SKAcc contributions. *edited*
    reads the in-place ``*Edited`` fields where present."""
    vs = 6 * (4 if (int(skin.get("QuantizeInfo", 0)) >> 4) in (4, 7, 0xa) else 2)
    totals = {}

    def add(bone, vertex, raw):
        slot = totals.setdefault(vertex, {})
        slot[bone] = slot.get(bone, 0) + raw

    def count(entry):
        if edited and entry.get("VertexCntEdited") is not None:
            return int(entry["VertexCntEdited"])
        return int(entry["VertexCnt"])

    for entry in skin.get("SK1s") or []:
        bone = entry.get("BoneIndexEdited") if edited and entry.get("BoneIndexEdited") is not None else entry["BoneIndex"]
        start = (int(entry.get("GplVertexArrValue", 0)) + int(entry.get("VertexOffset", 0))) // vs
        for i in range(count(entry)):
            add(int(bone), start + i, 256)
    for entry in skin.get("SK2s") or []:
        start = (int(entry.get("GplVertexArrValue", 0)) + int(entry.get("VertexOffset", 0))) // vs
        weights = _skin_bytes(entry, "WeightData", edited)
        for i in range(min(count(entry), len(weights) // 2)):
            add(int(entry["BoneIndex1"]), start + i, weights[2 * i])
            add(int(entry["BoneIndex2"]), start + i, weights[2 * i + 1])
    for entry in skin.get("SKAccs") or []:
        base = int(entry.get("GplDestArrValue", 0)) // vs
        weights = _skin_bytes(entry, "WeightData", edited)
        dests_raw = _skin_bytes(entry, "DestIndexData", edited)
        dests = struct.unpack(f'>{len(dests_raw) // 2}H', dests_raw[:len(dests_raw) // 2 * 2])
        for i in range(min(count(entry), len(weights), len(dests))):
            add(int(entry["BoneIndex"]), base + dests[i], weights[i])
    return totals


def _decode_model_skin_edit(edited, skin, ranges):
    """``{global vertex: {bone: raw weight}}`` of a model-level
    ``SkinDataEdited``, or None when it cannot be placed. Its entries name
    each member by its index inside its submesh (``VertexIndices``; SKAcc:
    ``DestIndexData``). The encoder keeps the donor's bone sets and groups
    the members by their donor entry (SK1: bone and GplVertexArrValue, SK2:
    bone pair and GplVertexArrValue, SKAcc: bone), so each index is placed
    among the slots of that donor entry."""
    if edited.get("MembershipEdited"):
        return None
    vs = 6 * (4 if (int(skin.get("QuantizeInfo", 0)) >> 4) in (4, 7, 0xa) else 2)

    def local_map(slots):
        mapping = {}
        for vertex in slots:
            for start, n in ranges:
                if start <= vertex < start + n:
                    if vertex - start in mapping:
                        raise LookupError("ambiguous vertex index")
                    mapping[vertex - start] = vertex
                    break
        return mapping

    def run_slots(entries):
        slots = set()
        for entry in entries:
            start = (int(entry.get("GplVertexArrValue", 0)) + int(entry.get("VertexOffset", 0))) // vs
            slots.update(range(start, start + int(entry["VertexCnt"])))
        return slots

    def indices(entry, key):
        raw = _to_bytes(entry.get(key)) if entry.get(key) else b""
        return struct.unpack(f'>{len(raw) // 2}H', raw[:len(raw) // 2 * 2])

    totals = {}

    def add(mapping, bone, local, raw):
        vertex = mapping[local]                    # KeyError: not a slot of the donor entry
        slot = totals.setdefault(vertex, {})
        slot[bone] = slot.get(bone, 0) + raw

    try:
        for entry in edited.get("SK1s") or []:
            bone, gpl = int(entry["BoneIndex"]), int(entry.get("GplVertexArrValue", 0))
            donors = [e for e in skin.get("SK1s") or []
                      if int(e["BoneIndex"]) == bone and int(e.get("GplVertexArrValue", 0)) == gpl]
            if not donors:
                return None
            mapping = local_map(run_slots(donors))
            for local in indices(entry, "VertexIndices"):
                add(mapping, bone, local, 256)
        for entry in edited.get("SK2s") or []:
            pair = {int(entry["BoneIndex1"]), int(entry["BoneIndex2"])}
            gpl = int(entry.get("GplVertexArrValue", 0))
            donors = [e for e in skin.get("SK2s") or []
                      if {int(e["BoneIndex1"]), int(e["BoneIndex2"])} == pair
                      and int(e.get("GplVertexArrValue", 0)) == gpl]
            if not donors:
                return None
            mapping = local_map(run_slots(donors))
            weights = _to_bytes(entry.get("WeightData")) if entry.get("WeightData") else b""
            for i, local in enumerate(indices(entry, "VertexIndices")):
                add(mapping, int(entry["BoneIndex1"]), local, weights[2 * i])
                add(mapping, int(entry["BoneIndex2"]), local, weights[2 * i + 1])
        for entry in edited.get("SKAccs") or []:
            bone = int(entry["BoneIndex"])
            slots = set()
            for donor in skin.get("SKAccs") or []:
                if int(donor["BoneIndex"]) == bone:
                    base = int(donor.get("GplDestArrValue", 0)) // vs
                    slots.update(base + d for d in indices(donor, "DestIndexData"))
            if not slots:
                return None
            mapping = local_map(slots)
            weights = _to_bytes(entry.get("WeightData")) if entry.get("WeightData") else b""
            for i, local in enumerate(indices(entry, "DestIndexData")):
                add(mapping, bone, local, weights[i])
    except (LookupError, ValueError, struct.error):
        return None
    return totals


def _edited_skin_influences(model):
    """``({submesh: [(vertex, bone, weight)]}, skinned bone ids)`` of the
    skinned bones as the file's skin edits leave them (in-place ``*Edited``
    SK fields, or a model-level ``SkinDataEdited``); None when the file has
    no skin edit or it cannot be decoded. Weights are raw / 256, as in the
    core parser's ``VertexInfluences``."""
    skin = model.get("SkinData") or {}
    model_edit = model.get("SkinDataEdited")
    inplace = any(key in entry for name in ("SK1s", "SK2s", "SKAccs")
                  for entry in skin.get(name) or [] for key in _INPLACE_SKIN_EDIT_KEYS)
    if not skin or not (inplace or model_edit):
        return None
    ranges = _submesh_vertex_ranges(model)
    try:
        if model_edit:
            totals = _decode_model_skin_edit(model_edit, skin, ranges)
            if totals is None:
                print("WARNING: SkinDataEdited could not be mapped to vertices; "
                      "the _edit objects show the donor skin weights")
                return None
        else:
            totals = _decode_skin_totals(skin, True)
    except (KeyError, ValueError, struct.error) as exc:
        print(f"WARNING: skin edits could not be decoded ({exc}); "
              "the _edit objects show the donor skin weights")
        return None
    skinned = {int(e["BoneIndex"]) for e in skin.get("SK1s") or []}
    skinned |= {int(e[k]) for e in skin.get("SK2s") or [] for k in ("BoneIndex1", "BoneIndex2")}
    skinned |= {int(e["BoneIndex"]) for e in skin.get("SKAccs") or []}
    skinned |= {bone for bones in totals.values() for bone in bones}
    per_submesh = {}
    for vertex, bones in sorted(totals.items()):
        for index, (start, n) in enumerate(ranges):
            if start <= vertex < start + n:
                per_submesh.setdefault(index, []).extend(
                    (vertex - start, bone, raw / 256.0) for bone, raw in sorted(bones.items()) if raw > 0)
                break
    return per_submesh, skinned


def _edit_object_influences(submesh_index, bone_list, skin_edit):
    """Influences for an ``_edit`` object of a submesh the skin edit touches:
    the donor's for non-skinned bones plus the edited skinned weights; None
    when the skin edit does not reach this submesh."""
    if skin_edit is None:
        return None
    per_submesh, skinned = skin_edit
    donor_skinned = False
    influences = []
    for bd in bone_list or []:
        bone_id = int(bd['BoneId'])
        for entry in bd.get('VertexInfluences', []):
            if entry['SubmeshIndex'] != submesh_index:
                continue
            if bone_id in skinned:
                donor_skinned = True
                continue
            raw = _to_bytes(entry['Influences'])
            influences.extend((v, bone_id, w) for v, w in struct.iter_unpack('>Hf', raw))
    if not donor_skinned and submesh_index not in per_submesh:
        return None
    return influences + per_submesh.get(submesh_index, [])


def _rigid_import_placement(submesh, donor_owner, effective_owner):
    """``(original_owner, make_edit)`` for importing a submesh.

    The donor object is the unedited "before" view, so a rigid one always
    sits on its donor bone. Every edit, a bone move included, shows on the
    ``_edit`` object, which sits on the effective owner. (Until 2026-10-07 a
    plain ``GeoIdEdited`` move without a ``RigidRebuild`` put the donor
    object on the new bone too, so both copies showed in the edited place.)
    """
    moved = donor_owner is not None and effective_owner != donor_owner
    return donor_owner, bool(_has_edited_data(submesh) or moved)


def _edited_submesh_view(submesh):
    """Return a shallow copy of *submesh* with all *Edited fields promoted to
    their primary counterparts so existing decode_* helpers can be reused
    without modification.

    A ``RigidRebuild`` is promoted the same way:
    its arrays replace the donor's, and ``_FaceSurfaceIds`` lists the surface
    key each face draws through (donor SurfaceId or new surface key)."""
    view = dict(submesh)
    rebuild = view.get("RigidRebuild") or view.get("SkinnedRebuild")
    if rebuild:
        return _rigid_rebuild_view(view, rebuild)

    vb = dict(view.get("VertexBuffer") or {})
    if vb.get("VertexBufferDataEdited"):
        vb["VertexBufferData"] = vb["VertexBufferDataEdited"]
    view["VertexBuffer"] = vb

    if view.get("FacesDataEdited"):
        view["FacesData"] = view["FacesDataEdited"]
    if view.get("FacesCountEdited") is not None:
        view["FacesCount"] = view["FacesCountEdited"]
    if view.get("FaceTextureIndicesEdited"):
        view["FaceTextureIndices"] = view["FaceTextureIndicesEdited"]

    edited_uvs = []
    for ch in view.get("UVChannels") or []:
        ch = dict(ch)
        if ch.get("UVChannelDataEdited"):
            ch["UVChannelData"] = ch["UVChannelDataEdited"]
        if ch.get("UVFacesDataEdited"):
            ch["UVFacesData"] = ch["UVFacesDataEdited"]
        edited_uvs.append(ch)
    view["UVChannels"] = edited_uvs

    # Per-loop colours and standalone normals: without these the `_edit`
    # object would show donor values and the next export would drop the edit.
    colors = []
    for ch in view.get("ColorChannels") or []:
        ch = dict(ch)
        if ch.get("ColorChannelDataEdited") and ch.get("ColorFacesDataEdited"):
            ch["ColorChannelData"] = ch["ColorChannelDataEdited"]
            ch["ColorFacesData"] = ch["ColorFacesDataEdited"]
        colors.append(ch)
    view["ColorChannels"] = colors

    normal_buffer = view.get("NormalBuffer")
    if (isinstance(normal_buffer, dict) and normal_buffer.get("NormalBufferDataEdited")
            and normal_buffer.get("NormalFacesDataEdited")):
        normal_buffer = dict(normal_buffer)
        normal_buffer["NormalBufferData"] = normal_buffer["NormalBufferDataEdited"]
        normal_buffer["NormalFacesData"] = normal_buffer["NormalFacesDataEdited"]
        view["NormalBuffer"] = normal_buffer

    # Faces moved to another donor surface: one DisplayStates index per face.
    face_surface_ids = _edited_face_surface_ids(view)
    if face_surface_ids is not None:
        view["_FaceSurfaceIds"] = face_surface_ids

    return view


def _edited_face_surface_ids(view):
    """SurfaceId of every face from ``FaceSurfaceIdsEdited``, or None when the
    field is absent or does not fit the faces / display states."""
    raw = _to_bytes(view.get("FaceSurfaceIdsEdited")) if view.get("FaceSurfaceIdsEdited") else b""
    if not raw:
        return None
    display_states = view.get("DisplayStates") or []
    indices = struct.unpack(f'>{len(raw) // 2}H', raw[:len(raw) // 2 * 2])
    if len(indices) != int(view.get("FacesCount") or 0):
        return None
    ids = []
    for ds_idx in indices:
        surface_id = display_states[ds_idx].get("SurfaceId") if ds_idx < len(display_states) else None
        if not surface_id:
            return None
        ids.append(surface_id)
    return ids


def _skinned_rebuild_influences(submesh):
    """``[(vertex, bone, weight)]`` of a SkinnedRebuild, or None."""
    rebuild = submesh.get("SkinnedRebuild") or {}
    raw = _to_bytes(rebuild.get("Influences")) if rebuild.get("Influences") else b""
    return list(struct.iter_unpack('>HHf', raw)) if raw else None


def _rigid_rebuild_view(view, rebuild):
    """The ``_edited_submesh_view`` of a submesh carrying a RigidRebuild or
    a SkinnedRebuild (same array shape; the skinned one keeps its normals
    interleaved in VertexBufferData)."""
    vb = dict(view.get("VertexBuffer") or {})
    vb["VertexBufferData"] = rebuild["VertexBufferData"]
    vb.pop("VertexBufferDataEdited", None)
    view["VertexBuffer"] = vb
    view["FacesData"] = rebuild["FacesData"]
    view["FacesCount"] = int(rebuild["FacesCount"])
    view["FaceTextureIndices"] = _from_bytes(struct.pack(f'>{view["FacesCount"]}H', *([0] * view["FacesCount"])))
    for key in ("FacesDataEdited", "FacesCountEdited", "FaceTextureIndicesEdited", "FaceSurfaceIdsEdited"):
        view.pop(key, None)

    normal_buffer = view.get("NormalBuffer")
    if isinstance(normal_buffer, dict) and rebuild.get("NormalBufferData"):
        normal_buffer = dict(normal_buffer)
        normal_buffer["NormalBufferData"] = rebuild["NormalBufferData"]
        normal_buffer["NormalFacesData"] = rebuild["NormalFacesData"]
        normal_buffer.pop("NormalBufferDataEdited", None)
        normal_buffer.pop("NormalFacesDataEdited", None)
        view["NormalBuffer"] = normal_buffer

    colors = []
    for ch in view.get("ColorChannels") or []:
        ch = dict(ch)
        if rebuild.get("ColorChannelData") and not colors:
            ch["ColorChannelData"] = rebuild["ColorChannelData"]
            ch["ColorFacesData"] = rebuild["ColorFacesData"]
        ch.pop("ColorChannelDataEdited", None)
        ch.pop("ColorFacesDataEdited", None)
        colors.append(ch)
    view["ColorChannels"] = colors

    rebuilt_uv = {int(uv["UVChannelIndex"]): uv for uv in rebuild.get("UVChannels") or []}
    uvs = []
    for ch in view.get("UVChannels") or []:
        ch = dict(ch)
        source = rebuilt_uv.get(int(ch.get("UVChannelIndex", 0)))
        if source is not None:
            ch["UVChannelData"] = source["UVChannelData"]
            ch["UVFacesData"] = source["UVFacesData"]
        ch.pop("UVChannelDataEdited", None)
        ch.pop("UVFacesDataEdited", None)
        uvs.append(ch)
    view["UVChannels"] = uvs

    table = list(rebuild.get("FaceSurfaceTable") or [])
    indices_raw = _to_bytes(rebuild.get("FaceSurfaceIndices"))
    indices = struct.unpack(f'>{len(indices_raw) // 2}H', indices_raw) if indices_raw else ()
    view["_FaceSurfaceIds"] = [table[i] for i in indices]
    return view


def _from_bytes(raw):
    """Field string for a raw buffer (the importer's decoders accept it)."""
    return FieldCodec.encode_field(raw, True)


_GX_WRAP = {0: 'EXTEND', 1: 'REPEAT', 2: 'MIRROR'}


def _surface_face_ranges(display_states):
    """Return list of (surface_id, start_face_idx, face_count) for draw states with faces.

    Includes ALL display-state types — not just Type-7 — because Type-1 (texture-bind)
    states can also carry primitive lists.  States that contribute zero faces are skipped
    (no material slot needed).  Returns None when any Type-7 state lacks FaceCount,
    signalling an old export that needs the legacy per-texture material path.
    """
    result = []
    cumulative = 0
    for ds_idx, ds in enumerate(display_states):
        fc = ds.get("FaceCount")
        if fc is None:
            if ds.get("DisplayStateId") == 7:
                return None  # Old Type-7 without FaceCount: fall back to legacy path
            continue         # Old non-Type-7 without FaceCount: assumed zero faces, skip
        if fc == 0:
            continue         # This state draws nothing; no material slot needed
        surface_id = ds.get("SurfaceId") or f"ds{ds_idx}"
        result.append((surface_id, cumulative, fc))
        cumulative += fc
    return result


def _create_material(mat_name, image, wrap_s=1):
    """Build an Image Texture -> Diffuse BSDF -> Material Output node tree."""
    mat = bpy.data.materials.new(name=mat_name)
    _build_material_nodes(mat, image, wrap_s)
    return mat


def _new_image_texture_node(nodes, right_x, y):
    """An Image Texture node at twice Blender's default width, its right edge
    at *right_x* so the wider node does not cover the node it feeds."""
    tex_node = nodes.new('ShaderNodeTexImage')
    tex_node.width *= 2
    tex_node.location = (right_x - tex_node.width, y)
    return tex_node


def _build_material_nodes(mat, image, wrap_s=1):
    """Replace *mat*'s node tree with the importer's texture tree (see _create_material)."""
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    nodes.clear()

    out_node = nodes.new('ShaderNodeOutputMaterial')
    out_node.location = (800, 0)

    bsdf_node = nodes.new('ShaderNodeBsdfDiffuse')
    bsdf_node.location = (550, 0)

    tex_node = _new_image_texture_node(nodes, 440, 0)
    if image:
        tex_node.image = image
    tex_node.extension = _GX_WRAP.get(wrap_s, 'REPEAT')

    links.new(tex_node.outputs['Color'], bsdf_node.inputs['Color'])
    links.new(bsdf_node.outputs['BSDF'], out_node.inputs['Surface'])


def _set_surface_material_metadata(mat, ds_entry):
    display_state_id = ds_entry.get("DisplayStateId")
    mat["DisplayStateId"] = display_state_id
    # An exported edit wins, so a re-import keeps it (the export compares
    # with the donor value and drops the edit when they match).
    mat["ShaderMode"] = ds_entry.get("ShaderModeEdited") or ds_entry.get("ShaderMode", "")
    mat.id_properties_ui("DisplayStateId").update(
        description="GX display-state command type for this donor surface.")
    shader_description = (
        "Editable Type-7 shader mode. Known names: Spec=specular  "
        "Shdw=no-specular  SpRf=specular-reflection  "
        "RhSp/LhSp=right/left-hand-specular  GhSp=ghost. "
        "Edit via the 'Manage Materials' panel button."
        if display_state_id == 7 else
        f"Raw Type-{display_state_id} GX state setting. Exposed for "
        "surface comparison; only Type-7 shader-mode edits are exported."
    )
    mat.id_properties_ui("ShaderMode").update(description=shader_description)

    if display_state_id == 7:
        param_hex = (ds_entry.get("DisplayStateParamBytesEdited")
                     or ds_entry.get("DisplayStateParamBytes", "000000"))
        try:
            # The 3 exported bytes are struct offsets +1..+3; specular
            # intensity is offset +1, i.e. index 0.
            specular_strength = bytes.fromhex(param_hex)[0]
        except (ValueError, IndexError):
            specular_strength = 0
        mat["SpecularStrength"] = specular_strength
        mat.id_properties_ui("SpecularStrength").update(
            min=0, max=255, soft_min=0, soft_max=255,
            description="Specular highlight intensity (0-255, linear TEV multiplier). "
            "Confirmed in-game for 'Spec'/'LhSp'/'RhSp' shader modes. "
            "Edit via the 'Manage Materials' panel button.")


@lru_cache(maxsize=None)
def _resolve_texture_image_path(sluggie_dir, tex_file):
    """Find a texture PNG for this import, falling back to sibling export folders.

    Lowpoly exports in this workspace often live in a sibling folder without a
    local tex/ directory, while the paired highpoly export keeps the PNG cache.
    """
    candidate_dirs = [os.path.join(sluggie_dir, 'tex')]

    parent_dir = os.path.dirname(sluggie_dir)
    if parent_dir and os.path.isdir(parent_dir):
        sibling_tex_dir = os.path.join(parent_dir, 'tex')
        candidate_dirs.append(sibling_tex_dir)
        try:
            for sibling_name in sorted(os.listdir(parent_dir)):
                sibling_dir = os.path.join(parent_dir, sibling_name)
                if os.path.isdir(sibling_dir):
                    candidate_dirs.append(os.path.join(sibling_dir, 'tex'))
        except OSError:
            pass

    for tex_dir in candidate_dirs:
        img_path = os.path.join(tex_dir, tex_file)
        if os.path.exists(img_path):
            return img_path
    return None


def _surface_ranges_from_face_ids(face_surface_ids):
    """``(surface_id, start, count)`` runs of a per-face surface list, in the
    shape ``_surface_face_ranges`` returns; a surface may appear in several
    runs, and ``build_mesh`` gives it one material slot."""
    ranges = []
    for face_index, surface_id in enumerate(face_surface_ids):
        if ranges and ranges[-1][0] == surface_id:
            ranges[-1] = (surface_id, ranges[-1][1], ranges[-1][2] + 1)
        else:
            ranges.append((surface_id, face_index, 1))
    return ranges


def build_mesh(name, positions, normals, faces, vb_meta, collection,
               uv_channels=None, color_channels=None,
               face_texture_indices=None, sluggie_dir=None,
               submesh_meta=None, prebuilt_materials=None,
               texture_file_map=None, face_surface_ids=None, surface_texture_files=None):
    """Create a Blender mesh object from a vertex list and link it to *collection*.

    *face_surface_ids*, when given, names the surface of every face directly
    (a rebuilt rigid submesh routes faces by key), instead of the donor's
    cumulative ``FaceCount`` ranges. *surface_texture_files* ({SurfaceId:
    PNG name}, ``_assigned_surface_texture_files``) overrides the image of a
    new surface material; its ``TextureIndex`` stays the donor's."""
    # Checked before the mesh exists: a face that names a vertex the buffer does not have makes a mesh
    # Blender can crash on. No exported model has one (all of 2_Output_Assets, 2026-11-22).
    highest = max((index for face in faces for index in face), default=-1)
    if highest >= len(positions):
        raise ValueError(f"{name}: a face uses vertex {highest}, but the submesh has {len(positions)} vertices")
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(positions, [], faces)
    mesh.update()

    n_normals = len(normals)
    if normals and n_normals == len(positions) and len(faces):
        max_face_idx = max(i for face in faces for i in face)
        if max_face_idx < n_normals:
            #mesh.use_auto_smooth = True
            normals_per_loop = [normals[i] for face in faces for i in face]
            mesh.normals_split_custom_set(normals_per_loop)
        # else: face indices exceed vertex buffer — skip custom normals silently

    # Per-loop normals from the standalone NormalBuffer (non-skinned meshes):
    # the donor values become custom split normals so unedited loops round-trip
    # unchanged through the Blender export (plan 3.3, item 1) — mirrors the
    # interleaved CompCount==6 path above, using NormalFacesData per-loop
    # indices instead of position indices.
    if not mesh.has_custom_normals and faces:
        normal_buffer = submesh_meta.get("NormalBuffer") if submesh_meta else None
        if (
            normal_buffer
            and normal_buffer.get("NormalBufferData")
            and normal_buffer.get("NormalFacesData")
        ):
            buffer_normals = decode_normal_buffer(normal_buffer)
            nf_raw = _to_bytes(normal_buffer["NormalFacesData"])
            nf_count = len(nf_raw) // 2
            nf_flat = list(struct.unpack(f'>{nf_count}H', nf_raw)) if nf_count else []
            loop_count = sum(len(f) for f in faces)
            if nf_count == loop_count and max(nf_flat) < len(buffer_normals):
                mesh.normals_split_custom_set([buffer_normals[i] for i in nf_flat])
            else:
                print(
                    f"WARNING: {name}: NormalFacesData has {nf_count} loop indices "
                    f"but the mesh has {loop_count} loops; per-loop normals skipped"
                )

    if uv_channels:
        for ch_ind, uv_channel in enumerate(uv_channels):
            coords, uv_faces = decode_uv_channel(uv_channel)
            if not coords or not uv_faces:
                continue
            # Positional names ("uv0", "uv1", ...) so joined objects share
            # their UV layers instead of collecting one per model name.
            uv_layer = mesh.uv_layers.new(name=f"uv{ch_ind}")
            for poly in mesh.polygons:
                face_idx = poly.index
                if face_idx >= len(uv_faces):
                    continue
                uv_tri = uv_faces[face_idx]
                for loop_offset, loop_idx in enumerate(poly.loop_indices):
                    uv_idx = uv_tri[loop_offset % 3]
                    if uv_idx < len(coords):
                        s, t = coords[uv_idx]
                        # GX V increases downward; flip to match Blender convention
                        uv_layer.data[loop_idx].uv = (s, 1.0 - t)

    if color_channels:
        for color_channel in color_channels:
            ch_idx = color_channel.get("ColorChannelIndex", 0)
            colors, color_faces = decode_color_channel(color_channel)
            if not colors or not color_faces:
                continue
            layer_name = f"color{ch_idx}"
            vcol_layer = mesh.color_attributes.new(name=layer_name, type='BYTE_COLOR', domain='CORNER')
            for poly in mesh.polygons:
                face_idx = poly.index
                if face_idx >= len(color_faces):
                    continue
                col_tri = color_faces[face_idx]
                for loop_offset, loop_idx in enumerate(poly.loop_indices):
                    col_idx = col_tri[loop_offset % 3]
                    if col_idx < len(colors):
                        _set_loop_color(vcol_layer.data[loop_idx], colors[col_idx])

    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)

    # Store vertex buffer metadata as custom properties so the exporter can
    # match this object back to the correct submesh and re-quantize correctly.
    if vb_meta is not None:
        for prop in ("VertexBufferOffset", "VertexBufferLength",
                     "VertexBufferCompCount", "VertexBufferQuantizeInfo"):
            if prop in vb_meta:
                obj[prop] = vb_meta[prop]

    if submesh_meta is not None:
        # Compute once — needed for both shader-mode properties and material creation.
        display_states = submesh_meta.get("DisplayStates", [])
        surface_ranges = (
            _surface_ranges_from_face_ids(face_surface_ids) if face_surface_ids is not None
            else _surface_face_ranges(display_states)
        )

        # Object-level shader mode properties are only written for the legacy path
        # (old exports without FaceCount).  When per-surface materials exist the
        # shader mode lives on mat["ShaderMode"] instead.
        if surface_ranges is None:
            for ds_idx, ds in enumerate(display_states):
                if ds.get("DisplayStateId") != 7:
                    continue
                surface_id = ds.get("SurfaceId") or f"ds{ds_idx}"
                prop_val = f"DS_{surface_id}_ShaderMode"
                obj[prop_val] = ds.get("ShaderModeEdited") or ds.get("ShaderMode", "")
                obj.id_properties_ui(prop_val).update(
                    description=(
                        f"Surface {surface_id} shader mode (legacy — re-export to get per-surface materials). "
                        "Known 4-char names: Spec=specular  Shdw=no-specular  SpRf=specular-reflection  "
                        "RhSp/LhSp=right/left-hand-specular  GhSp=ghost."
                    ))
    else:
        display_states = []
        surface_ranges = None

    # Store UV channel material binding metadata as custom properties
    if uv_channels:
        for uv_channel in uv_channels:
            ch_ind = uv_channel.get("UVChannelIndex", 0)
            prefix = f"UV{ch_ind}_"
            tex_idx = uv_channel.get("TextureIndex")
            wrap_s  = uv_channel.get("WrapS")
            wrap_t  = uv_channel.get("WrapT")
            if tex_idx is not None:
                obj[prefix + "TextureIndex"] = tex_idx
                obj.id_properties_ui(prefix + "TextureIndex").update(
                    description=f"TPL texture index bound to UV channel {ch_ind}")
            if wrap_s is not None:
                obj[prefix + "WrapS"] = wrap_s
                obj.id_properties_ui(prefix + "WrapS").update(
                    description=f"GX S-axis wrap mode for UV channel {ch_ind}")
            if wrap_t is not None:
                obj[prefix + "WrapT"] = wrap_t
                obj.id_properties_ui(prefix + "WrapT").update(
                    description=f"GX T-axis wrap mode for UV channel {ch_ind}")

    # Create Blender materials and assign per-face material indices.
    # New path: one material per face-owning draw state (SurfaceId-keyed).
    # Legacy fallback: one material per unique texture index for old exports.
    if surface_ranges is not None and uv_channels and face_texture_indices:
        # Build texture-index → UV channel map for node tree setup
        tex_to_uv = {}
        for uv_ch in uv_channels:
            idx = uv_ch.get('TextureIndex')
            if idx is not None and idx not in tex_to_uv:
                tex_to_uv[idx] = uv_ch

        mat_slot = {}  # surface_id -> material slot index
        for surface_id, start_fi, fc in surface_ranges:
            if surface_id in mat_slot:
                continue   # a surface listed in several face runs keeps one slot
            slot_idx = len(mat_slot)
            fi_tex = face_texture_indices[start_fi] if start_fi < len(face_texture_indices) else 0
            uv_ch = tex_to_uv.get(fi_tex) or (uv_channels[0] if uv_channels else None)
            wrap_s = uv_ch.get('WrapS', 1) if uv_ch else 1
            wrap_t = uv_ch.get('WrapT', 1) if uv_ch else 1

            if prebuilt_materials is not None and surface_id in prebuilt_materials:
                mat = prebuilt_materials[surface_id]
            elif sluggie_dir is not None:
                tex_file = (texture_file_map or {}).get(fi_tex, f'{fi_tex}.png')
                assigned_file = (surface_texture_files or {}).get(surface_id)
                img_path = assigned_file and _resolve_texture_image_path(sluggie_dir, assigned_file)
                if not img_path:                   # no assignment, or its PNG is gone: the donor's
                    img_path = _resolve_texture_image_path(sluggie_dir, tex_file)
                image = bpy.data.images.load(img_path, check_existing=True) if img_path else None
                mat = _create_material(f'{name}_{surface_id}', image, wrap_s)
                # Store surface identity and editable properties on the material
                ds_entry = next((ds for ds in display_states if ds.get("SurfaceId") == surface_id), {})
                mat["SurfaceId"] = surface_id
                mat["TextureIndex"] = fi_tex
                mat["WrapS"] = wrap_s
                mat["WrapT"] = wrap_t
                _set_surface_material_metadata(mat, ds_entry)
                mat.id_properties_ui("SurfaceId").update(
                    description="Stable draw-state identity (sm{n}_ds{n}). Do not delete — export resolves this material by SurfaceId.")
                mat.id_properties_ui("TextureIndex").update(
                    description="TPL texture slot index active for this draw state.")
                mat.id_properties_ui("WrapS").update(
                    description="GX S-axis wrap mode for this draw state (0=extend, 1=repeat, 2=mirror).")
                mat.id_properties_ui("WrapT").update(
                    description="GX T-axis wrap mode for this draw state (0=extend, 1=repeat, 2=mirror).")
            else:
                continue

            mat_slot[surface_id] = slot_idx
            obj.data.materials.append(mat)

        # Assign faces to their draw-state material by cumulative face range
        for surface_id, start_fi, fc in surface_ranges:
            slot = mat_slot.get(surface_id, 0)
            for fi in range(start_fi, min(start_fi + fc, len(mesh.polygons))):
                mesh.polygons[fi].material_index = slot

    elif uv_channels and face_texture_indices and sluggie_dir is not None:
        # Legacy: per-texture materials (old exports without FaceCount)
        tex_to_uv = {}
        for uv_ch in uv_channels:
            idx = uv_ch.get('TextureIndex')
            if idx is not None and idx not in tex_to_uv:
                tex_to_uv[idx] = uv_ch

        unique_tex = sorted(set(face_texture_indices))
        mat_slot = {}  # TextureIndex -> material slot index
        for slot_idx, tex_idx in enumerate(unique_tex):
            mat_slot[tex_idx] = slot_idx
            uv_ch = tex_to_uv.get(tex_idx) or uv_channels[0]
            wrap_s = uv_ch.get('WrapS', 1)
            tex_file = (texture_file_map or {}).get(tex_idx, f'{tex_idx}.png')
            img_path = _resolve_texture_image_path(sluggie_dir, tex_file)
            image = bpy.data.images.load(img_path, check_existing=True) if img_path else None
            mat = _create_material(f'{name}_mat{tex_idx}', image, wrap_s)
            obj.data.materials.append(mat)

        for poly in mesh.polygons:
            fi = poly.index
            tex_idx = face_texture_indices[fi] if fi < len(face_texture_indices) else unique_tex[0]
            poly.material_index = mat_slot.get(tex_idx, 0)

    elif prebuilt_materials is not None and face_texture_indices:
        # Legacy prebuilt: reuse by tex_idx (old format, int keys)
        available_tex = sorted(t for t in set(face_texture_indices) if t in prebuilt_materials)
        mat_slot = {}
        for slot_idx, tex_idx in enumerate(available_tex):
            mat_slot[tex_idx] = slot_idx
            obj.data.materials.append(prebuilt_materials[tex_idx])

        fallback_slot = 0
        for poly in mesh.polygons:
            fi = poly.index
            tex_idx = face_texture_indices[fi] if fi < len(face_texture_indices) else (available_tex[0] if available_tex else 0)
            poly.material_index = mat_slot.get(tex_idx, fallback_slot)

    return obj


def _restore_root_bone_scale(arm_obj, edited):
    """Put an exported ``RootBoneScaleEdited`` back on the armature, so a
    re-import followed by an export keeps the model scale."""
    try:
        value = tuple(float(v) for v in edited)
    except (TypeError, ValueError):
        return
    if len(value) == 3 and all(math.isfinite(v) for v in value):
        arm_obj["RootBoneScale"] = value


def build_armature(name, bone_list, collection, skin_data=None, reorient=True):
    """Create a Blender Armature from a BoneHierarchy list and link it to *collection*.

    The armature object is named *name* (the imported .sluggie file name without
    its extension). Bone names are ``bone_<id>``. With *reorient* (the import
    option "Reorient Bones"), tails are aimed at the child's head, or at the
    average head of several children (at least REORIENT_MIN_FORK_LENGTH long;
    forward when that gives no direction); leaf bones continue their parent's
    direction instead, falling
    back to a small global-Z offset when there is no usable parent so the bone
    stays visible in the viewport. Without it, that step is skipped and every
    bone keeps the game's own rest orientation (its local +Y is the bone axis,
    one length for all bones). Returns the armature object.
    """
    arm_data = bpy.data.armatures.new(name)
    arm_obj  = bpy.data.objects.new(name, arm_data)
    collection.objects.link(arm_obj)

    # Whole-model (root-bone) scale, editable by the user in the outliner.
    # Defaults to unit scale so an untouched import writes nothing back. The
    # exporter reads this and emits RootBoneScaleEdited when it differs from
    # [1,1,1]; the patcher then scales the model's main root bone SRT.
    arm_obj["RootBoneScale"] = (1.0, 1.0, 1.0)
    arm_obj.id_properties_ui("RootBoneScale").update(
        description=(
            "Whole-model scale applied to the main root bone. "
            "Leave at [1,1,1] for no change; any other value is written back "
            "to dt_na.dat on export."
        ))

    prev_active = bpy.context.view_layer.objects.active
    bpy.context.view_layer.objects.active = arm_obj
    bpy.ops.object.mode_set(mode='EDIT')
    edit_bones = arm_data.edit_bones

    bone_id_to_name = {}
    for bd in bone_list:
        eb = edit_bones.new(f"bone_{bd['BoneId']}")
        h = bd['HeadPosition']
        eb.head = (h[0], h[1], h[2])
        # Placeholder tail — overridden below when a child is found
        eb.tail = (h[0], h[1], h[2] + LEAF_TAIL_FALLBACK)
        bone_id_to_name[bd['BoneId']] = eb.name

    # Collect every child head for each parent so we can aim tails
    child_heads = {}
    for bd in bone_list:
        pid = bd['ParentBoneId']
        if pid is not None:
            child_heads.setdefault(pid, []).append(mathutils.Vector(bd['HeadPosition']))

    for bd in bone_list:
        eb = edit_bones.get(bone_id_to_name.get(bd['BoneId'], ''))
        if eb is None:
            continue
        # Set parent relationship
        pid = bd['ParentBoneId']
        if pid is not None:
            parent_eb = edit_bones.get(bone_id_to_name.get(pid, ''))
            if parent_eb:
                eb.parent = parent_eb
        # Aim tail at the child, or at the children's average head. A fork's
        # average can sit almost on the head (pelvis between the thighs), so
        # forks get a minimum length; a bone with no direction points forward.
        if reorient and bd['BoneId'] in child_heads:
            heads_c = child_heads[bd['BoneId']]
            target = sum(heads_c, mathutils.Vector()) / len(heads_c)
            direction = target - eb.head
            if direction.length <= 1e-9:
                eb.tail = eb.head + REORIENT_FORWARD * REORIENT_MIN_FORK_LENGTH
            elif len(heads_c) > 1 and direction.length < REORIENT_MIN_FORK_LENGTH:
                eb.tail = eb.head + direction.normalized() * REORIENT_MIN_FORK_LENGTH
            else:
                eb.tail = target

    heads = [bd['HeadPosition'] for bd in bone_list]
    extent = max(
        max(h[axis] for h in heads) - min(h[axis] for h in heads)
        for axis in range(3)
    ) if heads else 0.0

    if not reorient:
        # No reorientation: each bone takes the game's rest rotation (bone axis =
        # the game bone's local +Y), all at one length scaled to the model.
        length = max(extent * 0.03, LEAF_TAIL_FALLBACK * 0.5)
        abs_mats = _compute_bone_absolute_matrices(bone_list)
        for bd in bone_list:
            eb = edit_bones.get(bone_id_to_name.get(bd['BoneId'], ''))
            if eb is None:
                continue
            eb.tail = eb.head + mathutils.Vector((0.0, length, 0.0))
            rot = abs_mats[bd['BoneId']].to_quaternion() if bd['BoneId'] in abs_mats else mathutils.Quaternion()
            eb.matrix = mathutils.Matrix.Translation(eb.head) @ rot.to_matrix().to_4x4()

    # Leaf bones have no child to aim at. Continuing the parent's direction
    # keeps chain terminators — fingertips and the like — in line with the
    # chain instead of forking off along +Z, where the stub reads as a real
    # finger segment and is easy to click by mistake.
    #
    # The parent's length is only a starting point: some leaves hang off long
    # structural bones (Luigi's bone_4 off a 0.85-unit spine bone) and would
    # shoot a spike across the model, while others hang off near-degenerate
    # bones (mini_luigi's bones sit 2e-06 apart) and would come out an
    # invisible sliver. Clamp into a band scaled to the model's own bone
    # spread, falling back to the fixed stub length for models too small or
    # too degenerate to derive a scale from.
    leaf_max = max(extent * 0.05, LEAF_TAIL_FALLBACK)
    leaf_min = LEAF_TAIL_FALLBACK * 0.5

    # Runs after the loop above so every parent already has its final tail.
    for bd in bone_list:
        if not reorient or bd['BoneId'] in child_heads:
            continue
        eb = edit_bones.get(bone_id_to_name.get(bd['BoneId'], ''))
        if eb is None or eb.parent is None:
            continue
        direction = eb.parent.tail - eb.parent.head
        # A parent with no direction at all gives nothing to continue, so the
        # +Z placeholder stands; normalizing here would collapse the bone and
        # Blender drops zero-length bones on leaving edit mode.
        if direction.length > 1e-9:
            length = min(max(direction.length, leaf_min), leaf_max)
            eb.tail = eb.head + direction.normalized() * length

    bpy.ops.object.mode_set(mode='OBJECT')

    skn_bone_ids = HostBones.skn_bone_ids(skin_data)
    for bd in bone_list:
        bone_name = bone_id_to_name.get(bd['BoneId'])
        if bone_name and bone_name in arm_data.bones:
            b = arm_data.bones[bone_name]
            b['track_id'] = bd.get('TrackId', 0xFFFF)
            # The game re-solves these bones (AnimScale): they follow the
            # parent's scaled position, not its scale. No visible effect
            # while every scale is 1, as in every stock animation.
            if AnimScale.is_layer_root(b['track_id']):
                b.inherit_scale = 'NONE'
            b['game_translation'] = list(bd['Translation'])
            b['game_quaternion'] = list(bd['Quaternion'])
            b['game_scale'] = list(bd['Scale'])
            # Donor ownership/skinning snapshot for the Add submesh free-bone
            # proposal (HostBones.py). Fixed
            # facts of the exported model, read-only, stored on Bone (not
            # EditBone) so they survive into saved .blend files.
            # SluggiesSkinned must come from SkinData: BoneHierarchy's own
            # "Skinned" flag only means GeoIdRaw == 0xFFFF.
            b['SluggiesGeoIdRaw'] = int(bd.get('GeoIdRaw', 0xFFFF))
            b['SluggiesSkinned'] = bd['BoneId'] in skn_bone_ids
            # Round-tripped for Add Bone: every bone (donor or new) needs these
            # written into BoneHierarchyEdited on export. (A new bone's own
            # SRTType is derived at export, not copied from its parent.)
            if bd.get('MirrorBoneId') is not None:
                b['SluggiesMirrorBoneId'] = int(bd['MirrorBoneId'])
            if bd.get('MirrorRole') is not None:
                b['SluggiesMirrorRole'] = int(bd['MirrorRole'])
            b['SluggiesSRTType'] = int(bd.get('SRTType', 0))
            b['SluggiesDrawPriority'] = int(bd.get('DrawPriority', 0))
            b['SluggiesInheritTransform'] = bool(bd.get('InheritTransform', True))
            # False for every imported (donor) bone; Add bone sets this True.
            b['SluggiesUserAdded'] = False

    arm_obj['SluggiesBoneMetadataVersion'] = HostBones.BONE_METADATA_VERSION
    arm_obj.show_in_front = True
    arm_obj.display_type = 'WIRE'
    arm_obj.rotation_euler[0] = math.pi / 2
    bpy.context.view_layer.objects.active = prev_active
    return arm_obj


def assign_bone_collections(arm_obj, bone_names=None):
    """Sort every bone of *arm_obj* into the BoneRoles collections, from the
    properties the import stored on it (SluggiesSkinned, SluggiesGeoIdRaw,
    track_id, SluggiesUserAdded). Collections are created in
    ``BoneRoles.COLLECTION_ORDER``, only for roles the model has. With
    *bone_names*, only those bones, taken out of their old role collections
    first."""
    arm_data = arm_obj.data
    if bone_names is not None:
        for name in BoneRoles.COLLECTION_ORDER:
            collection = arm_data.collections.get(name)
            if collection is not None:
                for bone_name in bone_names:
                    collection.unassign(arm_data.bones[bone_name])
    roles_by_bone = {
        bone.name: BoneRoles.bone_roles(
            skinned=bool(bone.get('SluggiesSkinned', False)),
            geo_id_raw=int(bone.get('SluggiesGeoIdRaw', BoneRoles.GEO_ID_FREE)),
            track_id=int(bone.get('track_id', BoneRoles.NO_TRACK)),
            has_parent=bone.parent is not None,
            has_children=bool(bone.children),
            user_added=bool(bone.get('SluggiesUserAdded', False)),
        )
        for bone in arm_data.bones
        if bone_names is None or bone.name in bone_names
    }
    used = {role for roles in roles_by_bone.values() for role in roles}
    for name in BoneRoles.COLLECTION_ORDER:
        if name in used:
            BoneRoles.bone_collection(arm_data, name)
    for bone_name, roles in roles_by_bone.items():
        for role in roles:
            arm_data.collections[role].assign(arm_data.bones[bone_name])


def add_rest_pose_action(arm_obj):
    """A one-frame action keying every bone at its rest pose, made the
    armature's active action, so the Action Editor can switch back to rest
    after .anm imports. An empty action would not reset the pose: assigning
    it leaves bones where the previous action put them. It has no
    SluggiesAnmGroup, so the .anm export ignores it."""
    action = bpy.data.actions.new(name=f"{arm_obj.name}_RestPose")
    action.use_fake_user = True
    action['SluggiesRestPose'] = True
    if arm_obj.animation_data is None:
        arm_obj.animation_data_create()
    arm_obj.animation_data.action = action

    def _key(data_path, values, group):
        for i, value in enumerate(values):
            # Blender 4.4+ (slotted actions) creates F-curves through the data-block.
            if hasattr(action, 'fcurve_ensure_for_datablock'):
                fc = action.fcurve_ensure_for_datablock(arm_obj, data_path, index=i, group_name=group)
            else:
                fc = action.fcurves.new(data_path, index=i, action_group=group)
            fc.keyframe_points.insert(0, value, options={'FAST'})
            fc.update()

    for pose_bone in arm_obj.pose.bones:
        pose_bone.rotation_mode = 'QUATERNION'
        path = f'pose.bones["{bpy.utils.escape_identifier(pose_bone.name)}"]'
        _key(f'{path}.location', (0.0, 0.0, 0.0), pose_bone.name)
        _key(f'{path}.rotation_quaternion', (1.0, 0.0, 0.0, 0.0), pose_bone.name)
        _key(f'{path}.scale', (1.0, 1.0, 1.0), pose_bone.name)
    return action


def _apply_import_rotation(obj):
    obj.matrix_world = obj.matrix_world @ mathutils.Matrix.Rotation(math.pi / 2, 4, 'X')


def add_vertex_groups(obj, submesh_index, bone_list, arm_obj, owner_bone_id=None, influences=None):
    """Add vertex groups from BoneHierarchy for *submesh_index* and attach an
    Armature modifier pointing at *arm_obj*.

    With *owner_bone_id* (a rigid submesh whose owner the file moved, or a
    rebuilt one whose vertices the donor influences do not cover) every
    vertex goes into ``bone_<owner>`` at weight 1.0 instead. With
    *influences* (``[(vertex, bone, weight)]`` of a rebuilt body) the groups
    come from those records."""
    if influences is not None:
        num_verts = len(obj.data.vertices)
        for v_idx, bone_id, weight in influences:
            group_name = f"bone_{bone_id}"
            vg = obj.vertex_groups.get(group_name)
            if vg is None:
                vg = obj.vertex_groups.new(name=group_name)
            if v_idx < num_verts:
                vg.add([v_idx], weight, 'REPLACE')
    elif owner_bone_id is not None:
        vg = obj.vertex_groups.new(name=f"bone_{owner_bone_id}")
        vg.add(list(range(len(obj.data.vertices))), 1.0, 'REPLACE')
    else:
        for bd in bone_list:
            for entry in bd.get('VertexInfluences', []):
                if entry['SubmeshIndex'] != submesh_index:
                    continue
                group_name = f"bone_{bd['BoneId']}"
                vg = obj.vertex_groups.get(group_name)
                if vg is None:
                    vg = obj.vertex_groups.new(name=group_name)
                num_verts = len(obj.data.vertices)
                raw = _to_bytes(entry['Influences'])
                for v_idx, weight in struct.iter_unpack('>Hf', raw):
                    if v_idx < num_verts:
                        vg.add([v_idx], weight, 'REPLACE')

    mod = obj.modifiers.new(name="Armature", type='ARMATURE')
    mod.object = arm_obj


def _template_shader_mode_from_model(model, template_source):
    """Effective Type-7 mode of a template source, read from the .sluggie."""
    kind, _sep, argument = str(template_source).partition(':')
    if kind == 'builtin':
        from . import TemplateSources
        template = TemplateSources.BUILTIN_TEMPLATES.get(argument)
        return template.shader_mode if template is not None else ''
    for submesh in model.get('Submeshes') or []:
        states = submesh.get('DisplayStates') or []
        mode = ''
        for state in states:
            if int(state.get('DisplayStateId', -1)) == 7:
                mode = state.get('ShaderModeEdited') or state.get('ShaderMode', '')
            if state.get('SurfaceId') == argument:
                return mode
    return ''


def _new_surface_materials(name, submesh, submesh_index, model, sluggie_dir, texture_file_map):
    """Re-create the Add-material surfaces of a rebuilt rigid submesh
    (``RigidRebuild.NewSurfaces``) as Blender materials, keyed by surface key,
    with the metadata Add material writes. The
    image comes from the appended PNG in tex/ or from the donor texture it
    binds; when the file is missing the node stays empty, so the next export
    stops on it instead of changing the texture silently."""
    from . import ExportSluggies
    materials = {}
    rebuild = submesh.get("RigidRebuild") or submesh.get("SkinnedRebuild") or {}
    uv0 = (submesh.get("UVChannels") or [{}])[0]
    for entry in rebuild.get("NewSurfaces") or []:
        key = entry["SurfaceKey"]
        template = str(entry.get("TemplateSource") or "")
        assignment = entry.get("TextureAssignment") or {}
        tex_file = assignment.get("AdditionalTextureFileName")
        if tex_file is None and assignment.get("DonorTextureIndex") is not None:
            tex_file = (texture_file_map or {}).get(int(assignment["DonorTextureIndex"]))
        img_path = _resolve_texture_image_path(sluggie_dir, tex_file) if (sluggie_dir and tex_file) else None
        image = bpy.data.images.load(img_path, check_existing=True) if img_path else None
        if image is None:
            print(f"WARNING: {name}: PNG for new surface {key} ({tex_file}) not found; its texture node is left empty")
        wrap_s, wrap_t = int(uv0.get("WrapS", 1)), int(uv0.get("WrapT", 1))
        mat = _create_material(entry.get("MaterialName") or f"{name}_{key}", image, wrap_s)
        mat["SluggiesNewSurface"] = True
        mat.id_properties_ui("SluggiesNewSurface").update(
            description="Marks a Blender-only surface created by Add material, absent from the donor.")
        mat["SurfaceId"] = key
        mat.id_properties_ui("SurfaceId").update(
            description="Stable draw-state identity for this added surface. Do not delete.")
        mat["SluggiesSurfaceOwner"] = f"sm{submesh_index}"
        mat.id_properties_ui("SluggiesSurfaceOwner").update(
            description="The submesh (donor sm<N> or CustomSubmeshId) this surface belongs to.")
        mat["TemplateSource"] = template
        mat.id_properties_ui("TemplateSource").update(
            description="Donor or built-in template this surface's shading is cloned from.")
        try:
            mat["TemplateTextureIndex"] = ExportSluggies._custom_submesh_template_texture_index(model, template)
        except ValueError:
            mat["TemplateTextureIndex"] = 0
        mat.id_properties_ui("TemplateTextureIndex").update(
            description="Donor texture index this surface's GX format clones; never a fallback texture.")
        strength = entry.get("SpecularStrength")
        _set_surface_material_metadata(mat, {
            "DisplayStateId": 7,
            "ShaderMode": _template_shader_mode_from_model(model, template),
            "DisplayStateParamBytes": bytes([int(strength) if strength is not None else 0, 0, 0]).hex(),
        })
        mat["WrapS"] = wrap_s
        mat["WrapT"] = wrap_t
        materials[key] = mat
    return materials


# Length of a re-created Add Bone bone (SluggiesToolsPanel.ADDED_BONE_LENGTH; the
# panel imports this module, so the value is repeated, not imported).
ADDED_BONE_LENGTH = 1.0


def _srt_local_matrix(bone):
    """A bone's local rest matrix T @ R @ S from its .sluggie SRT fields, the
    same math as _compute_bone_absolute_matrices (Quaternion stored as
    ``[-qw, qx, qy, qz]``)."""
    trans, quat, scale = bone['Translation'], bone['Quaternion'], bone['Scale']
    rotation = mathutils.Quaternion((-quat[0], quat[1], quat[2], quat[3])).to_matrix().to_4x4()
    return mathutils.Matrix.Translation(trans) @ rotation @ mathutils.Matrix.Diagonal((*scale, 1.0))


def add_imported_added_bones(arm_obj, entries, donor_game_matrices=None):
    """Re-create the Add Bone bones of ``BoneHierarchyEdited`` (*entries* from
    CustomSubmeshImport.added_bone_entries) on *arm_obj*, with the properties
    Add Bone gives them. The exporter wrote each one's rest matrix relative to
    its parent's Blender rest matrix (a stadium root's relative to the
    armature), so this inverts it exactly. In a stadium a child of an original
    bone is written relative to that bone's GAME frame instead
    (``encode_bone_hierarchy_edited``): pass the stadium's
    *donor_game_matrices* (``{BoneId: absolute matrix}`` of the original
    bones) and those children are placed from it. Blender's own frame of an
    original bone is reoriented for display and would put the bone elsewhere
    (Blender 5.2.2, Yoshi Park, 2026-11-15: placed at (3, -2, 5), back at
    (3, -5, -2) and turned by 90 degrees). Returns the bone names."""
    if not entries:
        return []
    prev_active = bpy.context.view_layer.objects.active
    bpy.context.view_layer.objects.active = arm_obj
    bpy.ops.object.mode_set(mode='EDIT')
    created = []
    try:
        edit_bones = arm_obj.data.edit_bones
        for order, entry in enumerate(entries):
            name = f"bone_{int(entry['BoneId'])}"
            if name in edit_bones:
                continue
            parent = entry.get('ParentBoneId')
            parent_eb = edit_bones.get(f"bone_{int(parent)}") if parent is not None else None
            eb = edit_bones.new(name)
            eb.head = (0.0, 0.0, 0.0)
            eb.tail = (0.0, ADDED_BONE_LENGTH, 0.0)
            if parent_eb is None:
                base = mathutils.Matrix.Identity(4)
            elif donor_game_matrices is not None and int(parent) in donor_game_matrices:
                base = mathutils.Matrix(donor_game_matrices[int(parent)])
            else:
                base = parent_eb.matrix
            eb.matrix = base @ _srt_local_matrix(entry)
            eb.parent = parent_eb
            eb.use_connect = False
            created.append((eb.name, order, entry))
    finally:
        bpy.ops.object.mode_set(mode='OBJECT')
    for name, order, entry in created:
        b = arm_obj.data.bones[name]
        b['SluggiesUserAdded'] = True
        b['SluggiesCreationOrder'] = order
        b['SluggiesGeoIdRaw'] = int(entry.get('GeoIdRaw', GEO_ID_FREE))
        b['SluggiesSkinned'] = bool(entry.get('Skinned', False))
        b['SluggiesDrawPriority'] = int(entry.get('DrawPriority', 0))
        b['SluggiesInheritTransform'] = bool(entry.get('InheritTransform', True))
        b['track_id'] = int(entry.get('TrackId', GEO_ID_FREE))
    bpy.context.view_layer.objects.active = prev_active
    return [name for name, _order, _entry in created]


def restore_donor_bones(context, arm_obj, bone_list, skin_data=None):
    """Put the .sluggie's skeleton (*bone_list*, its BoneHierarchy) back on
    *arm_obj*: donor bones deleted in Blender come back where a fresh import
    puts them (Reorient Bones as on the original import), with their track
    id and import metadata, and every donor bone gets its original parent.
    Added bones keep their place, parent and collections. Keys of a deleted
    bone stay in its actions under its name, so its animation comes back
    with it. Returns (restored names, re-parented names)."""
    bones = arm_obj.data.bones
    expected = {f"bone_{bd['BoneId']}": (f"bone_{bd['ParentBoneId']}" if bd['ParentBoneId'] is not None else None)
                for bd in bone_list}
    for name in expected:
        if name in bones and bones[name].get('SluggiesUserAdded'):
            raise ValueError(f"added bone {name} holds the name of an original bone; renumber added bones first")
    missing = [name for name in expected if name not in bones]
    reparent = [name for name in expected if name in bones
                and (bones[name].parent.name if bones[name].parent else None) != expected[name]]
    if not missing and not reparent:
        return [], []
    if arm_obj.name not in context.view_layer.objects:
        raise ValueError(f"{arm_obj.name} is not in the view layer; include its collection")
    old_parents = {bones[name].parent.name for name in reparent if bones[name].parent is not None}

    view_layer = context.view_layer
    prev_active = view_layer.objects.active
    selected = [obj for obj in view_layer.objects if obj.select_get()]
    for obj in selected:
        obj.select_set(False)
    try:
        fresh = {}
        if missing:
            # A throwaway fresh import gives the deleted bones the same rest
            # frames (tails, roll) the original import gave them.
            temp = build_armature("__sluggies_restore_bones", bone_list, context.scene.collection, skin_data,
                                  reorient=bool(arm_obj.get('SluggiesBonesReoriented', True)))
            temp_data = temp.data
            for name in missing:
                bone = temp_data.bones[name]
                # Plain copies: the temp armature's ID properties die with it.
                props = {key: value.to_list() if hasattr(value, 'to_list') else value
                         for key, value in bone.items()}
                fresh[name] = (bone.head_local.copy(), bone.tail_local.copy(), bone.matrix_local.copy(),
                               bone.inherit_scale, props)
            bpy.data.objects.remove(temp)
            bpy.data.armatures.remove(temp_data)

        hidden = (arm_obj.hide_get(), arm_obj.hide_viewport)
        arm_obj.hide_set(False)
        arm_obj.hide_viewport = False
        arm_obj.select_set(True)
        view_layer.objects.active = arm_obj
        bpy.ops.object.mode_set(mode='EDIT')
        try:
            edit_bones = arm_obj.data.edit_bones
            for name in missing:
                head, tail, matrix, _inherit, _props = fresh[name]
                eb = edit_bones.new(name)
                eb.head = head
                eb.tail = tail
                eb.matrix = matrix
                eb.use_connect = False
            for name in missing + reparent:
                parent = expected[name]
                edit_bones[name].parent = edit_bones[parent] if parent is not None else None
        finally:
            bpy.ops.object.mode_set(mode='OBJECT')
            arm_obj.select_set(False)
            arm_obj.hide_set(hidden[0])
            arm_obj.hide_viewport = hidden[1]

        bones = arm_obj.data.bones
        for name in missing:
            _head, _tail, _matrix, inherit, props = fresh[name]
            bone = bones[name]
            bone.inherit_scale = inherit
            for key, value in props.items():
                bone[key] = value
        touched = set(missing) | set(reparent) | old_parents | {expected[n] for n in missing + reparent}
        assign_bone_collections(arm_obj, [name for name in touched if name is not None
                                          and not bones[name].get('SluggiesUserAdded')])
    finally:
        for obj in selected:
            obj.select_set(True)
        view_layer.objects.active = prev_active
    return missing, reparent


def _custom_submesh_image(name, assignment, sluggie_dir, texture_file_map):
    """The image a custom submesh surface binds: its added PNG from tex/, or
    the donor texture it names. None (with a console note) when the file is
    missing: the empty node then stops the next export instead of changing the
    texture silently, as for rebuilt surfaces."""
    tex_file = assignment.get("AdditionalTextureFileName")
    if tex_file is None and assignment.get("DonorTextureIndex") is not None:
        tex_file = (texture_file_map or {}).get(int(assignment["DonorTextureIndex"]))
    img_path = _resolve_texture_image_path(sluggie_dir, tex_file) if (sluggie_dir and tex_file) else None
    if img_path:
        return bpy.data.images.load(img_path, check_existing=True)
    print(f"WARNING: {name}: PNG {tex_file} not found; its texture node is left empty")
    return None


def _custom_submesh_materials(obj_name, cs, model, sluggie_dir, texture_file_map):
    """The surfaces of a decoded custom submesh *cs*, as Add New Submesh and
    Add material make them: the primary ``<id>_ds0`` first, then one material
    per ``AdditionalSurfaces`` entry, in slot order."""
    from . import ExportSluggies, SluggiesToolsPanel, TemplateSources
    default_strength = TemplateSources.BUILTIN_DEFAULT_SPECULAR_STRENGTH
    primary = _create_material(
        f"{obj_name}_{cs.custom_submesh_id}_ds0",
        _custom_submesh_image(obj_name, cs.texture_assignment, sluggie_dir, texture_file_map),
        wrap_s=1,
    )
    SluggiesToolsPanel._set_custom_primary_surface(
        primary, cs.custom_submesh_id, _template_shader_mode_from_model(model, cs.template_source),
        cs.specular_strength if cs.specular_strength is not None else default_strength,
    )
    materials = [primary]
    for surface in cs.additional_surfaces:
        template = str(surface.get("TemplateSource") or "")
        mat = _create_material(
            surface.get("MaterialName") or f"{obj_name}_{surface['SurfaceKey']}",
            _custom_submesh_image(obj_name, surface.get("TextureAssignment") or {}, sluggie_dir, texture_file_map),
            wrap_s=1,
        )
        try:
            template_texture_index = ExportSluggies._custom_submesh_template_texture_index(model, template)
        except ValueError:
            template_texture_index = 0
        strength = surface.get("SpecularStrength")
        SluggiesToolsPanel._apply_new_surface_plan(mat, {
            'kind': 'custom',
            'owner': cs.custom_submesh_id,
            'surface_id': surface['SurfaceKey'],
            'template_source': template,
            'template_texture_index': template_texture_index,
            'shader_mode': _template_shader_mode_from_model(model, template),
            'specular_strength': int(strength) if strength is not None else default_strength,
            'wrap_s': 1,
            'wrap_t': 1,
        })
        materials.append(mat)
    return materials


def build_custom_submesh(cs, model, arm_obj, bind_matrices, collection, sluggie_dir, texture_file_map):
    """Blender object for a decoded custom submesh *cs*
    (CustomSubmeshImport.CustomSubmeshMesh): bone-local vertices placed at the
    host bone's bind matrix (where the exporter reads them back from), weighted
    to the host bone, with the object properties Add New Submesh writes."""
    mesh = bpy.data.meshes.new(cs.name)
    mesh.from_pydata(cs.positions, [], cs.faces)
    mesh.update()
    # from_pydata lays the loops out face by face, so loop k is corner k.
    if cs.loop_uvs is not None:
        uv_layer = mesh.uv_layers.new(name="uv0")
        for loop, uv in enumerate(cs.loop_uvs):
            uv_layer.data[loop].uv = uv
    if cs.loop_colors is not None:
        colors = mesh.color_attributes.new(name="color0", type='BYTE_COLOR', domain='CORNER')
        for loop, rgba in enumerate(cs.loop_colors):
            _set_loop_color(colors.data[loop], rgba)
    if cs.loop_normals is not None:
        mesh.normals_split_custom_set(cs.loop_normals)

    obj = bpy.data.objects.new(cs.name, mesh)
    collection.objects.link(obj)
    obj['SluggiesCustomSubmesh'] = True
    obj['CustomSubmeshId'] = cs.custom_submesh_id
    obj['TemplateSource'] = cs.template_source

    for mat in _custom_submesh_materials(obj.name, cs, model, sluggie_dir, texture_file_map):
        mesh.materials.append(mat)
    for poly, surface in zip(mesh.polygons, cs.face_surfaces):
        poly.material_index = surface

    group = obj.vertex_groups.new(name=f"bone_{cs.host_bone_id}")
    group.add(list(range(len(mesh.vertices))), 1.0, 'REPLACE')
    modifier = obj.modifiers.new(name="Armature", type='ARMATURE')
    modifier.object = arm_obj
    obj.parent = arm_obj
    obj.matrix_parent_inverse = mathutils.Matrix.Identity(4)
    obj.matrix_basis = bind_matrices[cs.host_bone_id]
    return obj


def build_collision_object(entry, arm_obj, collection):
    """A collision-only mesh for one ``StadiumCollision`` entry: model-space
    vertices under the armature (identity basis, where the exporter reads them
    back from), drawn as wire, with its collision settings restored. A model
    mesh or custom submesh that was solid comes back without the setting; this
    object carries it instead."""
    # Everything is read from the entry before anything is built, so a bad entry leaves nothing behind.
    region = entry.get('Region')
    name = entry['Name'] if region is not None else f"{entry['Name']}_collision"
    positions = [tuple(p) for p in entry['Positions']]
    faces = [tuple(f) for f in entry['Faces']]
    highest = max((index for face in faces for index in face), default=-1)
    if highest >= len(positions):
        raise ValueError(f"{name}: a face uses vertex {highest}, but it has {len(positions)} vertices")
    number = int(entry['SurfaceType'])
    sides = next((i for i, v, _l, _d in StadiumCollisionExport.SIDES if v == entry.get('Sides', 'both')), None)
    territory = next(
        (i for i, v, _l, _d in StadiumCollisionExport.TERRITORIES if v == entry.get('Territory', 'auto')), None)
    if sides is None or territory is None:
        raise ValueError(
            f"{name}: unknown Sides {entry.get('Sides')!r} or Territory {entry.get('Territory')!r}")

    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(positions, [], faces)
    mesh.update()
    obj = bpy.data.objects.new(mesh.name, mesh)
    collection.objects.link(obj)
    obj.parent = arm_obj
    obj.matrix_parent_inverse = mathutils.Matrix.Identity(4)
    obj.matrix_basis = mathutils.Matrix.Identity(4)
    obj.display_type = 'WIRE'
    settings = obj.sluggies_collision
    settings.enabled = True
    settings.invisible = True  # a collision-only object, never drawn
    if region is not None:
        obj[StadiumCollisionExport.REGION_PROP] = int(region)
        obj.hide_render = True
    named = next((ident for ident, n, _l, _d in StadiumCollisionExport.SURFACE_TYPES if n == number), None)
    settings.surface_type = named or 'CUSTOM'
    if named is None:
        settings.custom_type = number
    settings.sides = sides
    settings.territory = territory
    return obj


# What an import creates, in the order a failed one is taken apart again (users before the data they use).
_IMPORTED_KINDS = ('objects', 'collections', 'meshes', 'armatures', 'actions', 'materials', 'images')


def _datablock_names():
    return {kind: {block.name for block in getattr(bpy.data, kind)} for kind in _IMPORTED_KINDS}


def _remove_datablocks_added_since(before):
    """Remove every datablock of ``_IMPORTED_KINDS`` that is not named in *before*; returns how many."""
    removed = 0
    for kind in _IMPORTED_KINDS:
        collection = getattr(bpy.data, kind)
        for block in [block for block in collection if block.name not in before[kind]]:
            try:
                collection.remove(block)
                removed += 1
            except (RuntimeError, ReferenceError):
                pass
    return removed


def _undoes_failed_import(execute):
    """For the import operator's ``execute``: a damaged or hand-edited file fails somewhere in the middle of
    the build (a short buffer, a missing key). Instead of a traceback over a half-built scene (the armature,
    some meshes, Blender left in armature Edit Mode), the error is reported, Object Mode restored and
    everything the import had created removed again."""
    @functools.wraps(execute)
    def guarded(self, context):
        if context.mode != 'OBJECT':
            self.report({"ERROR"}, "Switch to Object Mode before importing a .sluggie.")
            return {"CANCELLED"}
        before = _datablock_names()
        try:
            return execute(self, context)
        except Exception as exc:  # noqa: BLE001 - whatever a damaged file raises, the scene is put back
            traceback.print_exc()
            try:
                if bpy.context.mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:  # noqa: BLE001
                pass
            removed = _remove_datablocks_added_since(before)
            self.report({"ERROR"},
                f"Import failed ({type(exc).__name__}: {exc}): {os.path.basename(self.filepath)} is damaged "
                f"or not a model file. The {removed} object(s) and data blocks it had built were removed "
                "again; the full traceback is in the system console.")
            return {"CANCELLED"}
    return guarded


class SLUGGIES_OT_import(bpy.types.Operator, ImportHelper):
    bl_idname = "sluggies.import_json"
    bl_label = "Import Sluggers intermediate"
    bl_description = "Import a Sluggers intermediate JSON file"
    bl_options = {"UNDO"}

    filename_ext = ".sluggie"
    filter_glob: StringProperty(default="*.sluggie", options={"HIDDEN"}) # type: ignore[valid-type]
    reorient_bones: BoolProperty(  # type: ignore[valid-type]
        name="Reorient Bones",
        description=("Aim each bone at its child, or the average of several children "
                     "(leaf bones continue their parent) "
                     "for a readable skeleton. Off: bones keep the game's own rest "
                     "orientation. Only changes how the skeleton looks in Blender"),
        default=True,
    )

    @_undoes_failed_import
    def execute(self, context):
        # Per import only: a PNG that was missing (or has since been deleted) is looked up again.
        _resolve_texture_image_path.cache_clear()
        data = FieldCodec.load_sluggie(self.filepath)

        model = data["SluggiesModel"]
        model_number = model["ChunkNumber"]
        model_offset_hex = model["ModelOffset"]
        submeshes = model.get("Submeshes", [])
        texture_file_map = _texture_file_map(model.get("TextureDescriptors", []))
        sluggie_dir = os.path.dirname(self.filepath)
        if not texture_file_map:
            texture_file_map = _texture_file_map_from_sibling_sluggie(self.filepath, model)
        surface_texture_files = _assigned_surface_texture_files(model, texture_file_map)
        skin_edit = _edited_skin_influences(model)

        collection = context.collection

        # Build armature first so mesh objects can reference it immediately
        bone_list = model.get("BoneHierarchy")
        arm_obj = None
        abs_bone_mats = {}
        if bone_list:
            # Name the armature after the imported .sluggie file (without its
            # extension) so it is easy to identify in the outliner. The export
            # workflow does not rely on the armature name — meshes are matched
            # by their VertexBufferOffset custom property and skin weights are
            # read from bone_<id> vertex groups — so this is cosmetic.
            base_name = os.path.splitext(os.path.basename(self.filepath))[0]
            arm_obj = build_armature(base_name, bone_list, collection, model.get("SkinData"),
                                     reorient=self.reorient_bones)
            arm_obj['SluggiesBonesReoriented'] = bool(self.reorient_bones)
            _restore_root_bone_scale(arm_obj, model.get("RootBoneScaleEdited"))
            abs_bone_mats = _compute_bone_absolute_matrices(bone_list)
            # So the exporter and Add submesh can find this model's file and
            # tex/ directory without asking the user (SluggiePath.resolve).
            SluggiePath.remember(arm_obj, self.filepath)
            # The model directory; a stadium (TemplateSources.STADIUM_CHUNKS)
            # takes custom submeshes only on root bones.
            arm_obj['SluggiesChunkNumber'] = int(model_number)
            # Bones added with Add Bone (BoneHierarchyEdited), so their custom
            # submeshes and body weights have them again.
            from . import TemplateSources
            add_imported_added_bones(
                arm_obj, CustomSubmeshImport.added_bone_entries(model),
                abs_bone_mats if TemplateSources.is_stadium_chunk(model_number) else None)
            skipped_bones = CustomSubmeshImport.skipped_added_bone_ids(model)
            if skipped_bones:
                self.report(
                    {"WARNING"},
                    f"Added bone(s) {', '.join(str(b) for b in skipped_bones)} not imported: the parent "
                    "bone is not in the file. An export from this scene leaves them out.")
            assign_bone_collections(arm_obj)
            add_rest_pose_action(arm_obj)

        imported = 0
        for i, submesh in enumerate(submeshes):
            vb = submesh.get("VertexBuffer")
            if not vb:
                continue
            positions, normals = decode_vertex_buffer(vb)
            faces = decode_faces(submesh)
            uv_channels = submesh.get("UVChannels", [])
            color_channels = submesh.get("ColorChannels", [])
            face_texture_indices = decode_face_texture_indices(submesh, len(faces))
            mesh_name = f"{model_number}_{model_offset_hex}_submesh{i}"
            obj = build_mesh(mesh_name, positions, normals, faces, vb, collection,
                             uv_channels, color_channels,
                             face_texture_indices=face_texture_indices, sluggie_dir=sluggie_dir,
                             submesh_meta=submesh, texture_file_map=texture_file_map,
                             surface_texture_files=surface_texture_files)
            # The donor object stays on its donor bone as the "before" view;
            # the `_edit` object shows every edit, a bone move included, on
            # the effective owner (GeoIdEdited first).
            donor_owner, effective_owner = _submesh_owner_bones(bone_list or [], i)
            rebuilt = bool(submesh.get("RigidRebuild") or submesh.get("SkinnedRebuild"))
            skinned_influences = _skinned_rebuild_influences(submesh)
            original_owner, make_edit = _rigid_import_placement(submesh, donor_owner, effective_owner)
            if skinned_influences is None and not rebuilt and effective_owner == donor_owner:
                # Skin weights edited in place or by SkinDataEdited: the
                # `_edit` object carries them (the donor object keeps the
                # donor weights as the "before" view).
                skinned_influences = _edit_object_influences(i, bone_list, skin_edit)
                make_edit = make_edit or skinned_influences is not None
            if arm_obj is not None:
                add_vertex_groups(obj, i, bone_list, arm_obj)
                obj.parent = arm_obj
            else:
                _apply_import_rotation(obj)
            if bone_list:
                _apply_nonskinned_transform(obj, i, bone_list, abs_bone_mats, original_owner)
            # Facial pose edits belong to the `_edit` object when there is one (the donor object is the
            # "before" view); without one the donor object is the only place for them.
            ev = _edited_submesh_view(submesh) if make_edit else None
            has_edit_object = bool(ev and ev.get("VertexBuffer"))
            add_facial_shape_keys(
                obj, i, model.get("FacialPoseData"),
                None if has_edit_object else model.get("FacialPoseDataEdited")
            )
            imported += 1

            # Import the edited version of this submesh when one exists
            if make_edit:
                ev_vb = ev.get("VertexBuffer")
                if ev_vb:
                    edit_positions, edit_normals = decode_vertex_buffer(ev_vb)
                    edit_faces = decode_faces(ev)
                    edit_uv_channels = ev.get("UVChannels", [])
                    edit_color_channels = ev.get("ColorChannels", [])
                    edit_fti = decode_face_texture_indices(ev, len(edit_faces))

                    # Collect materials from the original mesh for reuse.
                    # New format: keyed by SurfaceId. Legacy format: keyed by tex_idx (int).
                    orig_materials = {}
                    for slot in obj.material_slots:
                        mat = slot.material
                        if mat is None:
                            continue
                        sid = mat.get("SurfaceId")
                        if sid:
                            orig_materials[sid] = mat
                        else:
                            try:
                                orig_materials[int(mat.name.rsplit('_mat', 1)[1])] = mat
                            except (IndexError, ValueError):
                                pass

                    face_surface_ids = ev.get("_FaceSurfaceIds")
                    if rebuilt:
                        orig_materials.update(_new_surface_materials(
                            mesh_name, submesh, i, model,
                            sluggie_dir, texture_file_map,
                        ))
                    edit_obj = build_mesh(
                        f"{mesh_name}_edit",
                        edit_positions, edit_normals, edit_faces,
                        vb, collection,
                        edit_uv_channels, edit_color_channels,
                        face_texture_indices=edit_fti,
                        sluggie_dir=None,
                        submesh_meta=ev,
                        prebuilt_materials=orig_materials or None,
                        texture_file_map=texture_file_map,
                        face_surface_ids=face_surface_ids,
                    )
                    if arm_obj is not None:
                        add_vertex_groups(
                            edit_obj, i, bone_list, arm_obj,
                            owner_bone_id=(
                                effective_owner
                                if skinned_influences is None and (rebuilt or effective_owner != donor_owner)
                                else None
                            ),
                            influences=skinned_influences,
                        )
                        edit_obj.parent = arm_obj
                    else:
                        _apply_import_rotation(edit_obj)
                    if bone_list:
                        _apply_nonskinned_transform(edit_obj, i, bone_list, abs_bone_mats, effective_owner)
                    rebuild = submesh.get("SkinnedRebuild") or submesh.get("RigidRebuild")
                    add_facial_shape_keys(
                        edit_obj, i, model.get("FacialPoseData"),
                        model.get("FacialPoseDataEdited"),
                        rebuild_poses=(rebuild.get("FacialPoses") or []) if rebuild else None,
                        rebuild_record_stride=12 if submesh.get("SkinnedRebuild") else 6,
                    )
                    imported += 1

        # Custom submeshes, placed with the bind matrices the exporter reads
        # them back with (BoneHierarchyEdited includes the added bones).
        custom_entries = model.get("CustomSubmeshes") or []
        if custom_entries and arm_obj is None:
            self.report({"WARNING"}, f"{len(custom_entries)} custom submesh(es) not imported: the model has no bones")
        elif custom_entries:
            bind_matrices = _compute_bone_absolute_matrices(model.get("BoneHierarchyEdited") or bone_list)
            for entry in custom_entries:
                try:
                    cs = CustomSubmeshImport.decode_custom_submesh(entry)
                except (KeyError, TypeError, ValueError, struct.error) as exc:
                    self.report({"WARNING"}, f"Custom submesh not imported: {exc}")
                    continue
                if cs.host_bone_id not in bind_matrices:
                    self.report({"WARNING"}, f"{cs.name}: host bone {cs.host_bone_id} does not exist; not imported")
                    continue
                for problem in cs.problems:
                    self.report({"WARNING"}, problem)
                build_custom_submesh(cs, model, arm_obj, bind_matrices, collection, sluggie_dir, texture_file_map)
                imported += 1

        collision_entries = StadiumCollisionExport.import_entries(model)
        if collision_entries and arm_obj is None:
            self.report({"WARNING"}, f"{len(collision_entries)} collision object(s) not imported: the model has no bones")
        elif collision_entries:
            original = [e for e in collision_entries if e.get('Region') is not None]
            col_collection = collection
            if original:
                # The stadium's own collision, in a collection of its own (hide it with one click).
                col_collection = bpy.data.collections.new(f"{arm_obj.name} collision")
                collection.children.link(col_collection)
            for entry in collision_entries:
                try:
                    build_collision_object(
                        entry, arm_obj, col_collection if entry.get('Region') is not None else collection)
                except (KeyError, ValueError, TypeError) as exc:
                    self.report({"WARNING"}, f"Collision object not imported: {exc}")

        context.view_layer.update()
        self.report({"INFO"}, f"Imported {imported} submesh(es) from {self.filepath}")
        return {"FINISHED"}


def menu_func_import(self, context):
    self.layout.operator(SLUGGIES_OT_import.bl_idname, text="Sluggers intermediate (.sluggie)")


class SLUGGIES_OT_import_anm(bpy.types.Operator, ImportHelper):
    bl_idname = "sluggies.import_anm"
    bl_label = "Import Sluggers animation"
    bl_description = "Import ANM animation files onto the selected armature"
    bl_options = {"UNDO"}

    filename_ext = ".anm"
    filter_glob: StringProperty(default="*.anm", options={"HIDDEN"})  # type: ignore[valid-type]
    # files + directory let the file browser take a multi-selection.
    files: CollectionProperty(type=bpy.types.OperatorFileListElement,  # type: ignore[valid-type]
                              options={'HIDDEN', 'SKIP_SAVE'})
    directory: StringProperty(subtype='DIR_PATH', options={'HIDDEN', 'SKIP_SAVE'})  # type: ignore[valid-type]

    def execute(self, context):
        arm_obj = context.active_object
        if arm_obj is None or arm_obj.type != 'ARMATURE':
            self.report({"ERROR"}, "Select an armature first")
            return {"CANCELLED"}

        arm_data = arm_obj.data
        if not any('track_id' in bone for bone in arm_data.bones):
            self.report({"ERROR"}, "Armature has no track_id data — import a .sluggie first")
            return {"CANCELLED"}

        track_to_bone = {}
        for bone in arm_data.bones:
            tid = bone.get('track_id', 0xFFFF)
            if tid != 0xFFFF:
                track_to_bone[tid] = bone.name

        # Reoriented bones need their keyframes moved onto the tail-aimed bone
        # frames; others share the game's rest frames (all stock rest scales
        # are 1). Armatures from before the "Reorient Bones" option (no
        # property) were reoriented.
        corrections = (_anm_bone_corrections(arm_data)
                       if arm_obj.get('SluggiesBonesReoriented', True) else None)

        if not self.files:
            file_list = [os.path.basename(self.filepath)]
        else:
            file_list = [f.name for f in self.files]

        if not arm_obj.animation_data:
            arm_obj.animation_data_create()

        # A script may call the operator with only filepath: directory is empty then.
        directory = self.directory or os.path.dirname(self.filepath)
        total_actions = 0
        for file_entry in file_list:
            filepath = os.path.join(directory, file_entry)
            anm_name = os.path.splitext(file_entry)[0]

            try:
                with open(filepath, 'rb') as f:
                    raw = f.read()
            except OSError as e:
                # Skipped, so the files before and after it are still imported.
                self.report({"WARNING"}, f"{file_entry}: could not be read ({e})")
                continue

            try:
                anm = AnmFormat.parse(raw)
            except (ValueError, struct.error) as e:
                self.report({"WARNING"}, f"{file_entry}: {e}")
                continue
            sequences = anm['sequences']
            group = anm_name

            for seq_i, sequence in enumerate(sequences):
                action_name = f"{anm_name}_seq{seq_i}"
                action = bpy.data.actions.new(name=action_name)
                action.use_fake_user = True
                _store_anm_metadata(action, anm, group, filepath, seq_i, set(track_to_bone))
                arm_obj.animation_data.action = action
                keyed = set()

                for track in sequence:
                    tid = track['track_id']
                    bone_name = track_to_bone.get(tid)
                    if bone_name is None:
                        continue

                    pose_bone = arm_obj.pose.bones.get(bone_name)
                    if pose_bone is None:
                        continue

                    bone_mat = pose_bone.bone.matrix_local
                    if pose_bone.parent:
                        E_local = pose_bone.parent.bone.matrix_local.inverted() @ bone_mat
                    else:
                        E_local = bone_mat
                    inv_E_local = E_local.inverted()
                    if corrections is not None:
                        inv_C_parent = (corrections[pose_bone.parent.name].inverted()
                                        if pose_bone.parent else mathutils.Matrix.Identity(4))
                        C_bone = corrections[bone_name]

                    rest_trans, rest_quat, rest_scale = game_rest_srt(arm_data.bones[bone_name])

                    pose_bone.rotation_mode = 'QUATERNION'
                    data_path_loc = f'pose.bones["{bone_name}"].location'
                    data_path_rot = f'pose.bones["{bone_name}"].rotation_quaternion'
                    data_path_scl = f'pose.bones["{bone_name}"].scale'

                    fc_loc = [action.fcurve_ensure_for_datablock(arm_obj, data_path_loc, index=i) for i in range(3)]
                    fc_rot = [action.fcurve_ensure_for_datablock(arm_obj, data_path_rot, index=i) for i in range(4)]
                    fc_scl = [action.fcurve_ensure_for_datablock(arm_obj, data_path_scl, index=i) for i in range(3)]

                    for kf in track['keys']:
                        frame = kf['time']
                        settings = kf['settings']

                        trans = settings.get(0, rest_trans)
                        scale = settings.get(1, rest_scale)
                        quat = settings.get(3, rest_quat)

                        L_anm = _game_srt_matrix(trans, quat, scale)

                        # Keyframes are game-space locals (child in game parent
                        # frame); the rest SRT gives identity either way.
                        if corrections is not None:
                            matrix_basis = inv_E_local @ inv_C_parent @ L_anm @ C_bone
                        else:
                            matrix_basis = inv_E_local @ L_anm
                        loc, rot_q, scl = matrix_basis.decompose()

                        for i in range(3):
                            fc_loc[i].keyframe_points.insert(frame, loc[i], options={'FAST'})
                        for i in range(4):
                            fc_rot[i].keyframe_points.insert(frame, rot_q[i], options={'FAST'})
                        for i in range(3):
                            fc_scl[i].keyframe_points.insert(frame, scl[i], options={'FAST'})

                    for fc in fc_loc + fc_rot + fc_scl:
                        fc.update()
                    keyed.add(bone_name)

                # The game holds a bone without a track at its rest pose. Key
                # it there, so switching to this action does not keep the
                # pose another action left on it.
                for pose_bone in arm_obj.pose.bones:
                    if pose_bone.name in keyed:
                        continue
                    pose_bone.rotation_mode = 'QUATERNION'
                    for prop, values in (('location', (0.0, 0.0, 0.0)),
                                         ('rotation_quaternion', (1.0, 0.0, 0.0, 0.0)),
                                         ('scale', (1.0, 1.0, 1.0))):
                        data_path = f'pose.bones["{pose_bone.name}"].{prop}'
                        for i, value in enumerate(values):
                            fc = action.fcurve_ensure_for_datablock(arm_obj, data_path, index=i)
                            fc.keyframe_points.insert(0, value, options={'FAST'})

                total_actions += 1

        self.report({"INFO"}, f"Imported {total_actions} animation action(s)")
        return {"FINISHED"}


def _store_anm_metadata(action, anm, group, filepath, seq_index, bone_track_ids):
    """What the .anm export needs to write this sequence back: the group,
    the sequence's place in it, and its original track list (tracks of
    armature bones keep only their header, the rest their data)."""
    records = AnmFormat.track_records(anm['sequences'][seq_index], bone_track_ids)
    action['SluggiesAnmGroup'] = group
    action['SluggiesAnmSource'] = filepath
    action['SluggiesAnmMagic'] = anm['magic']
    action['SluggiesAnmBankId'] = anm['bank_id']
    action['SluggiesAnmSequence'] = seq_index
    action['SluggiesAnmSequenceCount'] = len(anm['sequences'])
    action['SluggiesAnmTracks'] = FieldCodec.encode_compact(AnmFormat.dumps_records(records))
    # The sequence length, editable as the action's manual frame range.
    length = max((t['length'] for t in anm['sequences'][seq_index]), default=0.0)
    action.use_frame_range = True
    action.frame_start = 0
    action.frame_end = max(length, 1.0)


def menu_func_import_anm(self, context):
    self.layout.operator(SLUGGIES_OT_import_anm.bl_idname, text="Sluggers animation (.anm)")


def register():
    bpy.utils.register_class(SLUGGIES_OT_import)
    bpy.utils.register_class(SLUGGIES_OT_import_anm)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import_anm)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import_anm)
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    bpy.utils.unregister_class(SLUGGIES_OT_import_anm)
    bpy.utils.unregister_class(SLUGGIES_OT_import)
