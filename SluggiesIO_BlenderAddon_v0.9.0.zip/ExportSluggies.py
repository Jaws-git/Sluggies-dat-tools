import bpy
import contextlib
import copy
import json
import math
import os
import re
import shutil
import struct
from dataclasses import dataclass
from bpy.props import BoolProperty, StringProperty
from bpy_extras.io_utils import ExportHelper

from .SkinWeights import quantize_skin_weights, MAX_BONE_INFLUENCES_PER_VERTEX
from .HostBones import compute_rigid_retargets, GEO_ID_FREE
from . import AnmExport
from . import CustomSubmeshExport
from . import ExportMode
from . import FieldCodec
from . import RigidRebuildExport
from . import SkinnedRebuildExport
from . import TemplateSources
from . import TextureConvert
from . import TextureSlotsCore
from . import HostBones
from . import ModelCheckCore
from . import SluggiePath
from . import StadiumCollisionExport


def _to_bytes(data) -> bytes:
    """Decode a binary field: ``x:`` hex string (legacy: base64 or ``z:`` zlib) or a list of byte values."""
    return FieldCodec.decode_field(data)


def _from_bytes(raw: bytes, use_compression: bool = True):
    """Encode binary data as an ``x:`` hex string, or a list of byte values in a --debug file."""
    return FieldCodec.encode_field(raw, use_compression)


def _pack_quantized_component(value, divisor, context):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{context}: coordinate/component is not finite ({value})")
    quantized = round(value * divisor)
    if not -32768 <= quantized <= 32767:
        minimum = -32768 / divisor
        maximum = 32767 / divisor
        raise ValueError(
            f"{context}: value {value} quantizes to {quantized}, outside int16 "
            f"range [-32768, 32767] (representable coordinates {minimum}..{maximum})"
        )
    return struct.pack('>h', quantized)

REQUIRED_PROPS = (
    "VertexBufferOffset",
    "VertexBufferLength",
    "VertexBufferCompCount",
    "VertexBufferQuantizeInfo",
)


def _get_custom_split_normals(obj):
    """Return per-vertex averaged custom split normals as a list of Vector, or None.

    Returns None when the mesh has no custom normals data (``has_custom_normals``
    is False).  When normals are present the loop normals are averaged per vertex
    so they map 1-to-1 with vertex indices, matching the interleaved XYZ+NxNyNz
    layout the game uses.
    """
    from mathutils import Vector
    mesh = obj.data
    if not mesh.has_custom_normals:
        return None
    vert_normals = [Vector((0.0, 0.0, 0.0)) for _ in mesh.vertices]
    vert_counts  = [0] * len(mesh.vertices)
    for loop in mesh.loops:
        vert_normals[loop.vertex_index] += Vector(loop.normal)
        vert_counts[loop.vertex_index]  += 1
    return [
        (vert_normals[i] / vert_counts[i]).normalized() if vert_counts[i] else Vector((0.0, 0.0, 1.0))
        for i in range(len(mesh.vertices))
    ]


# Blender stores imported normals at lower precision than the donor's
# quantized ints, so an untouched normal re-quantizes up to a few steps off
# (measured: <= 0.02 deg, up to 5 steps at shift 14). Anything this close to
# its donor value is round-trip noise, not an edit.
_NORMAL_ROUNDTRIP_MIN_COS = math.cos(math.radians(0.1))


def _decode_donor_components(record, comp_size, divisor, is_float):
    fmt = '>f' if is_float else '>h'
    values = [
        struct.unpack_from(fmt, record, offset)[0]
        for offset in range(0, len(record), comp_size)
    ]
    return values if is_float else [value / divisor for value in values]


def _normal_is_donor_roundtrip(normal, donor_normal):
    """True when *normal* is *donor_normal* after Blender's precision loss.

    A zero-length donor normal (unused/degenerate vertex) always counts:
    Blender cannot represent it and substitutes an arbitrary unit normal.
    """
    donor_length = math.sqrt(sum(c * c for c in donor_normal))
    if donor_length < 1e-8:
        return True
    length = math.sqrt(sum(c * c for c in normal))
    if length < 1e-8:
        return False
    cos = sum(a * b for a, b in zip(normal, donor_normal)) / (length * donor_length)
    return cos >= _NORMAL_ROUNDTRIP_MIN_COS


def encode_vertex_buffer_edited(obj, comp_count, quant_info, use_custom_normals=False,
                                use_compression=True, donor_data=None):
    """Re-quantize edited vertex positions (and normals if comp_count==6)
    back into the original binary format and return an encoded binary field (hex string or byte list).

    With *donor_data* (the donor VertexBufferData) and an unchanged vertex
    count, interleaved normals keep their donor bytes: always when
    *use_custom_normals* is off, and otherwise when Blender's normal is only
    round-trip noise away from the donor value.
    """
    mesh = obj.data
    fmt_nibble = quant_info >> 4
    shift = quant_info & 0xF
    divisor = 1 << shift
    is_float = fmt_nibble in [4, 7, 0xa]
    comp_size = 4 if is_float else 2
    stride = comp_count * comp_size

    donor_raw = _to_bytes(donor_data) if (donor_data is not None and comp_count >= 6) else None
    if donor_raw is not None and len(donor_raw) != len(mesh.vertices) * stride:
        donor_raw = None

    custom_normals = _get_custom_split_normals(obj) if (use_custom_normals and comp_count >= 6) else None
    basis_key = None
    if mesh.shape_keys:
        basis_key = mesh.shape_keys.key_blocks.get("Basis")

    raw_bytes = bytearray()
    for v in mesh.vertices:
        position = basis_key.data[v.index].co if basis_key is not None else v.co
        comps = [position.x, position.y, position.z]
        donor_normal_bytes = None
        if comp_count >= 6:
            if custom_normals is not None:
                n = custom_normals[v.index]
                comps += [n.x, n.y, n.z]
            else:
                comps += [v.normal.x, v.normal.y, v.normal.z]
            if donor_raw is not None:
                record = donor_raw[v.index * stride:(v.index + 1) * stride]
                normal_bytes = record[3 * comp_size:6 * comp_size]
                if custom_normals is None or _normal_is_donor_roundtrip(
                    comps[3:6],
                    _decode_donor_components(normal_bytes, comp_size, divisor, is_float),
                ):
                    donor_normal_bytes = normal_bytes
                    comps = comps[:3]
        component_names = ('x', 'y', 'z', 'nx', 'ny', 'nz')
        for component_index, val in enumerate(comps):
            if is_float:
                if not math.isfinite(float(val)):
                    raise ValueError(
                        f"{obj.name} vertex {v.index} {component_names[component_index]}: "
                        f"coordinate/component is not finite ({val})"
                    )
                raw_bytes += struct.pack('>f', val)
            else:
                raw_bytes += _pack_quantized_component(
                    val,
                    divisor,
                    f"{obj.name} vertex {v.index} {component_names[component_index]}",
                )
        if donor_normal_bytes is not None:
            raw_bytes += donor_normal_bytes

    return _from_bytes(bytes(raw_bytes), use_compression)


def _facial_vertex_indices(attribute):
    indices = []
    for run in attribute.get("Runs", []):
        first = run.get("FirstVertex", 0)
        count = run.get("VertexCount", 0)
        indices.extend(range(first, first + count))
    return indices


def _encode_facial_key(
    key, pose_zero_data, source_pose_data, indices, pose_index, quant_info,
    component_count, component_size,
):
    if component_size != 2 or component_count < 3:
        return None
    divisor = 1 << (quant_info & 0xF)
    stride = component_count * component_size
    pose_zero_raw = _to_bytes(pose_zero_data)
    raw = bytearray(_to_bytes(source_pose_data))
    if len(raw) != len(indices) * stride or len(pose_zero_raw) != len(indices) * stride:
        return None
    for mapped_index, vertex_index in enumerate(indices):
        coordinate = key.data[vertex_index].co
        if pose_index == 0:
            values = coordinate
        else:
            imported_pose_zero = struct.unpack_from(
                '>3h', pose_zero_raw, mapped_index * stride
            )
            values = tuple(
                coordinate[axis] - imported_pose_zero[axis] / divisor
                for axis in range(3)
            )
        for component, value in enumerate(values):
            quantized = max(-32768, min(32767, round(value * divisor)))
            struct.pack_into(
                '>h', raw, mapped_index * stride + component * component_size,
                quantized,
            )
    return bytes(raw)


def encode_facial_pose_edits(
    obj, facial_data, submesh_index, use_compression=True, facial_edited=None
):
    """Return sparse position-pose edits for one submesh's Blender shape keys."""
    if not facial_data or not obj.data.shape_keys:
        return []
    key_blocks = obj.data.shape_keys.key_blocks
    basis_key = key_blocks.get("Basis")
    if basis_key is None:
        return []
    quant_info = obj.get("VertexBufferQuantizeInfo", 0)
    edited_lookup = {
        (facial_object.get("ObjectIndex"), pose.get("PoseIndex")): pose.get("PoseData")
        for facial_object in (facial_edited or {}).get("Objects", [])
        for pose in facial_object.get("PositionPoseEdits", [])
    }
    object_edits = []

    for facial_object in facial_data.get("Objects", []):
        if facial_object.get("SubmeshIndex") != submesh_index:
            continue
        position = facial_object.get("Position", {})
        indices = _facial_vertex_indices(position)
        if not indices or max(indices) >= len(obj.data.vertices):
            continue
        original_poses = position.get("PoseData", [])
        object_index = facial_object.get("ObjectIndex")
        pose_count = facial_object.get("PoseCount", facial_data.get("PoseCount", 0))
        pose_zero_data = edited_lookup.get(
            (object_index, 0), original_poses[0] if original_poses else None
        )
        if pose_zero_data is None:
            continue
        pose_edits = []
        for pose_index in range(pose_count):
            key = basis_key if pose_index == 0 else key_blocks.get(
                f"facial_object_{facial_object.get('ObjectIndex')}_pose_{pose_index}"
            )
            if key is None or pose_index >= len(original_poses):
                continue
            source_pose_data = edited_lookup.get(
                (object_index, pose_index), original_poses[pose_index]
            )
            edited_raw = _encode_facial_key(
                key, pose_zero_data, source_pose_data, indices, pose_index,
                quant_info, position.get("ComponentCount", 3),
                position.get("ComponentSize", 2),
            )
            if edited_raw is None:
                continue
            if edited_raw != _to_bytes(original_poses[pose_index]):
                pose_edits.append({
                    "PoseIndex": pose_index,
                    "PoseData": _from_bytes(edited_raw, use_compression),
                })
        if pose_edits:
            object_edits.append({
                "ObjectIndex": facial_object.get("ObjectIndex"),
                "PositionPoseEdits": pose_edits,
            })
    return object_edits


def update_facial_pose_edits(candidates, data, warnings):
    """Replace edits for selected facial submeshes and preserve unselected edits."""
    model = data.get("SluggiesModel", {})
    facial_data = model.get("FacialPoseData")
    if not facial_data:
        model.pop("FacialPoseDataEdited", None)
        return

    submeshes = model.get("Submeshes", [])
    use_compression = model.get("UseCompression", True)
    selected = {}
    for obj in candidates:
        submesh_index = next((
            index for index, submesh in enumerate(submeshes)
            if str(obj.get("VertexBufferOffset"))
            == str(submesh.get("VertexBuffer", {}).get("VertexBufferOffset"))
        ), None)
        if submesh_index is not None:
            selected[submesh_index] = obj

    selected_object_indices = {
        entry.get("ObjectIndex") for entry in facial_data.get("Objects", [])
        if entry.get("SubmeshIndex") in selected
    }
    retained = [
        entry for entry in model.get("FacialPoseDataEdited", {}).get("Objects", [])
        if entry.get("ObjectIndex") not in selected_object_indices
    ]
    generated = []
    for submesh_index, obj in selected.items():
        if any(entry.get("SubmeshIndex") == submesh_index
               for entry in facial_data.get("Objects", [])):
            if not obj.data.shape_keys:
                warnings.append(
                    f"{obj.name}: facial shape keys are missing; existing facial edits cleared."
                )
            generated.extend(encode_facial_pose_edits(
                obj, facial_data, submesh_index, use_compression,
                model.get("FacialPoseDataEdited"),
            ))

    edits = retained + generated
    if edits:
        model["FacialPoseDataEdited"] = {"Objects": edits}
    else:
        model.pop("FacialPoseDataEdited", None)


def _find_root_scale_armature(candidates, context):
    """Return the imported armature object that carries the ``RootBoneScale``
    custom property, or None.

    The importer parents every skinned mesh to the armature, so the primary
    lookup walks up each candidate's parent chain. A scene-wide fallback covers
    the edge case where the mesh was reparented or the armature is simply
    selected without its meshes.
    """
    for obj in candidates:
        node = obj
        while node is not None:
            if node.type == 'ARMATURE' and "RootBoneScale" in node:
                return node
            node = node.parent
    for obj in context.scene.objects:
        if obj.type == 'ARMATURE' and "RootBoneScale" in obj:
            return obj
    return None


def encode_root_bone_scale_edited(candidates, data, warnings, context):
    """Read the armature's ``RootBoneScale`` and, when it differs from the
    unit scale [1, 1, 1], write it to ``SluggiesModel.RootBoneScaleEdited``.

    The field is popped when the scale is unchanged so an untouched import
    never writes it back. Returns the written 3-element scale list, or None
    when nothing was written (no armature found, or scale already unit).
    """
    model = data.get("SluggiesModel", {})
    arm_obj = _find_root_scale_armature(candidates, context)
    if arm_obj is None:
        model.pop("RootBoneScaleEdited", None)
        return None

    scale = arm_obj["RootBoneScale"]
    if scale is None or len(scale) != 3:
        warnings.append(
            f"{arm_obj.name}: RootBoneScale must be a 3-element vector; "
            "root-bone scale export skipped."
        )
        model.pop("RootBoneScaleEdited", None)
        return None

    value = [float(scale[0]), float(scale[1]), float(scale[2])]
    if value == [1.0, 1.0, 1.0]:
        model.pop("RootBoneScaleEdited", None)
        return None

    model["RootBoneScaleEdited"] = value
    return value


_BONE_NAME_RE = re.compile(r'^bone_(\d+)$')


def _bone_id_from_bone_name(name):
    """bone_<id> -> id, else None. Mirrors SluggiesToolsPanel._bone_id_from_name;
    duplicated here rather than imported to avoid a circular import (that
    module imports from this one)."""
    m = _BONE_NAME_RE.match(name or '')
    return int(m.group(1)) if m else None


def armature_has_new_bones(candidates, context):
    """Whether the .sluggie's armature carries any Add Bone bone; such a
    model is always exported in Hammerspace mode."""
    arm_obj = _find_root_scale_armature(candidates, context)
    if arm_obj is None:
        return False
    return any(b.get('SluggiesUserAdded') for b in arm_obj.data.bones)


SRT_TYPE_ROTATION = 0x4
SRT_TYPE_TRANSLATION = 0x8


def _srt_type_for(bone_name, translation, rotation, scale, warnings):
    """The SRT block's type byte for one new bone, derived from the values
    actually being written.

    The byte is a component-presence mask, not a free-form tag: bit 0x4 means
    "rotation is live", bit 0x8 means "translation is live", and the game
    ignores whichever component its bit doesn't claim. Surveyed over the
    player corpus, all 1,469 vanilla `SRTType 8` bones have an identity
    rotation and all 1,903 `SRTType 12` bones have a non-identity one, with no
    exceptions either way.

    So this cannot be inherited from the parent bone: a bone that copies its
    parent's `8` while carrying a real rotation has that rotation silently
    dropped in game, and the mesh riding it lands somewhere the user never saw
    in Blender.
    """
    srt_type = 0
    if abs(abs(rotation.w) - 1.0) > 1e-6 or any(
        abs(v) > 1e-6 for v in (rotation.x, rotation.y, rotation.z)
    ):
        srt_type |= SRT_TYPE_ROTATION
    if any(abs(v) > 1e-6 for v in (translation.x, translation.y, translation.z)):
        srt_type |= SRT_TYPE_TRANSLATION
    if any(abs(v - 1.0) > 1e-6 for v in (scale.x, scale.y, scale.z)):
        warnings.append(
            f"{bone_name}: bone scale is not 1; no vanilla bone carries one and the "
            "SRT type byte has no known scale bit, so the scale is exported but the "
            "game is expected to ignore it."
        )
    return srt_type


def added_bone_name_error(candidates, context):
    """Error text when an Add Bone bone's ``bone_<N>`` name differs from the id
    ``encode_bone_hierarchy_edited`` assigns it, else None."""
    arm_obj = _find_root_scale_armature(candidates, context)
    if arm_obj is None:
        return None
    bones = arm_obj.data.bones
    donor_count = sum(1 for b in bones if not b.get('SluggiesUserAdded'))
    return HostBones.added_bone_name_error(HostBones.added_bone_renames(donor_count, [
        (b.name, int(b.get('SluggiesCreationOrder', 0)))
        for b in bones if b.get('SluggiesUserAdded')
    ]))


def encode_bone_hierarchy_edited(candidates, data, warnings, context):
    """Write ``SluggiesModel.BoneHierarchyEdited`` when the target armature has
    any Add Bone leaf.

    Every donor bone is carried through unchanged (the patcher's validation
    is append-only), and every ``SluggiesUserAdded`` bone is assigned ids
    ``N, N+1, ...`` in ``SluggiesCreationOrder`` (the Blender bone *name* has
    no binary meaning). Each new bone's
    Blender rest matrix is converted to a local T/R/S against its parent,
    reusing the same bind-matrix convention
    ``CustomSubmeshExport.bone_local_matrix`` decodes back (T @ R @ S,
    quaternion stored as ``[-qw, qx, qy, qz]``).
    """
    model = data.get("SluggiesModel", {})
    arm_obj = _find_root_scale_armature(candidates, context)
    if arm_obj is None:
        model.pop("BoneHierarchyEdited", None)
        return

    new_bones = [b for b in arm_obj.data.bones if b.get('SluggiesUserAdded')]
    if not new_bones:
        model.pop("BoneHierarchyEdited", None)
        return

    donor_bones = model.get("BoneHierarchy") or []
    if not donor_bones:
        warnings.append(
            f"{arm_obj.name}: model has no BoneHierarchy; added bone(s) not exported."
        )
        model.pop("BoneHierarchyEdited", None)
        return

    donor_count = len(donor_bones)
    new_bones.sort(key=lambda b: (int(b.get('SluggiesCreationOrder', 0)), b.name))

    id_by_bone_name = {
        b.name: _bone_id_from_bone_name(b.name)
        for b in arm_obj.data.bones if not b.get('SluggiesUserAdded')
    }
    id_by_bone_name = {name: bid for name, bid in id_by_bone_name.items() if bid is not None}
    next_id = donor_count
    for b in new_bones:
        id_by_bone_name[b.name] = next_id
        next_id += 1

    edited = []
    for donor_bone in donor_bones:
        entry = dict(donor_bone)
        entry["UserAdded"] = False
        edited.append(entry)

    stadium = TemplateSources.is_stadium_chunk(model.get("ChunkNumber"))
    donor_absolute = CustomSubmeshExport.bone_absolute_matrices(donor_bones) if stadium else {}
    for b in new_bones:
        own_id = id_by_bone_name[b.name]
        parent = b.parent
        if parent is None and stadium:
            # A new stadium root bone: armature space is the game's model
            # space, so its rest matrix is its SRT.
            parent_id = None
            local = b.matrix_local
        elif parent is None or parent.name not in id_by_bone_name:
            warnings.append(f"{b.name}: has no valid parent bone; not exported.")
            continue
        elif stadium:
            # A new stadium child bone: relative to the parent's GAME frame, so the
            # bone sits in game where it sits in Blender (its game rest matrix is
            # its Blender rest matrix, like a new root's). A donor parent's game
            # frame is its BoneHierarchy SRT chain; a new parent's is its own
            # Blender rest matrix (Blender's display frame of a donor bone is
            # reoriented and differs from the game's).
            parent_id = id_by_bone_name[parent.name]
            if parent.get('SluggiesUserAdded'):
                parent_game = parent.matrix_local
            else:
                from mathutils import Matrix
                parent_game = Matrix(donor_absolute[parent_id])
            local = parent_game.inverted() @ b.matrix_local
        else:
            parent_id = id_by_bone_name[parent.name]
            local = parent.matrix_local.inverted() @ b.matrix_local
        translation, rotation, scale = local.decompose()
        geo_id_raw = int(b.get('SluggiesGeoIdRaw', GEO_ID_FREE))
        srt_type = _srt_type_for(b.name, translation, rotation, scale, warnings)

        edited.append({
            "BoneId": own_id,
            "GeoId": geo_id_raw,
            "GeoIdRaw": geo_id_raw,
            "ParentBoneId": parent_id,
            "Skinned": bool(b.get('SluggiesSkinned', False)),
            "TrackId": int(b.get('track_id', 0xFFFF)),
            "MirrorBoneId": own_id,
            "MirrorRole": 3,
            "SRTType": srt_type,
            "DrawPriority": int(b.get('SluggiesDrawPriority', 0)),
            "InheritTransform": bool(b.get('SluggiesInheritTransform', True)),
            "UserAdded": True,
            "Translation": [round(translation.x, 6), round(translation.y, 6), round(translation.z, 6)],
            "Scale": [round(scale.x, 6), round(scale.y, 6), round(scale.z, 6)],
            "Quaternion": [
                round(-rotation.w, 6), round(rotation.x, 6),
                round(rotation.y, 6), round(rotation.z, 6),
            ],
            "VertexInfluences": [],
        })

    model["BoneHierarchyEdited"] = edited


def untracked_keys_warnings(candidates, context):
    """Warnings for added bones that imported .anm actions (or the armature's
    active action) move although they have no animation track: their TrackId
    stays 0xFFFF and the .anm export skips them, so the motion never reaches
    the game."""
    arm_obj = _find_root_scale_armature(candidates, context)
    if arm_obj is None:
        return []
    actions = [a for group in AnmExport.anm_groups().values() for a in group]
    if arm_obj.animation_data is not None and arm_obj.animation_data.action not in actions:
        actions.append(arm_obj.animation_data.action)
    return AnmExport.untracked_keys_warnings(arm_obj, actions)


# --- Blender-side pre-check for the donor-topology rules
# HammerspaceMain._validate_bone_hierarchy_edited enforces authoritatively
# (act_section.html#appending-bones). This is a courtesy check so a mistake
# is visible while the user can still see and undo it in Blender; it is not
# a substitute for the patcher's own gate. Sibling-chain order is not in the
# .sluggie at all, so neither check can see it; the patcher's rebuilder keeps
# donor chains intact by construction.
def validate_bone_hierarchy_edited_export(model, warnings):
    """Return a list of blocking error strings for ``BoneHierarchyEdited``, or
    an empty list when nothing is wrong."""
    bone_hierarchy_edited = model.get("BoneHierarchyEdited")
    if not bone_hierarchy_edited:
        return []

    errors = []
    donor_bones = model.get("BoneHierarchy") or []
    donor_by_id = {int(b["BoneId"]): b for b in donor_bones}
    edited_by_id = {int(b["BoneId"]): b for b in bone_hierarchy_edited}
    new_ids = {int(b["BoneId"]) for b in bone_hierarchy_edited if b.get("UserAdded")}

    for bone_id, donor_bone in donor_by_id.items():
        edited_bone = edited_by_id.get(bone_id)
        if edited_bone is None:
            errors.append(f"donor bone {bone_id} is missing (donor bones cannot be deleted)")
            continue
        if edited_bone.get("UserAdded"):
            errors.append(f"donor bone {bone_id} is marked as a new bone")
            continue
        donor_parent = donor_bone.get("ParentBoneId")
        edited_parent = edited_bone.get("ParentBoneId")
        donor_parent_id = None if donor_parent is None else int(donor_parent)
        edited_parent_id = None if edited_parent is None else int(edited_parent)
        if donor_parent_id != edited_parent_id:
            if edited_parent_id in new_ids:
                errors.append(
                    f"new bone {edited_parent_id} was inserted between donor bones "
                    f"{donor_parent_id} and {bone_id}; new bones can only hang off "
                    "the tree as leaves"
                )
            else:
                errors.append(
                    f"donor bone {bone_id} was reparented from {donor_parent_id} "
                    f"to {edited_parent_id}"
                )

    stadium = TemplateSources.is_stadium_chunk(model.get("ChunkNumber"))
    for bone_id in sorted(new_ids):
        parent_id = edited_by_id[bone_id].get("ParentBoneId")
        if not stadium and parent_id is None:
            errors.append(f"new bone {bone_id} has no parent; new bones may not be roots outside stadiums")

    return errors


def _uv_layer_name(all_channels, target_ch_ind):
    """Return the Blender UV layer name for *target_ch_ind*: ``"uv<position>"``,
    the name ImportSluggies gives each channel's layer."""
    for enum_ind, ch in enumerate(all_channels):
        if ch.get('UVChannelIndex', enum_ind) == target_ch_ind:
            return f'uv{enum_ind}'
    return f'uv{target_ch_ind}'


def _legacy_uv_layer_name(all_channels, target_ch_ind):
    """Return the UV layer name older imports used: the channel's PaletteName,
    or ``"uv<position>"`` when it was empty or already taken."""
    used = set()
    for enum_ind, ch in enumerate(all_channels):
        idx = ch.get('UVChannelIndex', enum_ind)
        palette = ch.get('PaletteName') or ''
        raw = palette or f'uv{enum_ind}'
        name = raw if raw not in used else f'uv{enum_ind}'
        used.add(name)
        if idx == target_ch_ind:
            return name
    return f'uv{target_ch_ind}'


def _find_uv_layer(mesh, all_channels, target_ch_ind):
    """Return *mesh*'s UV layer for *target_ch_ind*, falling back to the
    PaletteName-based name of .blend files imported before 2026-10-11, and
    for the first channel ("uv0") to the render-active (else active) layer
    when no other channel claims that layer's name."""
    name = _uv_layer_name(all_channels, target_ch_ind)
    layer = mesh.uv_layers.get(name)
    if layer is None:
        layer = mesh.uv_layers.get(_legacy_uv_layer_name(all_channels, target_ch_ind))
    if layer is None and name == 'uv0':
        active = mesh.uv_layers.active_render or mesh.uv_layers.active
        if active is not None:
            claimed = set()
            for ch in all_channels:
                idx = ch.get('UVChannelIndex', 0)
                if idx != target_ch_ind:
                    claimed.add(_uv_layer_name(all_channels, idx))
                    claimed.add(_legacy_uv_layer_name(all_channels, idx))
            if active.name not in claimed:
                layer = active
    return layer


def encode_uv_channel_edited(obj, json_channel, use_compression=True, all_uv_channels=None):
    """Re-quantize Blender UV layer back into the game's ST coordinate format.

    Writes each Blender UV value back into its ORIGINAL slot position, using
    UVFacesData to look up which slot index the draw list expects for each face
    loop. This preserves the original coord-array layout so the unmodified draw
    list in the .dat file keeps working correctly.

    Returns uv_channel_data_enc, or None if the matching UV layer is not found.
    Warns (via returned string list) when a slot receives two conflicting values
    (i.e. the user split a UV seam that was previously shared).
    """
    ch_ind = json_channel.get("UVChannelIndex", 0)
    mesh_data = obj.data
    if all_uv_channels is not None:
        uv_layer = _find_uv_layer(mesh_data, all_uv_channels, ch_ind)
    else:
        uv_layer = (mesh_data.uv_layers.get(f"uv{ch_ind}")
                    or mesh_data.uv_layers.get(json_channel.get("PaletteName", "") or f"uv{ch_ind}"))
        if uv_layer is None and ch_ind == 0:
            uv_layer = mesh_data.uv_layers.active_render or mesh_data.uv_layers.active
    if uv_layer is None:
        return None

    quant_info = json_channel["UVChannelQuantizeInfo"]
    comp_count = json_channel["UVChannelCompCount"]
    expected_length = json_channel["UVChannelLength"]
    fmt_nibble = quant_info >> 4
    shift = quant_info & 0xF
    divisor = 1 << shift
    is_float = fmt_nibble in [4, 7, 0xa]
    comp_size = 4 if is_float else 2
    num_slots = expected_length // (comp_count * comp_size)

    # Decode original per-face UV slot indices from UVFacesData
    uv_faces_raw = _to_bytes(json_channel["UVFacesData"])
    n = len(uv_faces_raw) // 2
    flat = list(struct.unpack(f'>{n}H', uv_faces_raw))
    original_uv_faces = [flat[i * 3 : i * 3 + 3] for i in range(n // 3)]

    # Fill output slots using original slot assignments
    # Each slot is (qs, qt); None means the slot was never referenced by a loop.
    output_slots = [None] * num_slots
    conflicts = []

    for poly in mesh_data.polygons:
        face_idx = poly.index
        if face_idx >= len(original_uv_faces):
            continue
        uv_tri = original_uv_faces[face_idx]
        for loop_offset, loop_idx in enumerate(poly.loop_indices):
            uv_slot = uv_tri[loop_offset % 3]
            uv = uv_layer.data[loop_idx].uv
            s = uv.x
            t = 1.0 - uv.y  # undo Blender V-flip applied on import
            if is_float:
                qs, qt = s, t
            else:
                qs = round(s * divisor)
                qt = round(t * divisor)
            if output_slots[uv_slot] is None:
                output_slots[uv_slot] = (qs, qt)
            elif output_slots[uv_slot] != (qs, qt):
                conflicts.append(uv_slot)

    # Fall back to original data for any slot not touched by a loop.
    # Store raw quantized values (int16 for integer format, float for float format)
    # so they stay in the same units as active slots and re-encode correctly.
    if None in output_slots:
        orig_raw = _to_bytes(json_channel["UVChannelData"])
        for slot_idx, val in enumerate(output_slots):
            if val is None:
                off = slot_idx * comp_count * comp_size
                os_ = struct.unpack_from('>f' if is_float else '>h', orig_raw, off)[0]
                ot_ = struct.unpack_from('>f' if is_float else '>h', orig_raw, off + comp_size)[0]
                output_slots[slot_idx] = (os_, ot_)

    # Encode the coord array in original slot order
    raw_bytes = bytearray()
    for slot_index, (qs, qt) in enumerate(output_slots):
        comps = [qs, qt] + [0.0] * (comp_count - 2)
        for component_index, val in enumerate(comps):
            if is_float:
                if not math.isfinite(float(val)):
                    raise ValueError(
                        f"{obj.name} UV{ch_ind} slot {slot_index} component "
                        f"{component_index}: value is not finite ({val})"
                    )
                raw_bytes += struct.pack('>f', float(val))
            else:
                raw_bytes += _pack_quantized_component(
                    int(val) / divisor,
                    divisor,
                    f"{obj.name} UV{ch_ind} slot {slot_index} component {component_index}",
                )

    return _from_bytes(bytes(raw_bytes), use_compression), conflicts


def _per_loop_normals(mesh, loop_indices):
    """Per-loop normals for *loop_indices*.

    Uses Blender loop normals (custom split normals when the mesh has them,
    geometric face normals otherwise). Loops with a degenerate (zero-length)
    custom normal — e.g. new loops created by mesh edits before the user
    re-applies smooth shading — fall back to the face normal so something
    usable is always exported.
    """
    result = []
    for loop_idx in loop_indices:
        n = mesh.loops[loop_idx].normal
        if n.length_squared < 1e-8:
            n = mesh.polygons[mesh.loops[loop_idx].polygon_index].normal
        result.append((n[0], n[1], n[2]))
    return result


def _per_loop_buffer(records, what, use_compression=True):
    """Encode one record per loop as (data, index buffer), the per-loop
    contract of UV/normal/color edits. Up to 65,535 loops this is the identity
    layout; a bigger mesh (a stadium ground, 2026-10-18) can't index its loops
    with u16, so equal records are stored once. Every patcher reader looks a
    loop's value up through the index buffer and compacts by value, so both
    layouts give the same result."""
    if len(records) <= 0xFFFF:
        data, indices = b''.join(records), range(len(records))
    else:
        slot_of = {}
        indices = [slot_of.setdefault(record, len(slot_of)) for record in records]
        if len(slot_of) > 0xFFFF:
            raise ValueError(
                f"{what}: {len(slot_of):,} different values on {len(records):,} face corners; "
                "the game indexes at most 65,535 per mesh. Split the mesh or reduce its seams."
            )
        data = b''.join(slot_of)
    return (
        _from_bytes(data, use_compression),
        _from_bytes(struct.pack(f'>{len(indices)}H', *indices), use_compression),
    )


def _per_loop_records(data, faces, stride):
    """Inverse of _per_loop_buffer: the record each loop points at."""
    raw, index_raw = _to_bytes(data), _to_bytes(faces)
    indices = struct.unpack(f'>{len(index_raw) // 2}H', index_raw)
    return [raw[index * stride:(index + 1) * stride] for index in indices]


def encode_normal_edits(obj, json_normal_buffer, loop_indices, use_compression=True):
    """Export per-loop edited normals aligned with FacesDataEdited (plan 3.3, item 1).

    Mirrors the per-loop UV contract of item 3.2: one quantized normal per loop
    in FacesDataEdited loop order (no deduplication) plus an identity per-loop
    index buffer. The patcher compacts the buffer like UVChannelDataEdited.

    Records may declare more components than the three normal axes (CompCount 6
    interleaves [NX, NY, NZ, X, Y, Z]). Blender only carries the normal, so the
    trailing components are copied verbatim from the donor record each loop
    referenced. Returns None when that donor mapping is unavailable.

    With an unchanged loop layout, a loop whose normal is only Blender
    round-trip noise away from its donor record keeps that record verbatim,
    so an untouched mesh exports byte-identical normals.
    """
    normal_data = bytearray()
    comp = json_normal_buffer.get("NormalBufferCompCount", 3)
    quant = json_normal_buffer.get("NormalBufferQuantizeInfo", 0)
    is_float = (quant >> 4) in [4, 7, 0xa]
    divisor = 1 << (quant & 0xF)
    comp_size = 4 if is_float else 2
    stride = comp * comp_size

    # Per-loop donor records, available only with an unchanged loop layout.
    donor_records = None
    donor_raw = _to_bytes(json_normal_buffer.get("NormalBufferData") or b"")
    donor_faces = json_normal_buffer.get("NormalFacesData")
    if donor_raw and donor_faces is not None and not len(donor_raw) % stride:
        donor_indices = list(struct.unpack(
            f'>{len(_to_bytes(donor_faces)) // 2}H', _to_bytes(donor_faces)))
        donor_count = len(donor_raw) // stride
        if len(donor_indices) == len(loop_indices) and all(
            index < donor_count for index in donor_indices
        ):
            donor_records = [
                donor_raw[index * stride:(index + 1) * stride]
                for index in donor_indices
            ]
    # Trailing components can only be preserved with an unchanged loop layout.
    if comp > 3 and donor_records is None:
        return None

    for loop_position, n in enumerate(_per_loop_normals(obj.data, loop_indices)):
        if donor_records is not None:
            record = donor_records[loop_position]
            if _normal_is_donor_roundtrip(
                n, _decode_donor_components(record[:3 * comp_size], comp_size, divisor, is_float)
            ):
                normal_data += record
                continue
        for val in n[:comp]:
            if is_float:
                if not math.isfinite(float(val)):
                    raise ValueError(
                        f"{obj.name}: per-loop normal component is not finite ({val})"
                    )
                normal_data += struct.pack('>f', val)
            else:
                normal_data += _pack_quantized_component(
                    val, divisor, f"{obj.name} per-loop normal component"
                )
        if comp > 3:
            normal_data += donor_records[loop_position][3 * comp_size:]

    if len(normal_data) != len(loop_indices) * stride:
        return None
    return _per_loop_buffer(
        [bytes(normal_data[k * stride:(k + 1) * stride]) for k in range(len(loop_indices))],
        f"{obj.name} normals", use_compression,
    )


def _apply_inplace_normal_edits(obj, normal_buffer, loop_indices, errors, use_compression=True):
    """Write in-place standalone normal edits. Returns True when loops that
    share a donor slot got different normals, which only Hammerspace can
    store."""
    normal_edits = encode_normal_edits(
        obj, normal_buffer, loop_indices, use_compression
    )
    if normal_edits is None:
        donor_loop_count = len(_to_bytes(
            normal_buffer.get("NormalFacesData")
        )) // 2
        errors.append(
            f"{obj.name}: standalone normal overwrite DROPPED — extended "
            f"normal records could not preserve their donor mapping "
            f"({donor_loop_count} donor loops, {len(loop_indices)} mesh loops). "
            f"The donor normals were kept; your normal edits are NOT in this "
            f"export. Keep the original topology or leave Overwrite Normals off."
        )
        normal_buffer.pop("NormalBufferDataEdited", None)
        normal_buffer.pop("NormalFacesDataEdited", None)
        return False

    norm_data, norm_faces = normal_edits
    donor_faces_raw = _to_bytes(normal_buffer["NormalFacesData"])
    norm_comp = normal_buffer.get("NormalBufferCompCount", 3)
    norm_quant = normal_buffer.get("NormalBufferQuantizeInfo", 0)
    norm_stride = norm_comp * _comp_size_skin(norm_quant)
    loop_records = _per_loop_records(norm_data, norm_faces, norm_stride)
    donor_count = len(donor_faces_raw) // 2
    donor_indices = [
        int.from_bytes(donor_faces_raw[k*2:k*2+2], 'big')
        for k in range(donor_count)
    ]
    # Conflict check: if loops sharing a donor slot have different edited
    # normals, compaction would grow the buffer.
    slot_values = {}
    normal_conflict = False
    for slot_idx, loop_pos in zip(donor_indices, range(len(loop_indices))):
        record = loop_records[loop_pos]
        if slot_idx in slot_values:
            if slot_values[slot_idx] != record:
                normal_conflict = True
                break
        else:
            slot_values[slot_idx] = record
    if normal_conflict:
        errors.append(
            f"{obj.name}: standalone normal buffer conflict — loops sharing "
            f"a donor slot have different edited normals. Normal overwrite "
            f"DROPPED (would exceed original buffer size); your normal edits "
            f"are NOT in this export."
        )
        normal_buffer.pop("NormalBufferDataEdited", None)
        normal_buffer.pop("NormalFacesDataEdited", None)
        return True
    normal_buffer["NormalBufferDataEdited"] = norm_data
    normal_buffer["NormalFacesDataEdited"] = norm_faces
    return False


def _get_loop_color(entry):
    """Read one color attribute entry back in the donor's own value space.

    ``entry.color`` converts between sRGB and scene-linear on top of the 8-bit
    BYTE_COLOR storage, which does not round-trip: 73 of the 256 donor byte
    values come back shifted by one, so every export of an untouched model
    would report a spurious color edit. ``color_srgb`` maps straight onto the
    stored bytes. Mirrors ``_set_loop_color`` in ImportSluggies.
    """
    try:
        return entry.color_srgb
    except AttributeError:
        return entry.color


def _encode_color_entry(quant_info, rgba):
    """Encode one 0..1 (r, g, b, a) color into the big-endian entry layout that
    decode_color_channel (ImportSluggies) decodes for the channel's format."""
    fmt = quant_info >> 4
    r, g, b, a = (max(0.0, min(1.0, c)) for c in rgba)
    if fmt == 0:  # RGB565
        value = ((int(round(r * 31)) & 0x1F) << 11) \
              | ((int(round(g * 63)) & 0x3F) << 5) \
              | (int(round(b * 31)) & 0x1F)
        return value.to_bytes(2, 'big')
    if fmt == 3:  # RGBA4444
        value = ((int(round(r * 15)) & 0xF) << 12) \
              | ((int(round(g * 15)) & 0xF) << 8) \
              | ((int(round(b * 15)) & 0xF) << 4) \
              | (int(round(a * 15)) & 0xF)
        return value.to_bytes(2, 'big')
    if fmt in (1, 4):  # RGB8
        return bytes((int(round(r * 255)), int(round(g * 255)), int(round(b * 255))))
    if fmt in (2, 5):  # RGBA8
        return bytes((int(round(r * 255)), int(round(g * 255)),
                      int(round(b * 255)), int(round(a * 255))))
    raise ValueError(f"unsupported color channel format {fmt} (quantizeInfo=0x{quant_info:X})")


def encode_color_edits(obj, json_channel, loop_indices, use_compression=True):
    """Export per-loop edited colors for one ColorChannels entry (plan 3.3, item 1).

    Reads the CORNER-domain color attribute the importer created ('color0' /
    'color1'), one entry per loop in FacesDataEdited loop order, plus an
    identity per-loop index buffer — the same per-loop contract as
    UVFacesDataEdited. Returns None when the attribute does not exist.
    Unset (0, 0, 0, 0) corners are written white, as on the rebuild paths
    (CustomSubmeshExport.fill_unset_colors).
    """
    mesh = obj.data
    ch_idx = json_channel.get("ColorChannelIndex", 0)
    attr = next((a for a in mesh.color_attributes if a.name == f"color{ch_idx}"), None)
    if attr is None:
        return None
    quant = json_channel.get("ColorChannelQuantizeInfo", 0)
    colors = CustomSubmeshExport.fill_unset_colors(
        obj.name, [_get_loop_color(attr.data[loop_idx]) for loop_idx in loop_indices],
    )
    return _per_loop_buffer(
        [_encode_color_entry(quant, color) for color in colors],
        f"{obj.name} color{ch_idx}", use_compression,
    )


def encode_mesh_hammerspace(obj, json_submesh, use_custom_normals=False, use_compression=True):
    """Encode all mesh data for hammerspace export (vertex count may differ from original).

    Returns a dict with:
      'VertexBufferDataEdited':    binary field   — full re-quantized vertex buffer
      'FacesDataEdited':           binary field   — uint16 BE triangulated face indices
      'FacesCountEdited':          int            — triangle count
      'FaceTextureIndicesEdited':  binary field   — uint16 BE texture index per face
                                                    (derived from Blender material slots;
                                                    used to route faces to draw states)
      'UVEdits': {ch_ind: (uv_data_enc, uv_faces_enc), ...}
      'NormalEdits': (normal_data_enc, normal_faces_enc) or None — per-loop normals
                      when the submesh has a standalone NormalBuffer (plan 3.3)
      'ColorEdits': {ch_ind: (color_data_enc, color_faces_enc), ...} — per-loop
                     colors for channels whose color attribute exists (plan 3.3)
    """
    mesh = obj.data
    mesh.calc_loop_triangles()
    triangles = mesh.loop_triangles

    vb_data = encode_vertex_buffer_edited(
        obj,
        obj["VertexBufferCompCount"],
        obj["VertexBufferQuantizeInfo"],
        use_custom_normals=use_custom_normals,
        use_compression=use_compression,
        donor_data=json_submesh.get("VertexBuffer", {}).get("VertexBufferData"),
    )

    face_flat = [vi for tri in triangles for vi in tri.vertices]
    faces_data = _from_bytes(struct.pack(f'>{len(face_flat)}H', *face_flat), use_compression)

    # Per-face texture index derived from Blender material slots.
    # Prefer mat["TextureIndex"] (set by 2.2 import); fall back to name parsing.
    mat_to_tex: dict[int, int] = {}
    for slot_idx, slot in enumerate(obj.material_slots):
        tex_idx = 0
        if slot.material is not None:
            tex_prop = slot.material.get("TextureIndex")
            if tex_prop is not None:
                tex_idx = int(tex_prop)
            else:
                try:
                    tex_idx = int(slot.material.name.rsplit('_mat', 1)[1])
                except (IndexError, ValueError):
                    pass
        mat_to_tex[slot_idx] = tex_idx
    face_tex_flat = [
        mat_to_tex.get(mesh.polygons[tri.polygon_index].material_index, 0)
        for tri in triangles
    ]
    face_tex_data = _from_bytes(
        struct.pack(f'>{len(face_tex_flat)}H', *face_tex_flat), use_compression
    )

    all_uv_channels = json_submesh.get('UVChannels', [])
    uv_edits = {}
    for json_channel in all_uv_channels:
        ch_ind = json_channel.get('UVChannelIndex', 0)
        uv_layer = _find_uv_layer(mesh, all_uv_channels, ch_ind)
        if uv_layer is None:
            continue

        quant_info_uv = json_channel['UVChannelQuantizeInfo']
        comp_count_uv = json_channel['UVChannelCompCount']
        fmt_nibble = quant_info_uv >> 4
        shift = quant_info_uv & 0xF
        divisor = 1 << shift
        is_float = fmt_nibble in [4, 7, 0xa]

        # Per-loop UV storage: each face-corner gets its own UV entry, in loop
        # order. The patcher compacts it against the donor slot layout, which
        # keeps the donor's duplicate values at their own indices (deduplicating
        # here once changed the array length and broke patching). Only meshes
        # past 65,535 corners store equal values once (_per_loop_buffer).
        coords = []
        for tri in triangles:
            for loop_idx in tri.loops:
                uv = uv_layer.data[loop_idx].uv
                s = uv.x
                t = 1.0 - uv.y  # undo Blender V-flip applied on import
                if is_float:
                    qs, qt = float(s), float(t)
                else:
                    qs = int(round(s * divisor))
                    qt = int(round(t * divisor))
                coords.append((qs, qt))

        records = []
        for coord_index, (qs, qt) in enumerate(coords):
            record = bytearray()
            for component_index, val in enumerate(
                [qs, qt] + [0.0] * (comp_count_uv - 2)
            ):
                if is_float:
                    if not math.isfinite(float(val)):
                        raise ValueError(
                            f"{obj.name} UV{ch_ind} loop {coord_index} component "
                            f"{component_index}: value is not finite ({val})"
                        )
                    record += struct.pack('>f', float(val))
                else:
                    record += _pack_quantized_component(
                        int(val) / divisor,
                        divisor,
                        f"{obj.name} UV{ch_ind} loop {coord_index} component {component_index}",
                    )
            records.append(bytes(record))
        uv_edits[ch_ind] = _per_loop_buffer(records, f"{obj.name} UV{ch_ind}", use_compression)

    # Per-loop normals (standalone NormalBuffer, non-skinned meshes) and per-loop
    # colors — same expanded per-loop contract as the UV edits above (plan 3.3).
    loop_indices = [loop_idx for tri in triangles for loop_idx in tri.loops]

    normal_edits = None
    normal_buffer = json_submesh.get("NormalBuffer")
    # Normals are only rewritten when the user opted in, matching in-place mode.
    if use_custom_normals and isinstance(normal_buffer, dict) and "NormalBufferData" in normal_buffer:
        normal_edits = encode_normal_edits(obj, normal_buffer, loop_indices, use_compression)

    color_edits = {}
    for json_channel in json_submesh.get("ColorChannels", []):
        ch_ind = json_channel.get("ColorChannelIndex", 0)
        encoded = encode_color_edits(obj, json_channel, loop_indices, use_compression)
        if encoded is not None:
            color_edits[ch_ind] = encoded

    return {
        'VertexBufferDataEdited':   vb_data,
        'FacesDataEdited':          faces_data,
        'FacesCountEdited':         len(triangles),
        'FaceTextureIndicesEdited': face_tex_data,
        'UVEdits':                  uv_edits,
        'NormalEdits':              normal_edits,
        'ColorEdits':               color_edits,
    }


def _comp_size_skin(quant_info):
    fmt = quant_info >> 4
    return 4 if fmt in [4, 7, 0xa] else 2


def _skn_block_size(skin_data: dict, flush_ind_size: int = None, edited: bool = False) -> int:
    """Calculate total byte size of an SKN block from a SkinData or SkinDataEdited dict.

    Mirrors the logic of patch_skn_dat.skn_block_size so the Blender exporter
    can compare original vs edited sizes without importing from SluggiesTools.
    With *edited*, each entry's *Edited field is measured where present
    (encode_skin_weights_inplace: does the edited layout still fit?).
    """
    sk1s   = skin_data.get('SK1s',   [])
    sk2s   = skin_data.get('SK2s',   [])
    skaccs = skin_data.get('SKAccs', [])
    if flush_ind_size is None:
        flush_ind_size = skin_data.get('FlushIndSize', 0)

    def _a4(n):
        return (n + 3) & ~3

    def _field(e, key):
        return _a4(len(_to_bytes((edited and e.get(key + 'Edited')) or e[key])))

    total  = 0x24                 # SKN header
    total += len(sk1s)   * 0x40  # SK1 structs
    total += len(sk2s)   * 0x74  # SK2 structs
    total += len(skaccs) * 0x44  # SKAcc structs

    for e in sk1s:
        total += _field(e, 'BindPoseData')
    for e in sk2s:
        total += _field(e, 'BindPoseData')
        total += _field(e, 'WeightData')
    for e in skaccs:
        total += _field(e, 'BindPoseData')
        total += _field(e, 'DestIndexData')
        total += _field(e, 'WeightData')

    if flush_ind_size:
        total += _a4(flush_ind_size * 2)

    return total


def _get_vgroup_weight(obj, group_name, vertex_index):
    """Return 0-1 weight for vertex_index in group_name, or 0.0 if absent."""
    vg = obj.vertex_groups.get(group_name)
    if vg is None:
        return 0.0
    try:
        return vg.weight(vertex_index)
    except RuntimeError:
        return 0.0


def _parse_bone_group_name(name):
    """Return bone id from Blender vertex-group name bone_<id>, else None."""
    if not isinstance(name, str) or not name.startswith("bone_"):
        return None
    try:
        return int(name[5:])
    except ValueError:
        return None


def _detect_uniform_vertex_bone_id(obj):
    """Return a single bone id when all vertices map to exactly one bone_<id>."""
    group_bone = {group.index: _parse_bone_group_name(group.name) for group in obj.vertex_groups}
    uniform_id = None
    for vd in obj.data.vertices:
        v_id = None
        for g in vd.groups:
            if g.weight <= 0:
                continue
            parsed = group_bone.get(g.group)
            if parsed is None:
                continue
            if v_id is not None and v_id != parsed:
                return None
            v_id = parsed
        if v_id is None or (uniform_id is not None and uniform_id != v_id):
            return None
        uniform_id = v_id
    return uniform_id


def encode_unskinned_bone_reassignments(candidates, data, warnings):
    """Write BoneHierarchy.GeoIdEdited when a non-skinned submesh is retargeted.

    Detection rule: for a non-skinned submesh object, every vertex must belong
    to exactly one positive-weight bone_<id> group, and that id differs from
    the current owning bone id. The rule itself lives in
    HostBones.compute_rigid_retargets, shared with the free-bone proposal
    so both call sites agree on what a
    valid retarget is.
    """
    model = data.get("SluggiesModel", {})
    bone_list = model.get("BoneHierarchy")
    submeshes = model.get("Submeshes", [])
    if not bone_list or not submeshes:
        return False

    for bd in bone_list:
        bd.pop("GeoIdEdited", None)

    retargets, issues, obj_by_submesh = _candidate_rigid_retargets(candidates, model)
    bone_by_id = {int(bd["BoneId"]): bd for bd in bone_list if "BoneId" in bd}

    for issue in issues:
        obj = obj_by_submesh.get(issue.submesh_index)
        obj_name = obj.name if obj is not None else f"submesh {issue.submesh_index}"
        if issue.reason == "unknown_bone":
            warnings.append(
                f"{obj_name}: target group bone_{issue.target_bone_id} is not present in BoneHierarchy; "
                f"non-skinned reassignment skipped."
            )
        elif issue.reason == "target_claimed_by_other_submesh":
            warnings.append(
                f"{obj_name}: bone_{issue.target_bone_id} is already requested by submesh "
                f"{issue.detail}; one non-skinned bone can own only one GeoId."
            )
        elif issue.reason == "target_occupied":
            warnings.append(
                f"{obj_name}: bone_{issue.target_bone_id} currently owns submesh {issue.detail}; "
                f"reassignment skipped to avoid GeoId collision."
            )

    wrote_any = False
    for r in retargets:
        bone_by_id[r.from_bone_id]["GeoIdEdited"] = GEO_ID_FREE
        bone_by_id[r.to_bone_id]["GeoIdEdited"] = r.submesh_index
        wrote_any = True

    return wrote_any


def _candidate_rigid_retargets(candidates, model):
    """The donor rigid-submesh retargets the selected *candidates* request,
    against the donor ``BoneHierarchy`` (any ``GeoIdEdited`` left by an earlier
    export is ignored, since this export rewrites it).

    Returns ``(retargets, issues, obj_by_submesh)``. Shared by
    :func:`encode_unskinned_bone_reassignments` and the custom submesh
    host-bone re-check, so both see the same final scene state.
    """
    bone_list = model.get("BoneHierarchy") or []
    submeshes = model.get("Submeshes", [])
    submesh_by_vb = {}
    for i, sm in enumerate(submeshes):
        vb = sm.get("VertexBuffer")
        if vb and "VertexBufferOffset" in vb:
            submesh_by_vb[str(vb["VertexBufferOffset"])] = i

    obj_by_submesh = {}
    for obj in candidates:
        if "VertexBufferOffset" not in obj:
            continue
        sub_idx = submesh_by_vb.get(str(obj["VertexBufferOffset"]))
        if sub_idx is not None:
            obj_by_submesh[sub_idx] = obj

    bone_by_id = {int(bd["BoneId"]): bd for bd in bone_list if "BoneId" in bd}
    owner_bone_by_submesh = {
        int(bd["GeoId"]): int(bd["BoneId"])
        for bd in bone_list
        if (not bd.get("Skinned")) and bd.get("GeoId") is not None and int(bd.get("GeoId", -1)) >= 0
    }

    def _geo_raw(bd):
        if bd.get("GeoIdRaw") is not None:
            return int(bd["GeoIdRaw"])
        if bd.get("Skinned"):
            return GEO_ID_FREE
        return int(bd.get("GeoId", GEO_ID_FREE))

    bone_geo_raw = {bone_id: _geo_raw(bd) for bone_id, bd in bone_by_id.items()}

    target_bone_by_submesh = {}
    for sub_idx, from_bone_id in owner_bone_by_submesh.items():
        obj = obj_by_submesh.get(sub_idx)
        if obj is not None:
            target_bone_by_submesh[sub_idx] = _detect_uniform_vertex_bone_id(obj)

    retargets, issues = compute_rigid_retargets(
        owner_bone_by_submesh, bone_geo_raw, target_bone_by_submesh, set(bone_by_id.keys())
    )
    return retargets, issues, obj_by_submesh


def encode_skin_weights_inplace(candidates, data, warnings, use_custom_normals=False):
    """Re-pack SK1/SK2/SKAcc bind-pose source data and SK2/SKAcc weight bytes
    from Blender vertex positions/normals and vertex groups (in-place mode).

    Supports variable vertex counts per entry: trailing vertices that have lost
    all bone influence are trimmed from the source arrays, reducing entry size.
    Middle-removed vertices (still needed to preserve dest-slot ordering for
    subsequent kept vertices) retain their original source data.

    For SKAcc entries, any vertex can be freely removed since dest indices are
    explicit; duplicate-dest entries are always preserved verbatim.

    Writes into each SK entry:
    - 'BindPoseDataEdited'     (SK1 / SK2 / SKAcc)
    - 'WeightDataEdited'       (SK2 / SKAcc)
    - 'DestIndexDataEdited'    (SKAcc only, when count changes)
    - 'VertexCntEdited'        (any type, when count changes)

    Returns True if any entries were written, False if none were, and None
    on size overflow (the edit then needs Hammerspace).
    """
    skin_data = data["SluggiesModel"].get("SkinData")
    if not skin_data or not (skin_data.get("SK1s") or skin_data.get("SK2s") or skin_data.get("SKAccs")):
        return False
    quant_info  = skin_data["QuantizeInfo"]
    use_compression  = data["SluggiesModel"].get("UseCompression", True)
    vertex_size = 6 * _comp_size_skin(quant_info)
    fmt_nibble  = quant_info >> 4
    is_float    = fmt_nibble in [4, 7, 0xa]
    divisor     = 1 << (quant_info & 0xF)
    submeshes   = data["SluggiesModel"].get("Submeshes", [])

    skinned_bone_ids = set()
    for _e in skin_data.get("SK1s", []):
        skinned_bone_ids.add(_e["BoneIndex"])
    for _e in skin_data.get("SK2s", []):
        skinned_bone_ids.add(_e["BoneIndex1"])
        skinned_bone_ids.add(_e["BoneIndex2"])
    for _e in skin_data.get("SKAccs", []):
        skinned_bone_ids.add(_e["BoneIndex"])

    # Build per-submesh (vtx_start, vtx_count) using cumulative vertex counts.
    # gplVertexArr is a byte offset from the start of the runtime dest buffer;
    # gplVertexArr // vertex_size gives a global vertex index that runs
    # sequentially across all submeshes (0, 1, 2, … total_verts-1).
    # This matches how extract_bone_data in export.py maps SK entries to Blender
    # vertices — do NOT subtract (VertexBufferOffset - gpl_base) here.
    sub_ranges = []
    cumulative = 0
    for sm in submeshes:
        vb = sm["VertexBuffer"]
        vb_cs     = _comp_size_skin(vb["VertexBufferQuantizeInfo"])
        vtx_count = vb["VertexBufferLength"] // (vb["VertexBufferCompCount"] * vb_cs)
        sub_ranges.append((cumulative, vtx_count, vb["VertexBufferOffset"]))
        cumulative += vtx_count

    # Map VertexBufferOffset → object for quick lookup
    obj_by_vb = {str(obj["VertexBufferOffset"]): obj for obj in candidates if "VertexBufferOffset" in obj}

    # Pre-compute custom split normals per object when requested
    custom_normals_cache = {}
    if use_custom_normals:
        for _obj in candidates:
            if "VertexBufferOffset" in _obj:
                _cn = _get_custom_split_normals(_obj)
                if _cn is not None:
                    custom_normals_cache[str(_obj["VertexBufferOffset"])] = _cn

    def resolve(global_vtx):
        for j, (start, count, vb_off) in enumerate(sub_ranges):
            if start <= global_vtx < start + count:
                return obj_by_vb.get(str(vb_off)), global_vtx - start
        return None, global_vtx

    def pack_val(v, context):
        if is_float:
            if not math.isfinite(float(v)):
                raise ValueError(f"{context}: coordinate/component is not finite ({v})")
            return struct.pack('>f', float(v))
        return _pack_quantized_component(v, divisor, context)

    def encode_vertex(obj, local_v):
        vd  = obj.data.vertices[local_v]
        _cn = custom_normals_cache.get(str(obj["VertexBufferOffset"]))
        nx, ny, nz = (
            (_cn[local_v].x, _cn[local_v].y, _cn[local_v].z)
            if _cn is not None
            else (vd.normal.x, vd.normal.y, vd.normal.z)
        )
        buf = bytearray()
        for component, val in zip(
            ('x', 'y', 'z', 'nx', 'ny', 'nz'),
            (vd.co.x, vd.co.y, vd.co.z, nx, ny, nz),
        ):
            buf.extend(pack_val(val, f"{obj.name} vertex {local_v} {component}"))
        return bytes(buf)

    wrote_any = False

    # --- SK1 entries (source data only, no weights) ---
    # Re-encode in dest-slot order (position i → dest slot gplBase + vtx_off + i).
    # Trailing vertices with weight=0 are trimmed; middle-removed ones keep
    # their original source bytes so subsequent kept vertices stay at the
    # correct dest slot.
    for sk1 in skin_data.get("SK1s", []):
        bone_id      = sk1["BoneIndex"]
        n            = sk1["VertexCnt"]
        vtx_off      = sk1.get("VertexOffset", 0)
        global_start = (sk1["GplVertexArrValue"] + vtx_off) // vertex_size
        orig_src     = _to_bytes(sk1["BindPoseData"])

        # Detect full SK1 reassignment (all vertices moved from bone_A to one
        # other skinned bone via vertex-group rename/transfer).
        reassigned_bone = None
        seen_any = False
        unresolved = False
        candidate_ids = set()
        any_orig_weight = False
        for i in range(n):
            obj, local_v = resolve(global_start + i)
            if obj is None:
                unresolved = True
                continue
            seen_any = True
            if _get_vgroup_weight(obj, f"bone_{bone_id}", local_v) > 0:
                any_orig_weight = True

            ids_here = set()
            for g in obj.data.vertices[local_v].groups:
                if g.weight <= 0:
                    continue
                vg_name = obj.vertex_groups[g.group].name
                parsed = _parse_bone_group_name(vg_name)
                if parsed is not None and parsed in skinned_bone_ids:
                    ids_here.add(parsed)
            if len(ids_here) != 1:
                candidate_ids = set()
                break
            candidate_ids |= ids_here

        if seen_any and (not unresolved) and (not any_orig_weight) and len(candidate_ids) == 1:
            only_id = next(iter(candidate_ids))
            if only_id != bone_id:
                reassigned_bone = only_id

        target_bone_id = reassigned_bone if reassigned_bone is not None else bone_id
        target_bone_name = f"bone_{target_bone_id}"
        if reassigned_bone is not None:
            sk1["BoneIndexEdited"] = target_bone_id
        else:
            sk1.pop("BoneIndexEdited", None)

        last_kept  = -1
        slot_bytes = []
        for i in range(n):
            obj, local_v = resolve(global_start + i)
            if obj is None:
                # Vertex outside imported submeshes — treat as kept, preserve.
                slot_bytes.append(orig_src[vtx_off + i * vertex_size : vtx_off + (i + 1) * vertex_size])
                last_kept = i
            else:
                if _get_vgroup_weight(obj, target_bone_name, local_v) > 0:
                    slot_bytes.append(encode_vertex(obj, local_v))
                    last_kept = i
                else:
                    # Vertex removed — keep original for middle-ordering.
                    slot_bytes.append(orig_src[vtx_off + i * vertex_size : vtx_off + (i + 1) * vertex_size])

        new_count = last_kept + 1 if last_kept >= 0 else 0
        src = orig_src[:vtx_off] + b''.join(slot_bytes[:new_count])

        sk1["BindPoseDataEdited"] = _from_bytes(src, use_compression)
        if new_count != n:
            sk1["VertexCntEdited"] = new_count
        wrote_any = True

    # --- SK2 entries (source data + blend weights) ---
    # A vertex is "kept" if it still has at least one non-zero weight for
    # either bone in this pair.  Both weights zero → candidate for trailing trim.
    for sk2 in skin_data.get("SK2s", []):
        bone1        = sk2["BoneIndex1"]
        bone2        = sk2["BoneIndex2"]
        bone1_name   = f"bone_{bone1}"
        bone2_name   = f"bone_{bone2}"
        n            = sk2["VertexCnt"]
        vtx_off      = sk2.get("VertexOffset", 0)
        global_start = (sk2["GplVertexArrValue"] + vtx_off) // vertex_size
        orig_src     = _to_bytes(sk2["BindPoseData"])
        orig_wt      = _to_bytes(sk2["WeightData"])

        last_kept  = -1
        slot_src   = []
        slot_wt    = []
        for i in range(n):
            obj, local_v = resolve(global_start + i)
            if obj is None:
                slot_src.append(orig_src[vtx_off + i * vertex_size : vtx_off + (i + 1) * vertex_size])
                slot_wt.append(bytes([orig_wt[i * 2], orig_wt[i * 2 + 1]]))
                last_kept = i
            else:
                w1 = _get_vgroup_weight(obj, bone1_name, local_v)
                w2 = _get_vgroup_weight(obj, bone2_name, local_v)
                if w1 > 0 or w2 > 0:
                    slot_src.append(encode_vertex(obj, local_v))
                    slot_wt.append(bytes([
                        max(0, min(255, round(w1 * 256))),
                        max(0, min(255, round(w2 * 256))),
                    ]))
                    last_kept = i
                else:
                    # Both bones removed — keep original for middle-ordering.
                    slot_src.append(orig_src[vtx_off + i * vertex_size : vtx_off + (i + 1) * vertex_size])
                    slot_wt.append(bytes([orig_wt[i * 2], orig_wt[i * 2 + 1]]))

        new_count = last_kept + 1 if last_kept >= 0 else 0
        src = orig_src[:vtx_off] + b''.join(slot_src[:new_count])
        wt  = b''.join(slot_wt[:new_count])

        sk2["BindPoseDataEdited"] = _from_bytes(src, use_compression)
        sk2["WeightDataEdited"]   = _from_bytes(wt, use_compression)
        if new_count != n:
            sk2["VertexCntEdited"] = new_count
        wrote_any = True

    # --- SKAcc entries (source data + dest indices + weights) ---
    # Since dest indices are explicit, any vertex can be freely removed without
    # breaking the dest-slot ordering of other vertices.
    # Duplicate-dest entries are always preserved verbatim (same reasoning as
    # before: Blender stores only one weight per (bone, vertex) pair).
    for skacc in skin_data.get("SKAccs", []):
        bone_id   = skacc["BoneIndex"]
        bone_name = f"bone_{bone_id}"
        n         = skacc["VertexCnt"]
        dest_base = skacc["GplDestArrValue"] // vertex_size
        orig_src  = _to_bytes(skacc["BindPoseData"])
        orig_wt   = _to_bytes(skacc["WeightData"])
        dest_idxs = list(struct.unpack(f'>{n}H', _to_bytes(skacc["DestIndexData"])))

        dest_count = {}
        for di in dest_idxs:
            dest_count[di] = dest_count.get(di, 0) + 1
        dup_dests = {di for di, cnt in dest_count.items() if cnt > 1}

        new_src  = bytearray()
        new_dest = bytearray()
        new_wt   = bytearray()

        for i in range(n):
            di       = dest_idxs[i]
            global_v = dest_base + di
            obj, local_v = resolve(global_v)

            if di in dup_dests or obj is None:
                # Preserve verbatim — dup-dest or unknown vertex.
                new_src  += orig_src[i * vertex_size : (i + 1) * vertex_size]
                new_dest += struct.pack('>H', di)
                new_wt   += bytes([orig_wt[i]])
            else:
                w = _get_vgroup_weight(obj, bone_name, local_v)
                if w > 0:
                    new_src  += encode_vertex(obj, local_v)
                    new_dest += struct.pack('>H', di)
                    new_wt   += bytes([max(0, min(255, round(w * 256)))])
                # else: vertex removed from this SKAcc entry — skip entirely.

        new_count = len(new_dest) // 2
        skacc["BindPoseDataEdited"]  = _from_bytes(bytes(new_src),  use_compression)
        skacc["WeightDataEdited"]    = _from_bytes(bytes(new_wt),   use_compression)
        if new_count != n:
            skacc["DestIndexDataEdited"] = _from_bytes(bytes(new_dest), use_compression)
            skacc["VertexCntEdited"]     = new_count
        wrote_any = True

    # --- Size check ---
    # Edited size can never exceed original because we only shrink or keep equal.
    # This guard catches any unforeseen logic errors.
    orig_size = _skn_block_size(skin_data)
    edit_size = _skn_block_size(skin_data, edited=True)

    if edit_size > orig_size:
        overflow = edit_size - orig_size
        # Strip all edited fields so the patcher ignores this model.
        for sk1 in skin_data.get("SK1s", []):
            for k in ('BindPoseDataEdited', 'VertexCntEdited', 'BoneIndexEdited'):
                sk1.pop(k, None)
        for sk2 in skin_data.get("SK2s", []):
            for k in ('BindPoseDataEdited', 'WeightDataEdited', 'VertexCntEdited'):
                sk2.pop(k, None)
        for skacc in skin_data.get("SKAccs", []):
            for k in ('BindPoseDataEdited', 'WeightDataEdited', 'DestIndexDataEdited', 'VertexCntEdited'):
                skacc.pop(k, None)
        warnings.append(
            f"SKN block too large for in-place patch. "
            f"Original: {orig_size} B, Edited: {edit_size} B, "
            f"Overflow: +{overflow} B. Reduce vertex count or simplify bone influences."
        )
        return None

    return wrote_any


def skin_membership_changed(candidates, data):
    """Whether a vertex of an exported skinned mesh now has other skinning
    bones than in the donor. The in-place encoder above cannot store that
    (it only rewrites weights inside each vertex's original entries), so the
    export then uses Hammerspace."""
    skin_data = data["SluggiesModel"].get("SkinData")
    if not skin_data:
        return False
    vertex_size = 6 * _comp_size_skin(skin_data["QuantizeInfo"])
    donor_sets = ExportMode.donor_skin_bone_sets(skin_data, vertex_size)
    model = data["SluggiesModel"]
    # A weight on any bone of the skeleton is a membership change too (the
    # body is then rebuilt with that bone): added bones and original bones the
    # donor never skins both drive skinning (Dolphin 2026-10-12, 2026-10-24).
    skinned_bone_ids = SkinnedRebuildExport.allowed_skin_bones(
        model.get("BoneHierarchyEdited") or model.get("BoneHierarchy")
    )
    if donor_sets:
        skinned_bone_ids |= set().union(*donor_sets.values())

    obj_by_vb = {str(obj["VertexBufferOffset"]): obj for obj in candidates if "VertexBufferOffset" in obj}
    edited_sets = {}
    start = 0
    for sm in data["SluggiesModel"].get("Submeshes", []):
        vb = sm["VertexBuffer"]
        count = vb["VertexBufferLength"] // (
            vb["VertexBufferCompCount"] * _comp_size_skin(vb["VertexBufferQuantizeInfo"])
        )
        obj = obj_by_vb.get(str(vb["VertexBufferOffset"]))
        if obj is not None and vb.get("VertexBufferCompCount") == 6:
            names = {group.index: group.name for group in obj.vertex_groups}
            for local_v, vertex in enumerate(obj.data.vertices[:count]):
                bones = set()
                for g in vertex.groups:
                    if g.weight <= 0:
                        continue
                    bone_id = _parse_bone_group_name(names.get(g.group, ""))
                    if bone_id is not None and bone_id in skinned_bone_ids:
                        bones.add(bone_id)
                edited_sets[start + local_v] = bones
        start += count
    return ExportMode.skin_membership_changed(donor_sets, edited_sets)


def skinned_donor_objects(candidates, data):
    """``{id(obj): (submesh_index, obj)}`` for the exported objects that are a
    donor *skinned* submesh (``VertexBufferCompCount == 6``), matched by
    ``VertexBufferOffset``.

    A model can include rigid/static submeshes (cc=3) whose vertices attach to
    a single non-skinned bone but still carry a ``bone_<id>`` vertex group from
    import; those never take part in SK1/SK2/SKAcc classification. Custom
    submeshes have no ``VertexBufferOffset`` at all and never match.
    """
    mapping = {}
    for submesh_index, submesh in enumerate(data["SluggiesModel"].get("Submeshes", [])):
        if submesh["VertexBuffer"].get("VertexBufferCompCount") != 6:
            continue
        vb_off = str(submesh["VertexBuffer"]["VertexBufferOffset"])
        for obj in candidates:
            if "VertexBufferOffset" in obj and str(obj["VertexBufferOffset"]) == vb_off:
                mapping[id(obj)] = (submesh_index, obj)
                break
    return mapping


def encode_skin_hammerspace(candidates, data, warnings, use_custom_normals=False):
    """Rebuild SK1/SK2/SKAcc from Blender vertex groups for hammerspace export.

    Membership (which bone(s) influence a vertex) is read directly from
    Blender's current bone_<id> vertex groups — NOT from donor SK1/SK2/SKAcc
    structure — so real bone reassignment (moving a vertex group between
    donor bones) round-trips correctly.

    Splitting rules (vertices whose bone set is unchanged replicate the donor
    role assignment exactly; for edited vertices):
      donor accumulation-only → SKAcc for every influence
      1 influence  → SK1
      2+ influences → SK2 (donor's surviving pair bones, then replacement
                      bones, then by weight) + SKAcc (remainder)
    Each SK1/SK2 entry carries VertexIndices; the build tool splits entries
    into contiguous runs without reordering vertices.

    Weights are normalized and quantized together with the deterministic
    largest-remainder rule (SkinWeights.quantize_skin_weights) so output does
    not depend on Blender vertex-group iteration order.

    A vertex that had a donor bone influence but now resolves to zero is a
    hard export error (raises ValueError naming every offending object+
    vertex) — real donor models legitimately leave some vertices with no
    SK1/SK2/SKAcc coverage at all (static/unused position slots), so a
    vertex with no influence in BOTH the donor and the current Blender
    groups is not an error. Vertex groups that don't resolve to a donor-
    skinned bone are ignored with a warning (deduped by group name), unless
    doing so leaves a previously-weighted vertex unweighted, in which case
    the unweighted error wins and includes the ignored names too.

    A vertex whose set of bones differs from the donor's is not handled
    here since add-on 0.8.5: the body takes the SkinnedRebuild route
    (``_skinned_rebuild_plan``), so this encoder raises if it meets one.

    Bone pairs in SK2 are stored with the lower BoneId first.
    Source data (bind-pose XYZ + NxNyNz) is encoded with SkinData.QuantizeInfo.
    Writes 'SkinDataEdited' at the model level.  Returns (ok, message).
    """
    skin_data = data["SluggiesModel"].get("SkinData")
    if not skin_data:
        return True, None   # unskinned model — nothing to encode, not an error

    submeshes  = data["SluggiesModel"].get("Submeshes", [])
    quant_info = skin_data["QuantizeInfo"]
    use_compression = data["SluggiesModel"].get("UseCompression", True)
    cs         = _comp_size_skin(quant_info)
    fmt_nibble = quant_info >> 4
    is_float   = fmt_nibble in [4, 7, 0xa]
    divisor    = 1 << (quant_info & 0xF)

    def pack_val(v, context):
        if is_float:
            if not math.isfinite(float(v)):
                raise ValueError(f"{context}: coordinate/component is not finite ({v})")
            return struct.pack('>f', float(v))
        return _pack_quantized_component(v, divisor, context)

    obj_to_sub = skinned_donor_objects(candidates, data)
    if not obj_to_sub:
        # No skinned donor mesh took part in this export -- e.g. only a custom
        # submesh was selected. There is nothing to classify, and writing the
        # empty result would replace the donor's whole SK1/SK2/SKAcc structure
        # with nothing. The caller leaves SkinData (and any SkinDataEdited from
        # an earlier run) alone instead.
        return True, None

    # Only bones that already appear in the original SK data should feed the
    # rebuild.  Non-skinned bones own static submesh geometry and have NO SK
    # entries; their vertex groups must not be promoted to SK1/SK2/SKAcc entries
    # or the new block will exceed the original's size even with no mesh changes.
    skinned_bone_ids: set[int] = set()
    for _e in skin_data.get('SK1s',   []):
        skinned_bone_ids.add(_e['BoneIndex'])
    for _e in skin_data.get('SK2s',   []):
        skinned_bone_ids.add(_e['BoneIndex1'])
        skinned_bone_ids.add(_e['BoneIndex2'])
    for _e in skin_data.get('SKAccs', []):
        skinned_bone_ids.add(_e['BoneIndex'])

    # --- Original per-vertex bone membership (donor SkinData) ---
    # Used ONLY to detect whether the user's Blender vertex-group edits
    # actually changed skin membership anywhere in the model — NOT for
    # classification. SkinDataEdited is
    # treated as the complete source of truth for entry membership once an
    # edit is detected; membership must not be re-derived from stale donor
    # per-entry structure.
    _vertex_stride = 6 * cs  # 6 components (xyz + nxnynz) * component size

    # Compute cumulative vertex starts per submesh (for global ↔ local mapping)
    _sub_vtx_starts = []
    _sub_vtx_counts = []
    _cumulative = 0
    for _sm in submeshes:
        _vb = _sm["VertexBuffer"]
        _vb_cs = _comp_size_skin(_vb["VertexBufferQuantizeInfo"])
        _vtx_count = _vb["VertexBufferLength"] // (_vb["VertexBufferCompCount"] * _vb_cs)
        _sub_vtx_starts.append(_cumulative)
        _sub_vtx_counts.append(_vtx_count)
        _cumulative += _vtx_count

    # entry-index maps (NOT bone-id maps): a bone can legitimately own more
    # than one SK1/SK2 entry (different gplVertexArr destinations) — grouping
    # by bone id alone would silently merge them and change the entry count
    # even with no membership edit at all. Verified against production data:
    # Luigi's bone 51 owns two separate SK1 entries.
    _sk1_entry_of: dict[int, int] = {}
    for _idx, _e in enumerate(skin_data.get('SK1s', [])):
        _first = (_e['GplVertexArrValue'] + _e.get('VertexOffset', 0)) // _vertex_stride
        for _i in range(_e['VertexCnt']):
            _sk1_entry_of[_first + _i] = _idx
    _sk2_entry_of: dict[int, int] = {}
    for _idx, _e in enumerate(skin_data.get('SK2s', [])):
        _first = (_e['GplVertexArrValue'] + _e.get('VertexOffset', 0)) // _vertex_stride
        for _i in range(_e['VertexCnt']):
            _sk2_entry_of[_first + _i] = _idx
    # Fallback target for a vertex reassigned TO a bone from elsewhere: reuse
    # that bone's first existing entry rather than always minting a new one.
    _first_sk1_entry_by_bone: dict[int, int] = {}
    for _idx, _e in enumerate(skin_data.get('SK1s', [])):
        _first_sk1_entry_by_bone.setdefault(_e['BoneIndex'], _idx)
    _first_sk2_entry_by_pair: dict[tuple[int, int], int] = {}
    for _idx, _e in enumerate(skin_data.get('SK2s', [])):
        _pair = (min(_e['BoneIndex1'], _e['BoneIndex2']), max(_e['BoneIndex1'], _e['BoneIndex2']))
        _first_sk2_entry_by_pair.setdefault(_pair, _idx)

    _orig_membership: dict[int, set[int]] = {}
    for _e in skin_data.get('SK1s', []):
        _first = (_e['GplVertexArrValue'] + _e.get('VertexOffset', 0)) // _vertex_stride
        for _i in range(_e['VertexCnt']):
            _orig_membership.setdefault(_first + _i, set()).add(_e['BoneIndex'])
    for _e in skin_data.get('SK2s', []):
        _first = (_e['GplVertexArrValue'] + _e.get('VertexOffset', 0)) // _vertex_stride
        for _i in range(_e['VertexCnt']):
            _orig_membership.setdefault(_first + _i, set()).update(
                (_e['BoneIndex1'], _e['BoneIndex2']))
    # (bone_id, global_idx) -> literal donor weight byte, for replaying an
    # unchanged vertex's SKAcc contribution exactly rather than re-deriving
    # it. Donor duplicate-dest (twist/blend) entries are handled separately
    # below by the existing round-trip special case, so keeping only the
    # first match here is fine.
    _donor_skacc_weight: dict[tuple[int, int], int] = {}
    for _e in skin_data.get('SKAccs', []):
        _n = _e['VertexCnt']
        if _n == 0:
            continue
        _dests = struct.unpack(f'>{_n}H', _to_bytes(_e['DestIndexData']))
        _weights = _to_bytes(_e['WeightData'])
        _dest_base = _e.get('GplDestArrValue', 0) // _vertex_stride
        for _pos, _di in enumerate(_dests):
            _orig_membership.setdefault(_dest_base + _di, set()).add(_e['BoneIndex'])
            _donor_skacc_weight.setdefault((_e['BoneIndex'], _dest_base + _di), _weights[_pos])

    # Pre-compute custom split normals per object when requested
    custom_normals_cache = {}
    if use_custom_normals:
        for _obj_id, (_, _obj) in obj_to_sub.items():
            _cn = _get_custom_split_normals(_obj)
            if _cn is not None:
                custom_normals_cache[_obj_id] = _cn

    # SK1/SK2 group keys are donor ENTRY INDEXES when a vertex keeps its
    # original entry's bone(s), falling back to the bone's/pair's first
    # existing entry, or a synthetic ('new_sk1', bone_id) / ('new_sk2', lo, hi)
    # key when reassigned to a bone/pair with no existing entry at all. This
    # preserves entry count for the (overwhelmingly common) no-membership-
    # change case, since a bone owning multiple separate SK1/SK2 entries must
    # not be silently merged into one.
    sk1_groups   = {}  # entry key → [(sub_idx, local_v, obj)]
    sk2_groups   = {}  # entry key → [(sub_idx, local_v, w_lo, w_hi, obj)]
    skacc_groups = {}  # bone_id → [(sub_idx, local_v, weight_unit, dest_local_v, obj)]

    ignored_group_names: set[str] = set()
    unweighted: list[tuple[str, int]] = []
    overweighted: list[tuple[str, int, int]] = []
    membership_edited = False

    for _, (sub_idx, obj) in obj_to_sub.items():
        for v in obj.data.vertices:
            parsed = []
            for vge in v.groups:
                vg = obj.vertex_groups[vge.group]
                if not vg.name.startswith("bone_") or vge.weight <= 0.0:
                    continue
                try:
                    bone_id = int(vg.name[5:])
                except ValueError:
                    continue
                if bone_id not in skinned_bone_ids:
                    ignored_group_names.add(vg.name)
                    continue
                parsed.append((bone_id, vge.weight))
            parsed.sort(key=lambda x: -x[1])

            if len(parsed) > MAX_BONE_INFLUENCES_PER_VERTEX:
                overweighted.append((obj.name, v.index, len(parsed)))
                continue

            v_idx = v.index
            global_idx = _sub_vtx_starts[sub_idx] + v_idx
            orig_bones = _orig_membership.get(global_idx, set())

            if not parsed:
                # Real donor models legitimately leave some submesh-0
                # vertices with no SK1/SK2/SKAcc coverage at all (static/
                # unused position slots) — that is not an error. Only a
                # vertex that DID have a donor bone influence and lost it
                # is a genuine regression worth rejecting.
                if orig_bones:
                    unweighted.append((obj.name, v_idx))
                    membership_edited = True
                continue

            new_bones = {bone_id for bone_id, _ in parsed}
            membership_unchanged = (new_bones == orig_bones)
            if not membership_unchanged:
                membership_edited = True

            # --- Classification. Membership (WHICH bones influence a
            # vertex) always comes from Blender's current vertex groups. But the donor's choice of WHICH
            # ROLE each bone plays — SK2 pair partner vs. SKAcc supplement —
            # is an authored structural fact, not simply "the two heaviest
            # weights": verified against production data (Luigi), 103
            # vertices have a real 3rd (SKAcc) influence, and picking the
            # top-2-by-weight bones as the SK2 pair does NOT reliably
            # reproduce the donor's actual pair (Blender's re-imported
            # weight order need not match the donor's role assignment). So
            # whenever this vertex's bone SET is unchanged from the donor,
            # replicate the donor's own role assignment exactly, refreshing
            # only the weight VALUES from Blender; only a vertex whose bone
            # set actually changed falls back to the general influence-count
            # heuristic, since there is no donor role assignment left to
            # replicate for its new bone set.
            if membership_unchanged and global_idx in _sk2_entry_of:
                entry_idx = _sk2_entry_of[global_idx]
                e = skin_data['SK2s'][entry_idx]
                b_lo = min(e['BoneIndex1'], e['BoneIndex2'])
                b_hi = max(e['BoneIndex1'], e['BoneIndex2'])
                first = (e['GplVertexArrValue'] + e.get('VertexOffset', 0)) // _vertex_stride
                k = global_idx - first
                wt_bytes = _to_bytes(e['WeightData'])
                w1_byte, w2_byte = wt_bytes[2 * k], wt_bytes[2 * k + 1]
                w_lo, w_hi = (w1_byte, w2_byte) if e['BoneIndex1'] <= e['BoneIndex2'] else (w2_byte, w1_byte)
                sk2_groups.setdefault(entry_idx, []).append((sub_idx, v_idx, w_lo, w_hi, obj))
                for bone_id in (b for b, _ in parsed if b not in (b_lo, b_hi)):
                    byte = _donor_skacc_weight.get((bone_id, global_idx))
                    if byte is not None:
                        skacc_groups.setdefault(bone_id, []).append((sub_idx, v_idx, byte, v_idx, obj))
                continue

            if membership_unchanged and global_idx in _sk1_entry_of:
                entry_idx = _sk1_entry_of[global_idx]
                sk1_bone = skin_data['SK1s'][entry_idx]['BoneIndex']
                sk1_groups.setdefault(entry_idx, []).append((sub_idx, v_idx, obj))
                for bone_id in (b for b, _ in parsed if b != sk1_bone):
                    byte = _donor_skacc_weight.get((bone_id, global_idx))
                    if byte is not None:
                        skacc_groups.setdefault(bone_id, []).append((sub_idx, v_idx, byte, v_idx, obj))
                continue

            if membership_unchanged:
                # SKAcc-only vertex: no SK1/SK2 primary in the donor at all.
                for bone_id, _ in parsed:
                    byte = _donor_skacc_weight.get((bone_id, global_idx))
                    if byte is not None:
                        skacc_groups.setdefault(bone_id, []).append((sub_idx, v_idx, byte, v_idx, obj))
                continue

            # --- Genuinely edited membership: no donor role assignment to
            # replicate, so quantize fresh — but keep the vertex in its donor
            # skinning CATEGORY (SK1 / SK2 / accumulation-only) whenever the
            # new bone set allows it. The build tool lays entries out without
            # reordering vertices, and donor data never lets an SK1/SK2 entry
            # share a 32-byte cache line with another entry or with an
            # accumulation-only slot (verified across all 361 skinned models),
            # so a category change mid-entry cannot be laid out. ---
            quantized = quantize_skin_weights(parsed, target_sum=256)
            merged: dict[int, int] = {}
            for bone_id, unit in quantized:
                merged[bone_id] = merged.get(bone_id, 0) + unit

            donor_sk1 = _sk1_entry_of.get(global_idx)
            donor_sk2 = _sk2_entry_of.get(global_idx)
            if donor_sk1 is None and donor_sk2 is None and orig_bones:
                # Donor accumulation-only vertex: its slot lives in the memClr
                # tail, so every influence stays an SKAcc contribution. A lone
                # full-weight bone clamps 256 -> 255 (same MVP loss as SK2).
                for bone_id, unit in sorted(merged.items()):
                    skacc_groups.setdefault(bone_id, []).append(
                        (sub_idx, v_idx, min(255, unit), v_idx, obj))
                continue

            if len(parsed) == 1:
                bone_id = parsed[0][0]
                sk1_key = donor_sk1
                if sk1_key is None or skin_data['SK1s'][sk1_key]['BoneIndex'] != bone_id:
                    sk1_key = _first_sk1_entry_by_bone.get(bone_id, ('new_sk1', bone_id))
                sk1_groups.setdefault(sk1_key, []).append((sub_idx, v_idx, obj))
                continue

            # SK2 pair: the donor's surviving direct bone(s) first, then the
            # bones that replaced lost ones, then the rest by weight — so a
            # remapped SKAcc supplement bone stays a supplement.
            ranked = [bone_id for bone_id, _ in parsed]
            if donor_sk2 is not None:
                _donor_pair = skin_data['SK2s'][donor_sk2]
                survivors = [b for b in (_donor_pair['BoneIndex1'], _donor_pair['BoneIndex2'])
                             if b in new_bones]
            elif donor_sk1 is not None:
                _donor_bone = skin_data['SK1s'][donor_sk1]['BoneIndex']
                survivors = [_donor_bone] if _donor_bone in new_bones else []
            else:
                survivors = []
            replacements = [b for b in ranked if b not in orig_bones]
            top_bones = []
            for bone_id in survivors + replacements + ranked:
                if bone_id not in top_bones:
                    top_bones.append(bone_id)
            top_bones = top_bones[:2]
            b_lo, b_hi = min(top_bones), max(top_bones)
            # A single dominant bone can legitimately claim the full 256-unit
            # budget (e.g. the second influence quantizes to zero); clamping
            # to 255 here loses at most 1/256 of a unit — accepted for MVP
            # rather than reclassifying the vertex as SK1 after the fact.
            w_lo = min(255, merged.get(b_lo, 0))
            w_hi = min(255, merged.get(b_hi, 0))
            sk2_key = _first_sk2_entry_by_pair.get((b_lo, b_hi), ('new_sk2', b_lo, b_hi))
            sk2_groups.setdefault(sk2_key, []).append(
                (sub_idx, v_idx, w_lo, w_hi, obj))

            if len(parsed) > 2:
                for bone_id, unit in quantized:
                    if bone_id in (b_lo, b_hi):
                        continue
                    skacc_groups.setdefault(bone_id, []).append(
                        (sub_idx, v_idx, unit, v_idx, obj))

    if overweighted:
        detail = "; ".join(
            f"{name} vertex {idx} ({count} bones)" for name, idx, count in overweighted
        )
        raise ValueError(
            f"{len(overweighted)} vertex(es) exceed the {MAX_BONE_INFLUENCES_PER_VERTEX}-bone "
            f"influence limit: {detail}. "
            f"Remove some nonzero-weight bone_<id> vertex groups from these vertices."
        )

    if unweighted:
        detail = "; ".join(f"{name} vertex {idx}" for name, idx in unweighted)
        ignored_detail = (
            f" Ignored vertex groups (not donor-skinned bones): "
            f"{', '.join(sorted(ignored_group_names))}."
            if ignored_group_names else ""
        )
        raise ValueError(
            f"{len(unweighted)} vertex(es) have no valid donor bone influence: "
            f"{detail}.{ignored_detail}"
        )

    for _name in sorted(ignored_group_names):
        warnings.append(
            f"Vertex group '{_name}' does not resolve to a donor-skinned bone; ignored.")

    # A Blender vertex group holds only one weight per (vertex, bone), so donor
    # SKAcc entries that accumulate twice onto the same dest slot cannot survive
    # the round trip.  Rebuild those entries from the donor dest/weight arrays,
    # taking only the bind-pose source from Blender.
    _obj_by_sub = {sub_idx: obj for _, (sub_idx, obj) in obj_to_sub.items()}

    def _resolve_global_vertex(global_idx):
        for _sub_idx, _start in enumerate(_sub_vtx_starts):
            if _start <= global_idx < _start + _sub_vtx_counts[_sub_idx]:
                _obj = _obj_by_sub.get(_sub_idx)
                if _obj is None:
                    return None
                _local = global_idx - _start
                if _local >= len(_obj.data.vertices):
                    return None
                return _sub_idx, _local, _obj
        return None

    for _e in skin_data.get('SKAccs', []):
        _n = _e['VertexCnt']
        if _n == 0:
            continue
        _dests = list(struct.unpack(f'>{_n}H', _to_bytes(_e['DestIndexData'])))
        if len(set(_dests)) == _n:
            continue
        _weights = _to_bytes(_e['WeightData'])
        _dest_base = _e.get('GplDestArrValue', 0) // _vertex_stride
        _current = {_sub_vtx_starts[entry[0]] + entry[1]
                    for entry in skacc_groups.get(_e['BoneIndex'], [])}
        if _current != {_dest_base + _di for _di in _dests}:
            # This bone's accumulation membership was edited: restoring the
            # donor entry would silently undo the edit (or resurrect a bone
            # that lost every vertex), so keep the Blender-built entry.
            warnings.append(
                f"SKAcc bone {_e['BoneIndex']}: membership edited, duplicate dest "
                f"slots (donor 255+1 weights) rebuilt from Blender weights")
            continue
        _rebuilt = []
        for _di, _w in zip(_dests, _weights):
            _loc = _resolve_global_vertex(_dest_base + _di)
            if _loc is None:
                _rebuilt = None
                break
            _sub_idx, _local_v, _obj = _loc
            _rebuilt.append((_sub_idx, _local_v, _w, _di, _obj))
        if _rebuilt is None:
            warnings.append(
                f"SKAcc bone {_e['BoneIndex']}: duplicate dest slots could not be "
                f"resolved to mesh vertices; entry left as rebuilt from Blender")
            continue
        skacc_groups[_e['BoneIndex']] = _rebuilt

    def encode_src(entries):
        raw = bytearray()
        for entry in entries:
            obj_ref = entry[-1]
            v       = obj_ref.data.vertices[entry[1]]
            _cn     = custom_normals_cache.get(id(obj_ref))
            nx, ny, nz = (_cn[v.index].x, _cn[v.index].y, _cn[v.index].z) if _cn is not None else (v.normal.x, v.normal.y, v.normal.z)
            for component, val in zip(
                ('x', 'y', 'z', 'nx', 'ny', 'nz'),
                (v.co.x, v.co.y, v.co.z, nx, ny, nz),
            ):
                raw += pack_val(
                    val,
                    f"{obj_ref.name} vertex {v.index} SKN {component}",
                )
        return _from_bytes(bytes(raw), use_compression)

    # sk1_groups/sk2_groups keys are either a donor SK1s/SK2s entry INDEX
    # (int) or a ('new_sk1', bone_id) / ('new_sk2', lo, hi) sentinel for a
    # bone/pair with no existing donor entry. Resolve each key back to its
    # BoneIndex(es)/GplVertexArrValue: an existing entry's GPL value is a
    # harmless best-effort hint for the no-membership-change case (Geometry
    # Rebuild recomputes it unconditionally whenever MembershipEdited is
    # set), and a synthetic entry gets a 0 placeholder — never read as final
    # data either.
    orig_sk1s_list = skin_data.get('SK1s', [])
    orig_sk2s_list = skin_data.get('SK2s', [])

    def _sk1_identity(key):
        if isinstance(key, int):
            e = orig_sk1s_list[key]
            return e['BoneIndex'], e.get('GplVertexArrValue', 0)
        return key[1], 0  # ('new_sk1', bone_id)

    def _sk2_identity(key):
        if isinstance(key, int):
            e = orig_sk2s_list[key]
            b_lo = min(e['BoneIndex1'], e['BoneIndex2'])
            b_hi = max(e['BoneIndex1'], e['BoneIndex2'])
            return b_lo, b_hi, e.get('GplVertexArrValue', 0)
        return key[1], key[2], 0  # ('new_sk2', lo, hi)

    _orig_skacc_gda = {
        e['BoneIndex']: e.get('GplDestArrValue', 0)
        for e in skin_data.get('SKAccs', [])
    }

    # VertexIndices: skinned position-slot index of each member, in payload
    # order. The build tool splits an entry into contiguous runs from these
    # instead of value-matching bind-pose records (ambiguous for duplicates).
    def encode_vertex_indices(entries):
        return _from_bytes(
            struct.pack(f'>{len(entries)}H', *(entry[1] for entry in entries)), use_compression)

    new_sk1s = []
    for key in sorted(sk1_groups, key=lambda k: _sk1_identity(k)[0]):
        entries = sk1_groups[key]
        bone_id, gpl_value = _sk1_identity(key)
        new_sk1s.append({
            "BoneIndex": bone_id,
            "VertexCnt": len(entries),
            "BindPoseData": encode_src(entries),
            "VertexIndices": encode_vertex_indices(entries),
            "GplVertexArrValue": gpl_value,
        })

    new_sk2s = []
    for key in sorted(sk2_groups, key=lambda k: _sk2_identity(k)[:2]):
        entries = sk2_groups[key]
        b_lo, b_hi, gpl_value = _sk2_identity(key)
        wt = bytearray()
        for e in entries:
            wt.append(max(0, min(255, e[2])))
            wt.append(max(0, min(255, e[3])))
        new_sk2s.append({
            "BoneIndex1": b_lo, "BoneIndex2": b_hi,
            "VertexCnt": len(entries),
            "BindPoseData": encode_src(entries),
            "WeightData": _from_bytes(bytes(wt), use_compression),
            "VertexIndices": encode_vertex_indices(entries),
            "GplVertexArrValue": gpl_value,
        })

    new_skaccs = []
    for bone_id, entries in sorted(skacc_groups.items()):
        wt   = bytearray()
        dest = bytearray()
        for e in entries:
            wt   += bytes([max(0, min(255, e[2]))])
            dest += struct.pack('>H', e[3])
        new_skaccs.append({
            "BoneIndex": bone_id, "VertexCnt": len(entries),
            "BindPoseData":   encode_src(entries),
            "WeightData":    _from_bytes(bytes(wt), use_compression),
            "DestIndexData": _from_bytes(bytes(dest), use_compression),
            "GplDestArrValue": _orig_skacc_gda.get(bone_id, 0),
        })

    flush_ind_size = skin_data.get('FlushIndSize', 0)

    candidate_edited = {
        "QuantizeInfo": quant_info,
        "SK1s":         new_sk1s,
        "SK2s":         new_sk2s,
        "SKAccs":       new_skaccs,
    }
    if membership_edited:
        # A changed bone set takes the body rebuild (SkinnedRebuild), which
        # is decided before this encoder runs; reaching this means the body
        # object was not planned for it.
        raise ValueError(
            "vertices moved between bones, but the body was not routed to the body rebuild; "
            "export the body object itself (not only other parts) so its skin can be rebuilt"
        )

    orig_size = _skn_block_size(skin_data)
    edit_size = _skn_block_size(candidate_edited, flush_ind_size=flush_ind_size)

    # Per-category vertex totals — used in both feedback paths.
    orig_sk1s   = skin_data.get('SK1s',   [])
    orig_sk2s   = skin_data.get('SK2s',   [])
    orig_skaccs = skin_data.get('SKAccs', [])
    orig_v1 = sum(e['VertexCnt'] for e in orig_sk1s)
    orig_v2 = sum(e['VertexCnt'] for e in orig_sk2s)
    orig_v3 = sum(e['VertexCnt'] for e in orig_skaccs)
    edit_v1 = sum(e['VertexCnt'] for e in new_sk1s)
    edit_v2 = sum(e['VertexCnt'] for e in new_sk2s)
    edit_v3 = sum(e['VertexCnt'] for e in new_skaccs)

    # The hammerspace rebuild always uses vertex_offset=0, so BindPoseData blobs
    # omit the VertexOffset prefix bytes present in original SK1/SK2 entries.
    # Add those bytes back to edit_size so the comparison reflects actual payload
    # content: when SK1/SK2/SKAcc entries and vertex counts are identical the sizes
    # compare as equal and no spurious shrinkage message is shown.
    def _a4_vo(n): return (n + 3) & ~3
    vo_adjustment = (
        sum(_a4_vo(e.get('VertexOffset', 0)) for e in orig_sk1s) +
        sum(_a4_vo(e.get('VertexOffset', 0)) for e in orig_sk2s)
    )
    edit_size_adj = edit_size + vo_adjustment

    def _sk_stats(n1, v1, n2, v2, n3, v3, total):
        return (
            f"{total} B  "
            f"SK1: {n1} entries / {v1} verts  "
            f"SK2: {n2} entries / {v2} verts  "
            f"SKAcc: {n3} entries / {v3} verts"
        )

    if edit_size > orig_size:
        # Size growth is fine in hammerspace mode — the block is written to the
        # extended region of the dat file with no in-place size constraint.
        # (The hard overflow guard only applies to in-place mode, which uses
        # encode_skin_weights_inplace instead of this function.)
        overflow = edit_size - orig_size
        candidate_edited["FlushIndSize"] = flush_ind_size
        data["SluggiesModel"]["SkinDataEdited"] = candidate_edited
        msg = (
            f"SKN block grew by {overflow} B (hammerspace accommodates this).\n"
            f"  Original: {_sk_stats(len(orig_sk1s), orig_v1, len(orig_sk2s), orig_v2, len(orig_skaccs), orig_v3, orig_size)}\n"
            f"  Edited:   {_sk_stats(len(new_sk1s), edit_v1, len(new_sk2s), edit_v2, len(new_skaccs), edit_v3, edit_size)}"
        )
        return True, msg

    effective_shrinkage = orig_size - edit_size_adj
    candidate_edited["FlushIndSize"] = flush_ind_size
    data["SluggiesModel"]["SkinDataEdited"] = candidate_edited

    if effective_shrinkage > 0:
        verts_match = (edit_v1 == orig_v1 and edit_v2 == orig_v2 and edit_v3 == orig_v3)
        msg = (
            f"SKN block shrunk by {effective_shrinkage} B; patcher will zero-pad the remainder.\n"
            f"  Original: {_sk_stats(len(orig_sk1s), orig_v1, len(orig_sk2s), orig_v2, len(orig_skaccs), orig_v3, orig_size)}\n"
            f"  Edited:   {_sk_stats(len(new_sk1s), edit_v1, len(new_sk2s), edit_v2, len(new_skaccs), edit_v3, edit_size)}"
        )
        if not verts_match:
            msg += (
                "\n  Note: SKAcc vertex count differs from original — this is normal"
                " when some SKAcc dest slots fall outside submesh 0 (e.g. Head/Accessory"
                " submeshes). Those vertices are not part of the edited mesh and do not"
                " affect main-mesh skinning. Hammerspace write can proceed."
            )
        return True, msg
    return True, None


def _skin_data_edited_is_empty(data):
    """True when SkinDataEdited exists but carries no SK entry at all while the
    donor SkinData does.

    That combination is not something a real edit can produce -- it is the
    signature of an export that ran without the skinned mesh selected, before
    `skinned_donor_objects` gated the encode. Applying it would strip the
    model's skinning, and the patcher rejects it outright.
    """
    model = data.get("SluggiesModel", {})
    edited = model.get("SkinDataEdited")
    donor = model.get("SkinData")
    if not edited or not donor:
        return False
    lists = ("SK1s", "SK2s", "SKAccs")
    return (
        not any(edited.get(name) for name in lists)
        and any(donor.get(name) for name in lists)
    )


def _purge_skn_edited(data):
    """Strip all *Edited keys from SkinData SK entries and remove SkinDataEdited.

    Called at the start of every export so stale fields from a previous run
    never bleed into the new output.
    """
    model = data.get("SluggiesModel", {})
    model.pop("SkinDataEdited", None)
    skin = model.get("SkinData")
    if not skin:
        return
    sk1_keys   = ("BindPoseDataEdited", "VertexCntEdited", "BoneIndexEdited")
    sk2_keys   = ("BindPoseDataEdited", "WeightDataEdited", "VertexCntEdited")
    skacc_keys = ("BindPoseDataEdited", "WeightDataEdited", "DestIndexDataEdited", "VertexCntEdited")
    for e in skin.get("SK1s",   []):
        for k in sk1_keys:   e.pop(k, None)
    for e in skin.get("SK2s",   []):
        for k in sk2_keys:   e.pop(k, None)
    for e in skin.get("SKAccs", []):
        for k in skacc_keys: e.pop(k, None)


def detect_length_mismatches(obj, json_submesh):
    """Return a list of human-readable strings describing any buffer-length
    changes that need a Hammerspace export.

    Checks vertex buffer and all UV channels.  An empty list means all lengths
    are compatible with in-place patching.
    """
    issues = []
    vb = json_submesh.get("VertexBuffer", {})
    comp_count = vb.get("VertexBufferCompCount", 3)
    quant_info = vb.get("VertexBufferQuantizeInfo", 0)
    fmt = quant_info >> 4
    cs  = 4 if fmt in [4, 7, 0xa] else 2
    expected_vb_len = vb.get("VertexBufferLength", 0)
    actual_vb_len   = len(obj.data.vertices) * comp_count * cs
    if actual_vb_len != expected_vb_len:
        orig_vcount = expected_vb_len // (comp_count * cs) if comp_count * cs else 0
        issues.append(
            f"vertex count changed: {orig_vcount} → {len(obj.data.vertices)} "
            f"(buffer {expected_vb_len} B → {actual_vb_len} B)"
        )

    for ch in json_submesh.get("UVChannels", []):
        ch_ind       = ch.get("UVChannelIndex", 0)
        uv_comp      = ch.get("UVChannelCompCount", 2)
        uv_quant     = ch.get("UVChannelQuantizeInfo", 0)
        uv_cs        = 4 if (uv_quant >> 4) in [4, 7, 0xa] else 2
        orig_uv_len  = ch.get("UVChannelLength", 0)
        orig_uv_cnt  = orig_uv_len // (uv_comp * uv_cs) if uv_comp * uv_cs else 0
        # Count distinct UV coords in the Blender layer via UVFacesData slot range
        uv_faces_raw = ch.get("UVFacesData")
        if uv_faces_raw:
            import struct as _st
            raw   = _to_bytes(uv_faces_raw)
            n     = len(raw) // 2
            slots = list(_st.unpack(f'>{n}H', raw))
            new_uv_cnt = max(slots) + 1 if slots else 0
        else:
            new_uv_cnt = orig_uv_cnt
        if new_uv_cnt != orig_uv_cnt:
            issues.append(
                f"UV channel {ch_ind} slot count changed: {orig_uv_cnt} → {new_uv_cnt}"
            )

    return issues


def validate_against_json(obj, json_submesh):
    """Return a list of mismatch descriptions, empty if everything matches."""
    vb = json_submesh.get("VertexBuffer", {})
    mismatches = []
    for prop in REQUIRED_PROPS:
        obj_val = obj.get(prop)
        json_val = vb.get(prop)
        if obj_val is None:
            mismatches.append(f"object missing custom property '{prop}'")
        elif str(obj_val) != str(json_val):
            mismatches.append(f"{prop}: object={obj_val}, json={json_val}")
    return mismatches


NEW_SURFACE_BODY_MESSAGE = (
    "Partial face moves and new materials are supported on rigid submeshes only; "
    "on the body, move every face of a surface or none"
)


def _find_new_materials(obj, json_submesh, submesh_index=None):
    """Return a list of (material_name, reason) for materials that are NOT donor surfaces.

    A material is a valid donor surface when:
      - new path (2.2+): it carries a SurfaceId that exists in the donor's display states, or
      - legacy path: its name ends with ``_mat{tex_idx}`` where tex_idx is a texture index
        present in the donor's FaceTextureIndices.

    An Add-material surface (``SluggiesNewSurface``) is accepted on a rigid
    donor submesh when its ``SluggiesSurfaceOwner`` is that submesh
    (``sm<submesh_index>``); it is rejected on
    the skinned body and when it belongs to another submesh. Any other
    material (no SurfaceId, unknown SurfaceId, or unparseable legacy name) is
    rejected.

    A custom submesh (``SluggiesCustomSubmesh``) has no donor submesh to compare
    against — it accepts exactly its own ``<CustomSubmeshId>_ds*`` SurfaceIds
    and its own Add-material surfaces
    (``SluggiesNewSurface`` with ``SluggiesSurfaceOwner`` = its
    ``CustomSubmeshId``) and rejects
    everything else.
    """
    if obj.get("SluggiesCustomSubmesh"):
        custom_id = str(obj.get("CustomSubmeshId"))
        own_prefix = f'{custom_id}_ds'
        new_materials = []
        for slot in obj.material_slots:
            mat = slot.material
            if mat is None:
                continue
            sid = mat.get("SurfaceId")
            if mat.get("SluggiesNewSurface"):
                owner = mat.get("SluggiesSurfaceOwner")
                if owner != custom_id:
                    new_materials.append((mat.name, f"belongs to {owner or 'another submesh'}, not {custom_id}"))
                continue
            if not sid or not sid.startswith(own_prefix):
                reason = (f"SurfaceId '{sid}' is not this custom submesh's own surface"
                          if sid else "no SurfaceId")
                new_materials.append((mat.name, reason))
        return new_materials

    display_states = json_submesh.get("DisplayStates", [])
    donor_sids = {
        ds.get("SurfaceId") for ds in display_states if ds.get("SurfaceId")
    }

    # Legacy donor texture indices (old exports without SurfaceId/FaceCount).
    # FaceTextureIndices is an encoded uint16 BE array, one texture index per face.
    donor_tex_idxs = set()
    fti_raw = json_submesh.get("FaceTextureIndicesEdited") or json_submesh.get("FaceTextureIndices")
    if fti_raw:
        try:
            raw = _to_bytes(fti_raw)
            n = len(raw) // 2
            donor_tex_idxs = set(struct.unpack(f'>{n}H', raw))
        except Exception:
            donor_tex_idxs = set()

    owner_key = f"sm{submesh_index}" if submesh_index is not None else None
    new_materials = []
    for slot in obj.material_slots:
        mat = slot.material
        if mat is None:
            continue
        sid = mat.get("SurfaceId")
        if mat.get("SluggiesNewSurface"):
            owner = mat.get("SluggiesSurfaceOwner")
            if owner_key is not None and owner != owner_key:
                new_materials.append((mat.name, f"belongs to {owner or 'another submesh'}, not {owner_key}"))
            continue
        if sid:
            if sid not in donor_sids:
                new_materials.append((mat.name, f"SurfaceId '{sid}' is not a donor surface"))
            continue
        # No SurfaceId: legacy material — must be named '{...}_mat{tex_idx}' with a
        # donor texture index.
        try:
            tex_idx = int(mat.name.rsplit('_mat', 1)[1])
        except (IndexError, ValueError):
            new_materials.append((mat.name, "no SurfaceId and not a donor material name"))
            continue
        if donor_tex_idxs and tex_idx not in donor_tex_idxs:
            new_materials.append((mat.name, f"texture index {tex_idx} is not a donor texture"))
    return new_materials


def _connected_image_texture_nodes(material):
    """Return image nodes reachable from the active Material Output surface."""
    node_tree = getattr(material, "node_tree", None)
    if not getattr(material, "use_nodes", False) or node_tree is None:
        return []

    output_nodes = [
        node for node in node_tree.nodes
        if getattr(node, "type", None) == 'OUTPUT_MATERIAL'
    ]
    active_outputs = [
        node for node in output_nodes if getattr(node, "is_active_output", False)
    ]
    if active_outputs:
        output = active_outputs[0]
    elif len(output_nodes) == 1:
        output = output_nodes[0]
    else:
        return []

    try:
        surface = output.inputs['Surface']
    except (KeyError, TypeError):
        return []

    found = []
    visited = set()

    def visit_node(node):
        # Each link.from_node read makes a new Python wrapper, so id() differs
        # for one node reached over several links (e.g. Color and Alpha).
        as_pointer = getattr(node, "as_pointer", None)
        identity = as_pointer() if callable(as_pointer) else id(node)
        if identity in visited:
            return
        visited.add(identity)
        if getattr(node, "type", None) == 'TEX_IMAGE':
            found.append(node)
        for input_socket in getattr(node, "inputs", ()):
            for link in getattr(input_socket, "links", ()):
                source = getattr(link, "from_node", None)
                if source is not None:
                    visit_node(source)

    for link in getattr(surface, "links", ()):
        source = getattr(link, "from_node", None)
        if source is not None:
            visit_node(source)
    return found


# Mirrors texture_helper._TEMPLATE_FOOTPRINT_FIELDS plus the fields an
# addition overwrites: what remains is what a template lends an appended
# texture (format and sampler fields). Duplicated because the add-on stays
# standalone.
_TEMPLATE_UNLENT_FIELDS = frozenset((
    "Width", "Height", "ImageDataOffset", "ImageDataLength",
    "ImagePayloadLength", "ImageDataCapacity", "TextureDescriptorOffset",
    "TextureIndex", "TextureFileName", "AdditionalMipCount",
    "PaletteEntries", "PaletteFormat",
))


def _template_signature(descriptor):
    """The format and sampler fields a template descriptor lends an addition."""
    return json.dumps(
        {k: v for k, v in descriptor.items() if k not in _TEMPLATE_UNLENT_FIELDS},
        sort_keys=True, default=str,
    )


def _resolve_material_texture_changes(
    object_submeshes,
    descriptors,
    tex_dir,
    path_resolver=os.path.abspath,
    validate_texture_files=True,
    skip_unset_images=False,
    require_donor_files=True,
    planned_copies=None,
):
    """Classify connected material images without mutating Blender or JSON data.

    *skip_unset_images*: an image node without an image keeps the material's
    texture instead of failing (a `_L_` model, whose PNGs live in the main
    model's folder and may not have been found on import).

    *require_donor_files* False: only a new PNG (an addition) must exist in
    tex/; an image named like a donor texture is not read (Reimport textures
    off: the donor payloads are kept).

    *planned_copies* (a dict, see `_plan_external_texture_copy`): an existing
    PNG outside tex/ that the export reads is planned as a copy into tex/
    instead of failing, and an image in another format (TextureConvert) as
    its PNG conversion; the caller performs the copies."""
    descriptor_by_name = {
        descriptor.get("TextureFileName"): int(descriptor["TextureIndex"])
        for descriptor in descriptors
        if descriptor.get("TextureFileName")
    }
    donor_count = len(descriptors)
    additions = []
    # (file name, template signature) -> appended index. One PNG shown by
    # several materials is appended once and shared, instead of being encoded
    # and stored once per material.
    appended_index_by_key = {}
    assignments = {}
    changed_materials = []

    for obj, _json_submesh in object_submeshes:
        for slot in obj.material_slots:
            material = slot.material
            if material is None:
                continue
            surface_id = material.get("SurfaceId")
            if not surface_id:
                continue
            if material.get("SluggiesNewSurface"):
                # An Add-material surface has no donor TextureIndex; its image
                # is resolved with the custom-submesh resolver instead.
                continue

            image_nodes = _connected_image_texture_nodes(material)
            if len(image_nodes) > 1:
                raise ValueError(
                    f"Multiple textures in one material are not supported: {material.name}"
                )
            if not image_nodes:
                continue
            image = getattr(image_nodes[0], "image", None)
            image_path = (
                getattr(image, "filepath_raw", "") or getattr(image, "filepath", "")
                if image is not None else ""
            )
            if not image_path and skip_unset_images:
                continue
            if not image_path:
                raise ValueError(f"Material image has no file path: {material.name}")

            resolved_path = path_resolver(image_path)
            file_name = os.path.basename(os.path.normpath(resolved_path))
            source_path = os.path.abspath(os.path.normpath(resolved_path))
            convert = TextureConvert.needs_conversion(file_name)
            problem = TextureConvert.convert_problem(source_path) if convert else None
            if problem:
                raise ValueError(
                    f"Material '{material.name}' image must be a "
                    f"{TextureConvert.FORMAT_NAMES}: {file_name} {problem}"
                )
            local_path = os.path.join(tex_dir, file_name)
            desired_index = descriptor_by_name.get(file_name)
            if planned_copies is not None and validate_texture_files and (
                require_donor_files or desired_index is None
            ) and os.path.isfile(source_path) and (convert or (
                os.path.normcase(os.path.dirname(source_path))
                != os.path.normcase(os.path.abspath(tex_dir))
            )):
                # Linked from outside tex/ (or another format, converted):
                # copied in (or an identical file there reused); a name tex/
                # holds with other bytes takes a free name, which then
                # appends a new texture.
                file_name = _plan_external_texture_copy(source_path, tex_dir, planned_copies)
                local_path = os.path.join(tex_dir, file_name)
                desired_index = descriptor_by_name.get(file_name)
            if validate_texture_files and file_name not in (planned_copies or {}) and (
                require_donor_files or desired_index is None
            ) and not os.path.isfile(local_path):
                raise ValueError(
                    f"Texture PNG for material '{material.name}' must exist in "
                    f"the resolved tex folder: {local_path}"
                )

            original_index = int(material.get("TextureIndex", -1))
            if original_index < 0 or original_index >= donor_count:
                raise ValueError(
                    f"Material '{material.name}' has invalid donor TextureIndex "
                    f"{original_index}"
                )
            if desired_index is None:
                key = (file_name, _template_signature(descriptors[original_index]))
                desired_index = appended_index_by_key.get(key)
            if desired_index is None:
                desired_index = donor_count + len(additions)
                if desired_index > 0x1FFF:
                    raise ValueError(
                        "the appended texture index exceeds the Type-1 13-bit field"
                    )
                additions.append({
                    "TextureFileName": file_name,
                    "TemplateTextureIndex": original_index,
                })
                appended_index_by_key[key] = desired_index

            if desired_index != original_index:
                if surface_id in assignments:
                    raise ValueError(
                        f"SurfaceId '{surface_id}' is assigned by multiple materials"
                    )
                assignments[surface_id] = desired_index
                changed_materials.append(material.name)

    return additions, assignments, changed_materials


def _custom_submesh_texture_layer(mode):
    """Decode a Type-1 ShaderMode hex string into (layer, texture_index).
    Bits 13-15 are the texture layer, bits 0-12 are the texture index. Duplicated from
    HammerspaceMain._custom_submesh_texture_layer because the add-on stays
    standalone (no SluggiesTools imports)."""
    setting = int(mode, 16)
    return ((setting >> 13) & 7, setting & 0x1FFF)


def _custom_submesh_template_texture_index(model, template_source):
    """Resolve a CustomSubmesh's TemplateSource to the donor texture index
    its new descriptor should clone the GX format from. A custom submesh has no donor material of its own, so
    this walks the same donor DisplayStates a `rigid:`/`derived:`/`builtin:`
    template resolves against at build time (mirroring
    HammerspaceMain._custom_submesh_rigid_records/_derived_records/
    _builtin_records) to find the effective layer-0 Type-1 texture index:

    - `rigid:<SurfaceId>`: the template submesh's own effective layer-0
      texture at that surface.
    - `derived:<SurfaceId>`: submesh 0's effective layer-0 texture at that
      surface.
    - `builtin:<name>`: the host model's own submesh 0, first layer-0
      texture encountered (builtin templates are model-independent and
      always rebind to the host's own submesh-0 texture).
    """
    submeshes = model.get('Submeshes') or []
    submesh0_states = (submeshes[0].get('DisplayStates') if submeshes else None) or []

    def _effective_layer0(states, up_to_index):
        layer0 = None
        for state in states[:up_to_index + 1]:
            if int(state.get('DisplayStateId', -1)) != 1:
                continue
            layer, texture_index = _custom_submesh_texture_layer(state['ShaderMode'])
            if layer == 0:
                layer0 = texture_index
        return layer0

    if template_source.startswith('rigid:'):
        surface_id = template_source[len('rigid:'):]
        for submesh in submeshes:
            states = submesh.get('DisplayStates') or []
            for index, state in enumerate(states):
                if state.get('SurfaceId') != surface_id:
                    continue
                layer0 = _effective_layer0(states, index)
                if layer0 is None:
                    raise ValueError(
                        f"Template surface '{surface_id}' has no layer-0 texture"
                    )
                return layer0
        raise ValueError(f"Template surface '{surface_id}' not found in donor submeshes")

    if template_source.startswith('derived:'):
        surface_id = template_source[len('derived:'):]
        for index, state in enumerate(submesh0_states):
            if state.get('SurfaceId') != surface_id:
                continue
            layer0 = _effective_layer0(submesh0_states, index)
            if layer0 is None:
                raise ValueError(
                    f"Derived surface '{surface_id}' has no layer-0 texture"
                )
            return layer0
        raise ValueError(f"Derived surface '{surface_id}' not found in submesh 0")

    if template_source.startswith('builtin:'):
        for state in submesh0_states:
            if int(state.get('DisplayStateId', -1)) != 1:
                continue
            layer, texture_index = _custom_submesh_texture_layer(state['ShaderMode'])
            if layer == 0:
                return texture_index
        raise ValueError("Host model's submesh 0 has no layer-0 texture")

    raise ValueError(f"Unrecognized TemplateSource: {template_source!r}")


def _plan_external_texture_copy(source_path, tex_dir, planned_copies, reserved_names=()):
    """Pick the tex/ file name an image outside tex/ is copied to on export.

    The patcher only reads bare file names from the model's tex/ folder, so an
    external PNG is copied in. The first free name among ``<stem>.png``,
    ``<stem>_1.png``, ... wins, where a name is usable when tex/ has no such
    file (and no other source is already planned for it), or when the file
    there is byte-identical to the source. That reuse keeps repeated exports
    from piling up copies, and an identical copy of a donor PNG still rebinds
    to that donor texture. A `reserved_names` entry (a donor descriptor's
    TextureFileName) is never claimed as a fresh copy target, even when its
    file is missing from tex/.

    An image in another format is converted first (TextureConvert): its PNG
    is what is copied and compared, under ``<stem>.png``, ``<stem>_1.png``,
    ... Raises ValueError when it cannot be converted.

    `planned_copies` maps tex/ file name -> source path (the converted PNG
    for another format) and is updated in place. Returns the chosen file name.
    """
    file_name = os.path.basename(source_path)
    stem, ext = os.path.splitext(file_name)
    if TextureConvert.needs_conversion(file_name):
        source_path = TextureConvert.converted_png(source_path)
        file_name, ext = TextureConvert.converted_name(file_name), '.png'
    try:
        with open(source_path, 'rb') as source_file:
            source_bytes = source_file.read()
    except OSError:
        source_bytes = None

    suffix = 0
    while True:
        candidate = file_name if suffix == 0 else f"{stem}_{suffix}{ext}"
        suffix += 1
        planned_source = planned_copies.get(candidate)
        if planned_source is not None:
            if os.path.normcase(planned_source) == os.path.normcase(source_path):
                return candidate
            continue
        target_path = os.path.join(tex_dir, candidate)
        if not os.path.exists(target_path):
            if candidate in reserved_names:
                continue
            planned_copies[candidate] = source_path
            return candidate
        if source_bytes is not None and os.path.isfile(target_path):
            try:
                with open(target_path, 'rb') as target_file:
                    if target_file.read() == source_bytes:
                        return candidate
            except OSError:
                pass


def _resolve_custom_submesh_texture_changes(
    custom_submesh_entries,
    descriptors,
    tex_dir,
    path_resolver=os.path.abspath,
    validate_texture_files=True,
    planned_copies=None,
):
    """Resolve each custom submesh material's connected image into a
    TextureAssignment. Applies the same
    per-material image-inspection rules as _resolve_material_texture_changes,
    but a custom submesh has no donor material to read a `TextureIndex`
    from: each entry instead supplies the donor texture index its template
    clones its GX format from (`_custom_submesh_template_texture_index`).

    Unlike donor materials, a custom submesh image may live outside tex/:
    it is planned as a copy into tex/ (`_plan_external_texture_copy`, which
    also converts other formats to PNG) that the caller performs once the
    export is otherwise validated.

    `custom_submesh_entries` is a list of (material, template_texture_index)
    pairs. Returns (additions, assignment_by_material_name, texture_copies):
    - `additions` is in the same shape as _resolve_material_texture_changes
      produces, appendable to AdditionalTextureDescriptors.
    - `assignment_by_material_name` maps each material's name to a dict
      usable directly as a CustomSubmesh TextureAssignment: either
      {"DonorTextureIndex": n} when the image already matches an existing
      descriptor (a rebind, "as before"), or
      {"AdditionalTextureFileName": name} for a newly appended one.
    - `texture_copies` is a list of (source_path, tex_dir_path) pairs.

    *planned_copies*: a dict shared with the other resolvers of one export,
    so no two sources claim one tex/ name (`texture_copies` then lists the
    shared plan).
    """
    descriptor_by_name = {
        descriptor.get("TextureFileName"): int(descriptor["TextureIndex"])
        for descriptor in descriptors
        if descriptor.get("TextureFileName")
    }
    donor_count = len(descriptors)
    additions = []
    assignments = {}
    if planned_copies is None:
        planned_copies = {}

    for material, template_texture_index in custom_submesh_entries:
        if template_texture_index < 0 or template_texture_index >= donor_count:
            raise ValueError(
                f"Material '{material.name}' has invalid template texture index "
                f"{template_texture_index}"
            )

        image_nodes = _connected_image_texture_nodes(material)
        if len(image_nodes) > 1:
            raise ValueError(
                f"Multiple textures in one material are not supported: {material.name}"
            )
        if not image_nodes:
            raise ValueError(
                f"Custom submesh material has no connected texture: {material.name}"
            )
        image = getattr(image_nodes[0], "image", None)
        image_path = (
            getattr(image, "filepath_raw", "") or getattr(image, "filepath", "")
            if image is not None else ""
        )
        if not image_path:
            raise ValueError(f"Material image has no file path: {material.name}")

        resolved_path = os.path.abspath(os.path.normpath(path_resolver(image_path)))
        file_name = os.path.basename(resolved_path)
        convert = TextureConvert.needs_conversion(file_name)
        problem = TextureConvert.convert_problem(resolved_path) if convert else None
        if problem:
            raise ValueError(
                f"Material '{material.name}' image must be a "
                f"{TextureConvert.FORMAT_NAMES}: {file_name} {problem}"
            )
        if validate_texture_files and not os.path.isfile(resolved_path):
            raise ValueError(
                f"Texture {'image' if convert else 'PNG'} for material "
                f"'{material.name}' does not exist: {resolved_path}"
            )
        in_tex_dir = (
            os.path.normcase(os.path.dirname(resolved_path))
            == os.path.normcase(os.path.abspath(tex_dir))
        )
        if convert or not in_tex_dir:
            file_name = _plan_external_texture_copy(
                resolved_path, tex_dir, planned_copies, descriptor_by_name
            )

        desired_index = descriptor_by_name.get(file_name)
        if desired_index is None:
            desired_index = donor_count + len(additions)
            if desired_index > 0x1FFF:
                raise ValueError(
                    "the appended texture index exceeds the Type-1 13-bit field"
                )
            additions.append({
                "TextureFileName": file_name,
                "TemplateTextureIndex": template_texture_index,
            })
            assignments[material.name] = {"AdditionalTextureFileName": file_name}
        else:
            assignments[material.name] = {"DonorTextureIndex": desired_index}

    texture_copies = [
        (source_path, os.path.join(tex_dir, name))
        for name, source_path in planned_copies.items()
    ]
    return additions, assignments, texture_copies


def _custom_submesh_triangles(obj):
    """Triangulate a custom submesh for export without changing the user's mesh: reads Blender's own loop
    triangles instead of running a Triangulate operator or modifier."""
    mesh = obj.data
    mesh.calc_loop_triangles()
    return CustomSubmeshExport.triangles_from_loop_triangles(mesh.loop_triangles)


def encode_stadium_collision(context, objects, arm_obj, warnings):
    """``StadiumCollision`` entries for the meshes with collision turned on
    (StadiumCollisionExport.py): model-space faces, read like a custom
    submesh's (undeformed mesh, rest pose, transforms applied mathematically)."""
    if not objects:
        return []
    if arm_obj is None:
        raise ValueError(
            f"{objects[0].name}: stadium collision needs the stadium's armature; "
            "select it too (or parent the collision mesh to it)")
    with _armature_rest_pose(context, arm_obj):
        arm_world = _matrix_rows(arm_obj.matrix_world)
        obj_worlds = [_matrix_rows(obj.matrix_world) for obj in objects]
    entries = []
    for obj, obj_world in zip(objects, obj_worlds):
        if obj.mode == 'EDIT':
            obj.update_from_editmode()
        skipped = CustomSubmeshExport.unsupported_modifier_names(
            (modifier.name, modifier.type) for modifier in obj.modifiers)
        if skipped:
            warnings.append(
                f"{obj.name}: modifier(s) {', '.join(skipped)} are not evaluated for its "
                "collision; apply them first or that geometry is not solid in game.")
        settings = obj.sluggies_collision
        try:
            surface_type = StadiumCollisionExport.surface_type_number(
                settings.surface_type, settings.custom_type)
            positions, faces = StadiumCollisionExport.model_space_geometry(
                [tuple(v.co) for v in obj.data.vertices], _custom_submesh_triangles(obj),
                obj_world, arm_world)
            entries.append(StadiumCollisionExport.collision_entry(
                obj.name, positions, faces, surface_type, settings.sides, settings.territory,
                region=obj.get(StadiumCollisionExport.REGION_PROP)))
        except ValueError as exc:
            raise ValueError(f"{obj.name}: {exc}" if not str(exc).startswith(obj.name) else str(exc)) from exc
    return entries


def _custom_submesh_armature(obj):
    """The armature a custom submesh follows: its Armature modifier's object,
    else the nearest armature parent."""
    for modifier in obj.modifiers:
        if modifier.type == 'ARMATURE' and modifier.object is not None:
            return modifier.object
    node = obj.parent
    while node is not None:
        if node.type == 'ARMATURE':
            return node
        node = node.parent
    return None


@contextlib.contextmanager
def _armature_rest_pose(context, arm_obj):
    """Evaluate the scene with *arm_obj* in its rest pose, then restore the
    user's pose setting. An object parented to a bone (or constrained to one)
    gets a pose-dependent ``matrix_world``; the rest pose makes it match the
    bind pose the game positions are relative to."""
    arm_data = arm_obj.data
    previous = arm_data.pose_position
    arm_data.pose_position = 'REST'
    context.view_layer.update()
    try:
        yield
    finally:
        arm_data.pose_position = previous
        context.view_layer.update()


def _matrix_rows(matrix):
    return [list(row) for row in matrix]


def _armature_local_geometry(context, obj, warnings):
    """The skinned body's geometry in armature (model) space: the same steps
    as _custom_submesh_bone_local_geometry with the identity in place of a
    host bone's bind matrix, since skinned positions are stored in model
    space (the SKN bind pose mirrors them)."""
    return _geometry_in_bind_space(context, obj, SkinnedRebuildExport.IDENTITY, warnings)


def _custom_submesh_bone_local_geometry(context, obj, bone_hierarchy, host_bone_id, warnings):
    """World position is authoritative.

    Transforms are applied mathematically, never with ``transform_apply``, so
    the export leaves the user's scene as it was:
    1. flush Edit Mode into the mesh data,
    2. read the undeformed ``mesh.vertices`` (never the evaluated mesh, so the
       Armature modifier and the current pose can't leak into bind positions),
    3-4. map object-local coordinates through the rest-pose world matrices into
       the host bone's bind-local space, using the target .sluggie's own
       BoneHierarchy bind matrices (the importer's placement matrices),
    6. reverse winding when that transform mirrors,
    7. warn about modifiers that export doesn't evaluate.
    Item 5 (normals) uses the returned ``to_bone`` matrix.
    """
    arm_obj = _custom_submesh_armature(obj)
    if arm_obj is None:
        raise ValueError(
            f"{obj.name}: custom submesh has no Armature modifier or armature parent; "
            "it can't be placed relative to its host bone"
        )
    host_bind = CustomSubmeshExport.bone_absolute_matrices(bone_hierarchy).get(host_bone_id)
    if host_bind is None:
        raise ValueError(
            f"{obj.name}: host bone {host_bone_id} does not exist in the target "
            ".sluggie BoneHierarchy"
        )
    return _geometry_in_bind_space(context, obj, host_bind, warnings)


def _geometry_in_bind_space(context, obj, host_bind, warnings):
    """Items 1-7 of _custom_submesh_bone_local_geometry for an already
    resolved *host_bind* matrix (armature-space bind matrix of the host
    bone, or the identity for the skinned body)."""
    arm_obj = _custom_submesh_armature(obj)
    if arm_obj is None:
        raise ValueError(
            f"{obj.name}: mesh has no Armature modifier or armature parent; "
            "it can't be placed relative to the skeleton"
        )
    if obj.mode == 'EDIT':
        obj.update_from_editmode()

    skipped = CustomSubmeshExport.unsupported_modifier_names(
        (modifier.name, modifier.type) for modifier in obj.modifiers
    )
    if skipped:
        warnings.append(
            f"{obj.name}: modifier(s) {', '.join(skipped)} are not evaluated on export; "
            "apply them first or their geometry is missing in game."
        )

    with _armature_rest_pose(context, arm_obj):
        obj_world = _matrix_rows(obj.matrix_world)
        arm_world = _matrix_rows(arm_obj.matrix_world)

    vertex_cos = [tuple(v.co) for v in obj.data.vertices]
    try:
        return CustomSubmeshExport.bone_local_geometry(
            vertex_cos, _custom_submesh_triangles(obj), obj_world, arm_world, host_bind,
        )
    except ValueError as exc:
        raise ValueError(f"{obj.name}: {exc}") from exc


def _custom_submesh_loop_attributes(obj, warnings):
    """Per-loop normals, UVs and colors of a custom submesh, indexed by Blender
    loop index. Call after the geometry,
    which flushes Edit Mode first.

    - Normals are Blender's loop normals (custom split normals when present).
    - UVs come from the render-active UV map. Only one map is exported; the
      game's second channel mirrors it.
    - Colors come from ``color0`` (the importer's name) or else the active
      color attribute, on corner or point domain. No color attribute means
      white.
    """
    mesh = obj.data
    loop_normals = _per_loop_normals(mesh, range(len(mesh.loops)))

    uv_layer = mesh.uv_layers.active_render or mesh.uv_layers.active
    if uv_layer is None:
        raise ValueError(f"{obj.name}: custom submesh has no UV map; add one and unwrap it")
    if len(mesh.uv_layers) > 1:
        warnings.append(
            f"{obj.name}: only UV map '{uv_layer.name}' (render-active) is exported; "
            "other UV maps are ignored."
        )
    loop_uvs = [tuple(uv_layer.data[i].uv) for i in range(len(mesh.loops))]

    color_attribute = mesh.color_attributes.get("color0") or mesh.color_attributes.active_color
    loop_colors = None
    if color_attribute is not None:
        if color_attribute.domain == 'CORNER':
            loop_colors = [tuple(_get_loop_color(color_attribute.data[i])) for i in range(len(mesh.loops))]
        elif color_attribute.domain == 'POINT':
            loop_colors = [
                tuple(_get_loop_color(color_attribute.data[loop.vertex_index])) for loop in mesh.loops
            ]
    return loop_normals, loop_uvs, loop_colors


def _custom_submesh_additional_materials(obj):
    """The Add-material surfaces of a custom submesh that at least one face
    uses, keyed by surface key in slot order. A new-surface material no face uses is reported as ignored."""
    custom_id = str(obj.get("CustomSubmeshId"))
    used_slots = {poly.material_index for poly in obj.data.polygons}
    materials, unused = {}, []
    for slot_index, slot in enumerate(obj.material_slots):
        mat = slot.material
        if mat is None or not mat.get("SluggiesNewSurface") or mat.get("SluggiesSurfaceOwner") != custom_id:
            continue
        key = mat.get("SurfaceId")
        if not key or not RigidRebuildExport.new_surface_key_matches(custom_id, key):
            continue
        if slot_index in used_slots:
            materials.setdefault(key, mat)
        else:
            unused.append(mat.name)
    return materials, unused


def _new_surface_entry(key, mat, texture_assignment):
    """One ``NewSurfaces`` / ``AdditionalSurfaces`` entry for an Add-material
    surface *mat* with its resolved *texture_assignment*."""
    surface = {
        "SurfaceKey": key,
        "MaterialName": mat.name,
        "TemplateSource": str(mat.get("TemplateSource") or ""),
        "TextureAssignment": dict(texture_assignment),
    }
    if "SpecularStrength" in mat:
        surface["SpecularStrength"] = max(0, min(255, int(mat["SpecularStrength"])))
    return surface


def encode_custom_submesh(context, obj, model, texture_assignment, warnings, use_compression=True,
                          specular_strength=None, texture_assignments=None, infos=None):
    """Encode one ``SluggiesCustomSubmesh`` object as a ``CustomSubmeshes``
    entry: triangulate, map world
    positions into host-bone space, range-check and quantize, and encode
    per-loop normals, colors and UVs for the template's attribute set.
    Raises ValueError with the object named.

    *texture_assignments* maps each material name of the object's Add-material
    surfaces to its resolved TextureAssignment; the faces are then routed per
    material and those surfaces become ``AdditionalSurfaces``."""
    host_bone_id = _detect_uniform_vertex_bone_id(obj)
    if host_bone_id is None:
        raise ValueError(
            f"{obj.name}: every vertex must belong to exactly one bone_<id> vertex group "
            "(the host bone), all the same bone"
        )
    template_source = str(obj.get("TemplateSource") or "")
    try:
        plan = CustomSubmeshExport.attribute_plan(model, template_source)
    except ValueError as exc:
        raise ValueError(f"{obj.name}: {exc}") from exc
    bone_hierarchy = model.get("BoneHierarchyEdited") or model.get("BoneHierarchy") or []
    geometry = _custom_submesh_bone_local_geometry(
        context, obj, bone_hierarchy, host_bone_id, warnings,
    )
    loop_normals, loop_uvs, loop_colors = _custom_submesh_loop_attributes(obj, warnings)

    additional_surfaces, face_surface_indices = [], None
    additional_materials, _unused = _custom_submesh_additional_materials(obj)
    if additional_materials:
        primary = _custom_submesh_material(obj)
        routing = RigidRebuildExport.route_custom_submesh_faces(
            obj.name, str(obj.get("CustomSubmeshId")), str(primary.get("SurfaceId")),
            geometry.triangles, [poly.material_index for poly in obj.data.polygons],
            _slot_surfaces(obj),
        )
        warnings.extend(routing.warnings)
        for key in routing.new_keys:
            mat = additional_materials[key]
            if texture_assignments is None or mat.name not in texture_assignments:
                raise ValueError(f"{obj.name}: material '{mat.name}' has no resolved texture")
            additional_surfaces.append(_new_surface_entry(key, mat, texture_assignments[mat.name]))
        face_surface_indices = RigidRebuildExport.custom_submesh_face_surface_indices(routing)
        (infos if infos is not None else warnings).append(
            RigidRebuildExport.surface_report(obj.name, routing))
    return CustomSubmeshExport.build_custom_submesh_entry(
        obj.name, str(obj.get("CustomSubmeshId")), host_bone_id, template_source, plan,
        geometry, loop_normals, loop_uvs, loop_colors, texture_assignment, use_compression,
        warnings, specular_strength, additional_surfaces, face_surface_indices, infos,
    )


def _armature_donor_bone_records(arm_obj):
    """The import-time bone snapshot on *arm_obj* (``SluggiesGeoIdRaw``,
    ``SluggiesSkinned``), donor bones only: user-added bones have no
    counterpart in the target's ``BoneHierarchy``."""
    records = []
    for bone in arm_obj.data.bones:
        if bone.get('SluggiesUserAdded'):
            continue
        bone_id = _bone_id_from_bone_name(bone.name)
        if bone_id is None:
            continue
        parent_id = _bone_id_from_bone_name(bone.parent.name) if bone.parent is not None else None
        records.append(HostBones.BoneRecord(
            bone_id=bone_id,
            parent_id=parent_id,
            geo_id_raw=int(bone.get('SluggiesGeoIdRaw', GEO_ID_FREE)),
            skinned=bool(bone.get('SluggiesSkinned', False)),
        ))
    return records


def validate_custom_submeshes(custom_objects, donor_candidates, model, warnings):
    """Checks on the final scene state
    before any custom submesh is encoded. Raises ValueError on the first
    blocking problem; ignored state goes into *warnings*.

    - Empty meshes are rejected.
    - Shape keys, extra materials and vertex groups other than the host bone
      are ignored with a warning (custom submeshes only; donor heads keep
      their facial shape keys without comment).
    - Each armature's import-time bone snapshot must match the target
      ``.sluggie``, or the armature belongs to another model.
    - Host bones are re-checked with ``classify_host_bones``: a bone taken
      since the cube was created, or claimed twice, is rejected.
    """
    hosts = []
    for obj in custom_objects:
        if obj.mode == 'EDIT':
            obj.update_from_editmode()
        mesh = obj.data
        if not mesh.vertices or not mesh.polygons:
            raise ValueError(f"{obj.name}: custom submesh has no faces")
        host_bone_id = _detect_uniform_vertex_bone_id(obj)
        if host_bone_id is None:
            raise ValueError(
                f"{obj.name}: every vertex must belong to exactly one bone_<id> vertex group "
                "(the host bone), all the same bone"
            )
        hosts.append(HostBones.CustomSubmeshHost(obj.name, host_bone_id))
        material = _custom_submesh_material(obj)
        shape_keys = mesh.shape_keys.key_blocks if mesh.shape_keys else []
        own_surfaces, unused_surfaces = _custom_submesh_additional_materials(obj)
        own_names = {mat.name for mat in own_surfaces.values()}
        warnings.extend(CustomSubmeshExport.ignored_state_warnings(
            obj.name,
            host_bone_id,
            [key.name for key in shape_keys],
            [slot.material.name for slot in obj.material_slots
             if slot.material is not None and slot.material.name not in own_names],
            material.name if material is not None else "",
            [group.name for group in obj.vertex_groups],
        ))
        for name in unused_surfaces:
            warnings.append(f"{obj.name}: material '{name}' is used by no face and is not exported.")

    sluggie_records = HostBones.bone_records_from_hierarchy(
        model.get("BoneHierarchy") or [], model.get("SkinData")
    )
    armatures = {}
    for obj in custom_objects:
        arm_obj = _custom_submesh_armature(obj)
        if arm_obj is not None:
            armatures.setdefault(arm_obj.name, arm_obj)
    for arm_obj in armatures.values():
        if not HostBones.bone_metadata_is_current(arm_obj.get('SluggiesBoneMetadataVersion')):
            raise ValueError(
                f"{arm_obj.name}: armature has no current bone metadata. "
                f"{HostBones.RE_IMPORT_MESSAGE}."
            )
        mismatches = HostBones.bone_metadata_mismatches(
            _armature_donor_bone_records(arm_obj), sluggie_records
        )
        if mismatches:
            shown = "; ".join(mismatches[:5])
            more = f" (and {len(mismatches) - 5} more)" if len(mismatches) > 5 else ""
            raise ValueError(
                f"{arm_obj.name}: armature does not match the target .sluggie "
                f"({shown}{more}). It was imported from a different model; export to "
                "the .sluggie it came from."
            )

    host_records = HostBones.bone_records_from_hierarchy(
        model.get("BoneHierarchyEdited") or model.get("BoneHierarchy") or [],
        model.get("SkinData"),
    )
    retargets, _issues, obj_by_submesh = _candidate_rigid_retargets(donor_candidates, model)
    errors = HostBones.custom_submesh_host_errors(
        host_records, retargets, hosts,
        {index: obj.name for index, obj in obj_by_submesh.items()},
    )
    if errors:
        raise ValueError(" ".join(errors))


def _custom_submesh_material(obj):
    """The material carrying this custom submesh's own ``<CustomSubmeshId>_ds*``
    SurfaceId (the one the Add submesh operator created), first slot wins."""
    prefix = f'{obj.get("CustomSubmeshId")}_ds'
    for slot in obj.material_slots:
        material = slot.material
        if material is not None and str(material.get("SurfaceId") or "").startswith(prefix):
            return material
    return None


def _merge_texture_additions(donor_additions, custom_additions):
    """Append custom submesh texture additions after the donor-material ones.

    Donor additions keep their positions, so the appended indices already
    written into DesiredTextureAssignments stay valid. A PNG that is already
    being appended (by a donor material or another custom submesh) is not
    appended twice: custom submeshes bind by file name, so they share it."""
    merged = list(donor_additions)
    names = {addition["TextureFileName"] for addition in merged}
    for addition in custom_additions:
        if addition["TextureFileName"] not in names:
            merged.append(addition)
            names.add(addition["TextureFileName"])
    return merged


def _partner_added_texture_descriptors(descriptors, additions):
    """Descriptors for the textures a main model's export appends, so its
    `_L_` partner can bind them as existing textures.

    See TextureSlotsCore.partner_added_texture_descriptors.
    """
    return TextureSlotsCore.partner_added_texture_descriptors(descriptors, additions)


def _resolve_export_texture_context(sluggie_path, model, with_owner=False):
    """Return descriptor/path context, borrowing it for a paired `_L_` model.

    A borrowed list also holds the main model's appended textures (indices
    after its own descriptors): the `_L_` model binds textures by index into
    the main model's TEX, so a custom submesh on it can use them once the
    main model is patched.

    *with_owner* appends the paired main model's .sluggie path (None when
    nothing is borrowed), for error messages."""
    def _result(descriptors, tex_dir, owns, owner_path=None):
        if with_owner:
            return descriptors, tex_dir, owns, owner_path
        return descriptors, tex_dir, owns

    model_dir = os.path.dirname(os.path.abspath(sluggie_path))
    local_descriptors = model.get("TextureDescriptors") or []
    if local_descriptors:
        return _result(local_descriptors, os.path.join(model_dir, 'tex'), True)

    folder_name = os.path.basename(model_dir)
    marker_index = folder_name.lower().find('_l_')
    if marker_index < 0:
        return _result([], os.path.join(model_dir, 'tex'), False)

    paired_suffix = folder_name[marker_index + 3:].lower()
    parent_dir = os.path.dirname(model_dir)
    candidates = []
    try:
        sibling_names = sorted(os.listdir(parent_dir))
    except OSError:
        sibling_names = []
    for sibling_name in sibling_names:
        sibling_dir = os.path.join(parent_dir, sibling_name)
        sibling_lower = sibling_name.lower()
        if (
            not os.path.isdir(sibling_dir)
            or '_l_' in sibling_lower
            or not sibling_lower.endswith('_' + paired_suffix)
        ):
            continue
        tex_dir = os.path.join(sibling_dir, 'tex')
        if not os.path.isdir(tex_dir):
            continue
        try:
            sluggie_names = sorted(
                name for name in os.listdir(sibling_dir)
                if name.lower().endswith('.sluggie')
            )
        except OSError:
            continue
        owners = {}
        for sluggie_name in sluggie_names:
            candidate_path = os.path.join(sibling_dir, sluggie_name)
            try:
                candidate_model = FieldCodec.load_sluggie(candidate_path).get('SluggiesModel', {})
            except (OSError, ValueError):
                continue
            if candidate_model.get('TextureDescriptors'):
                owners[candidate_path] = candidate_model
        # Several High files in one folder (variants saved under new names):
        # the one named like this Low file, else the exported one.
        owner_path = ModelCheckCore.pick_partner(list(owners), sluggie_path)
        if owner_path is None and owners:
            raise ValueError(
                f"Low-poly model '{folder_name}': the main model folder '{sibling_name}' holds several "
                f".sluggie files ({', '.join(os.path.basename(p) for p in owners)}) and none is named "
                "like this one or after its folder; rename the one to pair with"
            )
        if owner_path is not None:
            owner_model = owners[owner_path]
            descriptors = owner_model['TextureDescriptors']
            candidates.append((
                TextureSlotsCore.replaced_texture_descriptors(
                    descriptors, owner_model.get('TextureReplacements'),
                ) + _partner_added_texture_descriptors(
                    descriptors,
                    owner_model.get('AdditionalTextureDescriptors') or [],
                ),
                tex_dir,
                owner_path,
            ))

    if len(candidates) > 1:
        raise ValueError(
            f"Low-poly model '{folder_name}' matches multiple sibling texture owners"
        )
    if candidates:
        descriptors, tex_dir, owner_path = candidates[0]
        return _result(descriptors, tex_dir, False, owner_path)
    return _result([], os.path.join(model_dir, 'tex'), False)


# Runtime testing found that cross-mode reassignment is unsafe. In particular,
# changing a hand-role batch from RhSp/LhSp to Spec leaves its primitive list in
# the hand display-state slot, where game-state visibility still suppresses it.
# Only identical effective Type-7 modes are accepted. Flip this flag back to
# False to disable reassignment exports entirely.
ENABLE_MATERIAL_REASSIGNMENT_EXPORT = True


# ---------------------------------------------------------------------------
# Rigid rebuild: bpy glue around
# RigidRebuildExport. A donor rigid submesh whose edit the in-place fields
# cannot hold (changed topology, Object Mode transform, kept world position on
# another bone, faces moved between surfaces) is exported as a whole
# Submeshes[i].RigidRebuild instead.
# ---------------------------------------------------------------------------

def _empty_image_node_errors(objects):
    """An Image Texture node without an image on any Sluggies
    material (donor, new surface, custom submesh) cancels the export, whatever
    the texture toggles say. A new-surface or custom-submesh material with no
    image node at all is blocked the same way; a donor material without one
    keeps its donor texture."""
    errors = []
    for obj in objects:
        for slot in obj.material_slots:
            mat = slot.material
            if mat is None or not (mat.get("SurfaceId") or mat.get("SluggiesNewSurface")):
                continue
            image_nodes = _connected_image_texture_nodes(mat)
            if any(getattr(node, "image", None) is None for node in image_nodes):
                errors.append(
                    f"'{mat.name}' on {obj.name} has an Image Texture node without an image; "
                    "load a PNG into it (or remove the node) before exporting"
                )
            elif not image_nodes and (mat.get("SluggiesNewSurface") or obj.get("SluggiesCustomSubmesh")):
                errors.append(
                    f"'{mat.name}' on {obj.name} has no image in its texture node; "
                    "load a PNG before exporting"
                )
    return errors


def _bone_geo_id_raw(bone):
    """Literal ACT GeoId of a BoneHierarchy entry (GEO_ID_FREE when mesh-free)."""
    if bone.get("GeoIdRaw") is not None:
        return int(bone["GeoIdRaw"])
    if bone.get("Skinned"):
        return GEO_ID_FREE
    return int(bone.get("GeoId", GEO_ID_FREE))


def _rigid_vertex_bone_ids(obj):
    """Per vertex, the bone ids of its positive-weight bone_<id> groups."""
    group_bone = {group.index: _parse_bone_group_name(group.name) for group in obj.vertex_groups}
    result = []
    for vertex in obj.data.vertices:
        ids = set()
        for g in vertex.groups:
            bone_id = group_bone.get(g.group)
            if g.weight > 0 and bone_id is not None:
                ids.add(bone_id)
        result.append(ids)
    return result


def _slot_surfaces(obj):
    """What each material slot says about its surface (RigidRebuildExport.SlotSurface)."""
    slots = []
    for slot in obj.material_slots:
        mat = slot.material
        if mat is None:
            slots.append(None)
            continue
        slots.append(RigidRebuildExport.SlotSurface(
            material_name=mat.name,
            surface_id=mat.get("SurfaceId") or None,
            new_surface=bool(mat.get("SluggiesNewSurface")),
            owner=mat.get("SluggiesSurfaceOwner"),
        ))
    return slots


def _loop_colors(mesh):
    """Per-loop ``color0`` colours in the donor's value space, or None."""
    attribute = mesh.color_attributes.get("color0")
    if attribute is None:
        return None
    if attribute.domain == 'CORNER':
        return [tuple(_get_loop_color(attribute.data[i])) for i in range(len(mesh.loops))]
    if attribute.domain == 'POINT':
        return [tuple(_get_loop_color(attribute.data[loop.vertex_index])) for loop in mesh.loops]
    return None


@dataclass
class _RigidRebuildPlan:
    """A rigid donor submesh that takes the rebuild path this export."""
    obj: object
    submesh_index: int
    donor: object
    host_bone_id: int
    geometry: object
    routing: object
    reasons: list
    loop_normals: list
    loop_uvs: dict
    loop_colors: object
    new_surface_materials: dict   # surface key -> material
    facial_keys: object = None    # [RigidRebuildExport.FacialObjectKeys] or None


def _rigid_rebuild_plan(context, obj, submesh_index, target_submesh, model, warnings):
    """Decide a rigid donor submesh's export path and gather what the rebuild needs. Returns None when the
    in-place / slot-preserving path applies. Raises ValueError, naming the
    object, for anything that must stop the export (slot hygiene,
    unsupported position format). A submesh with facial poses carries them
    through the rebuild as its facial shape keys (``FacialPoses``)."""
    donor = RigidRebuildExport.donor_rigid_submesh(
        submesh_index, target_submesh, RigidRebuildExport.facial_pose_submeshes(model),
    )
    if obj.mode == 'EDIT':
        obj.update_from_editmode()
    mesh = obj.data
    owner_bone_id = next(
        (int(bone["BoneId"]) for bone in model.get("BoneHierarchy") or []
         if _bone_geo_id_raw(bone) == submesh_index),
        None,
    )
    vertex_bone_ids = _rigid_vertex_bone_ids(obj)
    if owner_bone_id is not None and vertex_bone_ids and not any(vertex_bone_ids):
        # Exports before 2026-10-18 gave submesh 0's owner no influences when the
        # model also has mesh-less bones (stadiums, Miis, ...), so it imported with
        # no bone_<id> group at all. Such a mesh still sits on its owner bone.
        host_bone_id = owner_bone_id
    else:
        problem = RigidRebuildExport.vertex_bone_problem(obj.name, vertex_bone_ids)
        if problem:
            raise ValueError(problem)
        host_bone_id = _detect_uniform_vertex_bone_id(obj)
    if not mesh.polygons:
        raise ValueError(f"{obj.name}: mesh has no faces")
    bone_hierarchy = model.get("BoneHierarchyEdited") or model.get("BoneHierarchy") or []
    geometry = _custom_submesh_bone_local_geometry(context, obj, bone_hierarchy, host_bone_id, warnings)
    topology_changed = ExportMode.topology_changed(
        (poly.vertices for poly in mesh.polygons), target_submesh.get("FacesData"),
    )
    moved = RigidRebuildExport.positions_moved(
        [tuple(v.co) for v in mesh.vertices], geometry, donor.position_quantize,
    )
    routing = RigidRebuildExport.route_faces(
        obj.name, donor, geometry.triangles,
        [poly.material_index for poly in mesh.polygons], _slot_surfaces(obj), topology_changed,
    )
    reasons = RigidRebuildExport.decide_reasons(
        topology_changed=topology_changed, moved=moved,
        host_changed=host_bone_id != owner_bone_id, surfaces_changed=routing.changed,
        out_of_range=RigidRebuildExport.outgrew_position_format(geometry, donor.position_quantize),
    )
    if not reasons:
        return None
    format_error = RigidRebuildExport.donor_position_format_error(donor, obj.name)
    if format_error:
        raise ValueError(format_error)
    shape_keys = mesh.shape_keys.key_blocks if mesh.shape_keys else []
    facial_keys = _facial_shape_key_data(obj, model, submesh_index) if donor.facial else None
    facial_warning = RigidRebuildExport.facial_warning(
        obj.name, donor, len(shape_keys), carried=facial_keys is not None,
    )
    if facial_warning:
        warnings.append(facial_warning)
    if not donor.facial and len(shape_keys) > 1:
        warnings.append(
            f"{obj.name}: its shape keys are ignored; this submesh has no facial poses in the "
            "game's data to carry them as."
        )
    warnings.extend(routing.warnings)
    all_channels = target_submesh.get("UVChannels", [])
    loop_uvs = {}
    for channel in all_channels:
        index = channel.get("UVChannelIndex", 0)
        layer = _find_uv_layer(mesh, all_channels, index)
        loop_uvs[index] = (
            [tuple(layer.data[i].uv) for i in range(len(mesh.loops))] if layer is not None else None
        )
    new_surface_materials = {}
    for slot in obj.material_slots:
        mat = slot.material
        if mat is not None and mat.get("SluggiesNewSurface") and mat.get("SurfaceId") in routing.new_keys:
            new_surface_materials.setdefault(mat["SurfaceId"], mat)
    return _RigidRebuildPlan(
        obj=obj, submesh_index=submesh_index, donor=donor, host_bone_id=host_bone_id,
        geometry=geometry, routing=routing, reasons=reasons,
        loop_normals=_per_loop_normals(mesh, range(len(mesh.loops))),
        loop_uvs=loop_uvs, loop_colors=_loop_colors(mesh),
        new_surface_materials=new_surface_materials,
        facial_keys=facial_keys,
    )


def _rigid_rebuild_entry(plan, texture_assignments, use_compression, warnings, infos):
    """Encode one plan as its RigidRebuild entry. *texture_assignments* maps a
    new-surface material name to its resolved TextureAssignment."""
    new_surfaces = []
    for key in plan.routing.new_keys:
        mat = plan.new_surface_materials[key]
        new_surfaces.append(_new_surface_entry(key, mat, texture_assignments[mat.name]))
    return RigidRebuildExport.build_rigid_rebuild_entry(
        plan.obj.name, plan.donor, plan.host_bone_id, plan.geometry, plan.loop_normals,
        plan.loop_uvs, plan.loop_colors, plan.routing, new_surfaces, plan.reasons,
        use_compression, warnings, infos, facial_keys=plan.facial_keys,
    )


def _vertex_bone_weights(obj):
    """Per vertex, ``{bone id: weight}`` of its positive-weight bone_<id> groups."""
    group_bone = {group.index: _parse_bone_group_name(group.name) for group in obj.vertex_groups}
    result = []
    for vertex in obj.data.vertices:
        weights = {}
        for g in vertex.groups:
            bone_id = group_bone.get(g.group)
            if g.weight > 0 and bone_id is not None:
                weights[bone_id] = weights.get(bone_id, 0.0) + g.weight
        result.append(weights)
    return result


@dataclass
class _SkinnedRebuildPlan:
    """The skinned body takes the rebuild path this export."""
    obj: object
    submesh_index: int
    donor: object
    geometry: object
    routing: object
    reasons: list
    normals: list                 # per exported vertex, armature space, unit
    loop_uvs: dict
    loop_colors: object
    vertex_weights: list          # per Blender vertex {bone: weight}, skinned bones only
    new_surface_materials: dict   # surface key -> material
    facial_keys: object = None    # [SkinnedRebuildExport.FacialObjectKeys] or None


def _shape_key_vertex_normals(key):
    """Per-vertex normals of a shape key's shape (object space), or None
    when Blender cannot compute them."""
    try:
        flat = list(key.normals_vertex_get())
    except (AttributeError, RuntimeError, TypeError):
        return None
    return [tuple(flat[i:i + 3]) for i in range(0, len(flat), 3)]


def _facial_shape_key_data(obj, model, submesh_index):
    """The mesh's facial shape keys as plain data for
    SkinnedRebuildExport.encode_facial_poses (the body) or
    RigidRebuildExport.encode_rigid_facial_poses (a rigid submesh), one
    entry per facial object on *submesh_index*: None when the model has no
    such object or the mesh has no Basis key (the poses are then dropped or
    neutralized)."""
    facial = model.get("FacialPoseData") or {}
    objects = [
        entry for entry in facial.get("Objects", []) if entry.get("SubmeshIndex") == submesh_index
    ]
    if not objects:
        return None
    mesh = obj.data
    key_blocks = mesh.shape_keys.key_blocks if mesh.shape_keys else None
    basis = key_blocks.get("Basis") if key_blocks else None
    if basis is None:
        return None
    basis_positions = [tuple(point.co) for point in basis.data]
    basis_normals = _shape_key_vertex_normals(basis)
    result = []
    for entry in objects:
        pose_count = int(entry.get("PoseCount", facial.get("PoseCount", 0)) or 0)
        positions, normals = [], []
        for pose in range(1, pose_count):
            key = key_blocks.get(
                SkinnedRebuildExport.FACIAL_KEY_NAME.format(object=entry.get("ObjectIndex"), pose=pose)
            )
            if key is None:
                positions.append(None)
                normals.append(None)
                continue
            positions.append([tuple(point.co) for point in key.data])
            normals.append(_shape_key_vertex_normals(key) if basis_normals is not None else None)
        result.append(SkinnedRebuildExport.FacialObjectKeys(
            object_index=int(entry.get("ObjectIndex")), pose_count=pose_count,
            pose_positions=positions, pose_normals=normals,
            basis_positions=basis_positions, basis_normals=basis_normals,
        ))
    return result


def _mark_skinned_added_bones(model, vertex_weights, object_name, warnings):
    """Set ``Skinned`` on every added bone the rebuilt body weights (the
    patcher writes GEO 0xFFFF for such a bone, as for a vanilla skinning bone)
    and say so in the log."""
    used = {bone for weights in vertex_weights for bone in weights}
    skinned = []
    for entry in model.get("BoneHierarchyEdited") or []:
        if entry.get("UserAdded") and int(entry["BoneId"]) in used:
            entry["Skinned"] = True
            skinned.append(int(entry["BoneId"]))
    if skinned:
        warnings.append(
            f"{object_name}: skinned to added bone(s) {', '.join(f'bone_{b}' for b in sorted(skinned))}."
        )


def _skinned_rebuild_plan(context, obj, submesh_index, target_submesh, model, warnings):
    """Decide the skinned body's export path and gather what the rebuild
    needs. Returns None when the slot-preserving paths apply.
    Raises ValueError, naming the object, for anything that must stop the
    export (slot hygiene, unweighted vertices, unsupported position format)."""
    donor = SkinnedRebuildExport.donor_skinned_submesh(
        submesh_index, target_submesh, model.get("SkinData"),
        RigidRebuildExport.facial_pose_submeshes(model),
    )
    if obj.mode == 'EDIT':
        obj.update_from_editmode()
    mesh = obj.data
    if not mesh.polygons:
        raise ValueError(f"{obj.name}: mesh has no faces")
    geometry = _armature_local_geometry(context, obj, warnings)
    topology_changed = ExportMode.topology_changed(
        (poly.vertices for poly in mesh.polygons), target_submesh.get("FacesData"),
    )
    moved = RigidRebuildExport.positions_moved(
        [tuple(v.co) for v in mesh.vertices], geometry, donor.position_quantize,
    )
    routing = RigidRebuildExport.route_faces(
        obj.name, donor, geometry.triangles,
        [poly.material_index for poly in mesh.polygons], _slot_surfaces(obj), topology_changed,
    )
    surfaces_changed = SkinnedRebuildExport.surfaces_need_rebuild(
        routing, donor, _effective_type7_modes(target_submesh.get("DisplayStates", [])),
    )
    # Vertex groups added, removed or reassigned: the body is rebuilt with
    # the new weights rather than laid out around the donor's entries.
    weights_changed = skin_membership_changed([obj], {"SluggiesModel": model})
    reasons = SkinnedRebuildExport.decide_reasons(
        topology_changed=topology_changed, moved=moved, surfaces_changed=surfaces_changed,
        weights_changed=weights_changed,
        out_of_range=RigidRebuildExport.outgrew_position_format(geometry, donor.position_quantize),
    )
    if not reasons:
        return None
    format_error = SkinnedRebuildExport.donor_position_format_error(donor, obj.name)
    if format_error:
        raise ValueError(format_error)
    warnings.extend(routing.warnings)

    bone_hierarchy = model.get("BoneHierarchyEdited") or model.get("BoneHierarchy") or []
    parent_of = {int(b["BoneId"]): b.get("ParentBoneId") for b in bone_hierarchy if "BoneId" in b}
    allowed = SkinnedRebuildExport.allowed_skin_bones(bone_hierarchy)
    vertex_weights = _vertex_bone_weights(obj)
    remap = SkinnedRebuildExport.remap_influences(vertex_weights, allowed, parent_of)
    warnings.extend(SkinnedRebuildExport.remap_report(remap, obj.name))
    _mark_skinned_added_bones(model, remap.weights, obj.name, warnings)
    newly_skinned = SkinnedRebuildExport.newly_skinned_bones(
        remap.weights, donor, SkinnedRebuildExport.added_bone_ids(model.get("BoneHierarchyEdited")),
    )
    if newly_skinned:
        warnings.append(
            f"{obj.name}: skinned to original bone(s) the original body doesn't skin to: "
            f"{SkinnedRebuildExport.bone_list(newly_skinned)}."
        )
    used = {v for tri in geometry.triangles for v in tri.vertices}
    unweighted_error = SkinnedRebuildExport.unweighted_error(
        obj.name, [v for v in remap.unweighted if v in used], vertex_weights,
    )
    if unweighted_error:
        raise ValueError(unweighted_error)

    shape_keys = mesh.shape_keys.key_blocks if mesh.shape_keys else []
    facial_keys = _facial_shape_key_data(obj, model, submesh_index) if donor.facial else None
    facial_warning = SkinnedRebuildExport.facial_warning(
        obj.name, donor, len(shape_keys), carried=facial_keys is not None,
    )
    if facial_warning:
        warnings.append(facial_warning)

    loop_normals = _per_loop_normals(mesh, range(len(mesh.loops)))
    normals = CustomSubmeshExport.transform_normals(
        SkinnedRebuildExport.vertex_normals(geometry, loop_normals, len(mesh.vertices)), geometry.to_bone,
    )
    all_channels = target_submesh.get("UVChannels", [])
    loop_uvs = {}
    for channel in all_channels:
        index = channel.get("UVChannelIndex", 0)
        layer = _find_uv_layer(mesh, all_channels, index)
        loop_uvs[index] = (
            [tuple(layer.data[i].uv) for i in range(len(mesh.loops))] if layer is not None else None
        )
    new_surface_materials = {}
    for slot in obj.material_slots:
        mat = slot.material
        if mat is not None and mat.get("SluggiesNewSurface") and mat.get("SurfaceId") in routing.new_keys:
            new_surface_materials.setdefault(mat["SurfaceId"], mat)
    return _SkinnedRebuildPlan(
        obj=obj, submesh_index=submesh_index, donor=donor, geometry=geometry, routing=routing,
        reasons=reasons, normals=normals, loop_uvs=loop_uvs, loop_colors=_loop_colors(mesh),
        vertex_weights=remap.weights, new_surface_materials=new_surface_materials,
        facial_keys=facial_keys,
    )


def _skinned_rebuild_entry(plan, texture_assignments, use_compression, warnings, infos):
    """Encode one body plan as its SkinnedRebuild entry."""
    new_surfaces = []
    for key in plan.routing.new_keys:
        mat = plan.new_surface_materials[key]
        new_surfaces.append(_new_surface_entry(key, mat, texture_assignments[mat.name]))
    entry = SkinnedRebuildExport.build_skinned_rebuild_entry(
        plan.obj.name, plan.donor, plan.geometry, plan.normals, plan.loop_uvs, plan.loop_colors,
        plan.routing, plan.vertex_weights, new_surfaces, plan.reasons, use_compression, warnings, infos,
    )
    if plan.facial_keys is not None:
        entry["FacialPoses"] = SkinnedRebuildExport.encode_facial_poses(
            plan.obj.name, plan.facial_keys, plan.geometry,
            entry.get("VertexBufferQuantizeInfo", plan.donor.position_quantize),
            use_compression, warnings, infos,
        )
    return entry


def _drop_facial_edits_for_submesh(data, submesh_index):
    """Remove FacialPoseDataEdited entries for *submesh_index*: a rebuilt
    submesh carries its poses in its rebuild's FacialPoses (or drops them),
    never as in-place pose edits."""
    model = data.get("SluggiesModel", {})
    facial = model.get("FacialPoseData") or {}
    dropped = {
        entry.get("ObjectIndex") for entry in facial.get("Objects", [])
        if entry.get("SubmeshIndex") == submesh_index
    }
    edited = model.get("FacialPoseDataEdited")
    if not edited or not dropped:
        return
    kept = [entry for entry in edited.get("Objects", []) if entry.get("ObjectIndex") not in dropped]
    if kept:
        model["FacialPoseDataEdited"] = {"Objects": kept}
    else:
        model.pop("FacialPoseDataEdited", None)


def _partial_move_error(obj, display_states, surf_mat):
    """Submesh 0 (skinned) keeps the complete-move rule: a donor surface whose
    faces are split between materials is refused with the rigid-only hint."""
    original = []
    for index, state in enumerate(display_states):
        count = state.get("FaceCount")
        if count is None:
            return None
        original += [index] * int(count)
    polygons = obj.data.polygons
    if len(original) != len(polygons):
        return None
    sid_to_index = {state.get("SurfaceId"): i for i, state in enumerate(display_states) if state.get("SurfaceId")}
    slot_to_index = {}
    for slot_index, slot in enumerate(obj.material_slots):
        mat = slot.material
        if mat is not None and mat.get("SurfaceId") in sid_to_index:
            slot_to_index[slot_index] = sid_to_index[mat["SurfaceId"]]
    targets = {}
    for poly, source in zip(polygons, original):
        targets.setdefault(source, set()).add(slot_to_index.get(poly.material_index, source))
    for source, moved_to in targets.items():
        if len(moved_to) > 1:
            name = display_states[source].get("SurfaceId") or f"ds{source}"
            return (
                f"{obj.name}: faces of surface '{name}' were moved only partly to other "
                f"materials. {NEW_SURFACE_BODY_MESSAGE}."
            )
    return None


def _effective_type7_modes(display_states):
    active_mode = None
    effective_modes = []
    for state in display_states:
        if state.get("DisplayStateId") == 7:
            active_mode = state.get("ShaderModeEdited") or state.get("ShaderMode", "")
        effective_modes.append(active_mode)
    return effective_modes


def _encode_face_surface_assignment(obj, display_states, surf_mat, use_compression, warnings):
    """Return (data, changed) encoding which display state owns each face.

    data is an encoded uint16 BE array (one ds_idx per face) or None when unchanged.
    Returns (None, False) for old exports without FaceCount, or when face count
    differs from the original (topology change — handled by milestone 4).
    Validates duplicate, foreign, and missing SurfaceIds; appends to warnings.
    """
    # Build original face → ds_idx from FaceCount cumulative ranges
    original_ds_idx = []
    for di, ds in enumerate(display_states):
        fc = ds.get("FaceCount")
        if fc is None:
            return None, False  # Old export without FaceCount
        for _ in range(fc):
            original_ds_idx.append(di)

    if not original_ds_idx:
        return None, False

    # Donor surface IDs from the sluggie display states
    donor_sid_to_ds_idx = {
        ds.get("SurfaceId"): di
        for di, ds in enumerate(display_states)
        if ds.get("SurfaceId")
    }

    # Detect duplicate SurfaceIds across material slots
    sid_slot_first = {}
    for slot_idx, slot in enumerate(obj.material_slots):
        mat = slot.material
        if mat is None:
            continue
        sid = mat.get("SurfaceId")
        if not sid:
            continue
        if sid in sid_slot_first:
            warnings.append(
                f"{obj.name}: SurfaceId '{sid}' is on multiple material slots "
                f"({sid_slot_first[sid]} and {slot_idx}) — only slot "
                f"{sid_slot_first[sid]} will be used."
            )
        else:
            sid_slot_first[sid] = slot_idx
        if sid not in donor_sid_to_ds_idx:
            warnings.append(
                f"{obj.name}: material '{mat.name}' has SurfaceId '{sid}' "
                f"not found in the donor's display states — faces assigned to "
                f"it keep their original draw-state assignment."
            )

    # Build mat_slot_idx → ds_idx (first occurrence of each SurfaceId wins)
    seen_sids = set()
    mat_slot_to_ds_idx = {}
    for slot_idx, slot in enumerate(obj.material_slots):
        mat = slot.material
        if mat is None:
            continue
        sid = mat.get("SurfaceId")
        if sid and sid in donor_sid_to_ds_idx and sid not in seen_sids:
            mat_slot_to_ds_idx[slot_idx] = donor_sid_to_ds_idx[sid]
            seen_sids.add(sid)

    n_faces = len(obj.data.polygons)
    if n_faces != len(original_ds_idx):
        return None, False  # Topology changed — face assignment handled in milestone 4

    current_ds_idx = []
    has_unresolved = False
    for poly in obj.data.polygons:
        di = mat_slot_to_ds_idx.get(poly.material_index)
        if di is None:
            has_unresolved = True
            current_ds_idx.append(original_ds_idx[poly.index])
        else:
            current_ds_idx.append(di)

    if has_unresolved:
        warnings.append(
            f"{obj.name}: some faces have materials without a valid donor SurfaceId; "
            f"those faces keep their original draw-state assignment."
        )

    if current_ds_idx == original_ds_idx:
        return None, False

    # A primitive-bearing non-Type-7 state inherits the most recent Type-7
    # shader mode. Compare that effective mode rather than the current command's
    # raw setting (for example, Type-1 11110001 is a texture binding, not a shader).
    effective_mode = _effective_type7_modes(display_states)
    for poly_index, (src_ds, dst_ds) in enumerate(zip(original_ds_idx, current_ds_idx)):
        if src_ds == dst_ds:
            continue
        if effective_mode[src_ds] != effective_mode[dst_ds]:
            src_name = display_states[src_ds].get("SurfaceId") or f"ds{src_ds}"
            dst_name = display_states[dst_ds].get("SurfaceId") or f"ds{dst_ds}"
            raise ValueError(
                f"{obj.name}: face {poly_index} cannot move from surface "
                f"'{src_name}' (shader mode {effective_mode[src_ds]}) to "
                f"surface '{dst_name}' (shader mode {effective_mode[dst_ds]}); "
                "only identical effective Type-7 shader reassignment is supported"
            )

    raw = struct.pack(f'>{n_faces}H', *current_ds_idx)
    return _from_bytes(raw, use_compression), True


def model_meshes(context, arm_obj):
    """(visible, hidden) meshes of the model *arm_obj*: its Sluggies, custom
    submesh and collision meshes below it or deformed by it."""
    shown, hidden = [], []
    for obj in context.view_layer.objects:
        if obj.type != 'MESH':
            continue
        owner = obj.parent
        while owner is not None and owner.type != 'ARMATURE':
            owner = owner.parent
        if owner is not arm_obj and not any(
                m.type == 'ARMATURE' and m.object is arm_obj for m in obj.modifiers):
            continue
        collision = getattr(obj, 'sluggies_collision', None)
        if not (obj.get('SluggiesCustomSubmesh') or (collision is not None and collision.enabled)
                or all(prop in obj for prop in REQUIRED_PROPS)):
            continue
        (shown if obj.visible_get() else hidden).append(obj)
    return shown, hidden


def export_selection(context):
    """(the objects the export treats as selected, hidden meshes left out):
    the selection, or for a selection of one model's armature and no mesh,
    that armature with all its visible meshes."""
    from . import ModelCheck
    selected = list(context.selected_objects)
    armatures = [obj for obj in selected if ModelCheck.is_sluggies_armature(obj)]
    if len(armatures) != 1 or any(obj.type == 'MESH' for obj in selected):
        return selected, []
    shown, hidden = model_meshes(context, armatures[0])
    return selected + shown, hidden


class SLUGGIES_OT_export(bpy.types.Operator, ExportHelper):
    bl_idname = "sluggies.export_json"
    bl_label = "Export Sluggers intermediate"
    bl_description = (
        "Write the edited model into a .sluggie file: the one it was imported "
        "from, or a new file name (the original is left untouched)"
    )
    bl_options = {"UNDO"}

    filename_ext = ".sluggie"
    filter_glob: StringProperty(default="*.sluggie", options={"HIDDEN"})  # type: ignore[valid-type]
    # First, so the file browser lists it at the top.
    exclude_unselected: BoolProperty(  # type: ignore[valid-type]
        name="Exclude all unselected meshes",
        description=(
            "The patched model keeps only the meshes this export writes: every original mesh "
            "that is not selected is left out of the game (not drawn), and its earlier edits "
            "are dropped. The main body always stays; stadiums keep every mesh. With only the "
            "armature selected, all its visible meshes count as selected. Off: unselected "
            "meshes keep their original or earlier exported state"
        ),
        default=True,
    )
    use_custom_normals: BoolProperty(  # type: ignore[valid-type]
        name="Overwrite Normals",
        description=(
            "Overwrite both interleaved vertex-buffer normals (CompCount>=6) "
            "and standalone NormalBuffer arrays with Blender's current normals. "
            "Leave off to keep the original normal values unchanged."
        ),
        default=False,
    )
    reimport_textures: BoolProperty(  # type: ignore[valid-type]
        name="Reimport textures from tex folder",
        description=(
            "When patching, replace the model's original textures in "
            "dt_na.dat with the edited PNGs from the model's tex/ folder. "
            "A PNG whose size changed makes the export use Hammerspace, "
            "which rebuilds the TEX section. New textures (new PNGs on "
            "materials, custom submeshes and new materials) are always "
            "added, with or without this option."
        ),
        default=False,
    )

    def invoke(self, context, event):
        # The file browser starts on the armature's source .sluggie: export
        # back into it, or type a new name to save a variant.
        from . import ModelCheck
        arm_obj = ModelCheck.selection_armature(context.selected_objects)
        source_path = SluggiePath.resolve(arm_obj, hint=self.filepath)
        if not source_path and arm_obj is not None and not self.filepath:
            # Start the browser on the recorded name at least.
            self.filepath = os.path.basename(SluggiePath.stored(arm_obj))
        if source_path and not self.filepath:
            self.filepath = source_path
            context.window_manager.fileselect_add(self)
            return {"RUNNING_MODAL"}
        return super().invoke(context, event)

    def execute(self, context):
        # --- load and sanity-check the source and target ---
        if not getattr(self, "filepath", "").strip():
            self.report(
                {"ERROR"},
                "No target .sluggie file was selected. Pick the .sluggie to "
                "update or type a new file name, and export again.",
            )
            return {"CANCELLED"}

        # Edit Mode keeps the mesh in BMesh, so mesh.uv_layers etc. read as
        # empty (IndexError on a custom submesh's UVs, Blender 5.2,
        # 2026-09-29). Refuse instead of flushing half the data.
        if context.mode.startswith('EDIT'):
            self.report(
                {"ERROR"},
                "Export is not possible in Edit Mode. Switch to Object Mode "
                "(Tab) and export again.",
            )
            return {"CANCELLED"}

        # The model is read from the armature's source .sluggie and written
        # to the target (self.filepath), which may be a new file in any
        # folder. Every path-relative lookup below (tex/, the Low model's
        # partner) uses the target's folder. SluggiePath.resolve finds a
        # moved source again (and records the hit); an armature without a
        # source (older imports) or with a lost one reads the target, which
        # the export below then records as its source.
        from . import ModelCheck
        # Only an armature selected: all its visible meshes count as selected.
        selected, hidden_meshes = export_selection(context)
        arm_obj = ModelCheck.selection_armature(selected)
        source_path = SluggiePath.resolve(arm_obj, hint=self.filepath)
        stored_path = SluggiePath.stored(arm_obj)
        if not source_path:
            if stored_path:
                self.report({"WARNING"},
                    f"The armature's source file {stored_path} is missing; reading the target instead.")
            source_path = self.filepath
        if not os.path.isfile(source_path):
            self.report({"ERROR"},
                f"{os.path.basename(self.filepath)} does not exist yet and "
                + (f"the armature's source file {stored_path} is missing. "
                   if stored_path else "the armature records no source .sluggie to read the model from. ")
                + "Export into the existing .sluggie of this model instead, "
                + SluggiePath.LOCATE_HINT[0].lower() + SluggiePath.LOCATE_HINT[1:]
                + ", or re-import the model.")
            return {"CANCELLED"}
        save_as = (os.path.normcase(os.path.abspath(source_path))
                   != os.path.normcase(os.path.abspath(self.filepath)))

        try:
            with open(source_path, 'rb') as f:
                content = f.read().strip()
        except Exception as e:
            self.report({"ERROR"}, f"Could not read file: {e}")
            return {"CANCELLED"}

        if not content:
            self.report({"ERROR"}, f"Source .sluggie file {source_path} is empty.")
            return {"CANCELLED"}

        try:
            data = FieldCodec.loads_sluggie(content)
        except ValueError as e:
            self.report({"ERROR"}, f"Could not parse the .sluggie file: {e}")
            return {"CANCELLED"}

        if "SluggiesModel" not in data:
            self.report({"ERROR"}, "JSON does not contain a 'SluggiesModel' entry.")
            return {"CANCELLED"}

        if save_as and os.path.exists(self.filepath):
            try:
                target_model = FieldCodec.load_sluggie(self.filepath).get("SluggiesModel")
            except (OSError, ValueError, AttributeError):
                target_model = None
            overwrite_error = ModelCheckCore.overwrite_error(
                data["SluggiesModel"], target_model, os.path.basename(self.filepath))
            if overwrite_error:
                self.report({"ERROR"}, overwrite_error)
                return {"CANCELLED"}

        use_compression = data["SluggiesModel"].get("UseCompression", True)
        submeshes = data["SluggiesModel"].get("Submeshes", [])

        # --- collect selected mesh objects that carry Sluggies custom properties ---
        # Custom submeshes have no
        # VertexBufferOffset of their own yet — they are new submeshes, not
        # edits to an existing one — so they are collected separately and
        # excluded from the VertexBufferOffset-matching candidates below.
        custom_submesh_candidates = [
            obj for obj in selected
            if obj.type == 'MESH' and obj.get('SluggiesCustomSubmesh')
        ]
        candidates = [
            obj for obj in selected
            if obj.type == 'MESH' and not obj.get('SluggiesCustomSubmesh')
            and all(prop in obj for prop in REQUIRED_PROPS)
        ]

        # Stadium collision: any selected mesh with collision turned on (a model
        # mesh, a custom submesh or a plain collision-only mesh).
        collision_objects = [
            obj for obj in selected
            if obj.type == 'MESH' and getattr(obj, 'sluggies_collision', None) is not None
            and obj.sluggies_collision.enabled
        ]
        # The stadium's original colliders (imported from StadiumCollisionVanilla)
        # count whether selected or not: once the scene has any, the patcher
        # rebuilds the whole collision file from them, so a deleted one is
        # collision removed, not collision left out by the selection.
        collision_armature = ModelCheck.selection_armature(selected)
        original_colliders = [
            obj for obj in context.scene.objects
            if obj.type == 'MESH' and StadiumCollisionExport.REGION_PROP in obj
            and collision_armature is not None and obj.parent is collision_armature
        ]
        collision_objects += [
            obj for obj in original_colliders
            if obj.sluggies_collision.enabled and obj not in collision_objects
        ]

        # "Make invisible": the object exports its collision only, never drawn.
        invisible_objects = [obj for obj in collision_objects if obj.sluggies_collision.invisible]
        invisible_error = StadiumCollisionExport.invisible_model_mesh_error(
            [obj.name for obj in invisible_objects if obj in candidates])
        if invisible_error:
            self.report({"ERROR"}, invisible_error)
            return {"CANCELLED"}
        custom_submesh_candidates = [obj for obj in custom_submesh_candidates if obj not in invisible_objects]

        if not candidates and not custom_submesh_candidates and not collision_objects:
            self.report({"ERROR"},
                "No selected mesh objects with Sluggies custom properties found. "
                "Import the JSON first, then select the meshes you want to export.")
            return {"CANCELLED"}

        if len(candidates) > len(submeshes):
            self.report({"ERROR"},
                f"{len(candidates)} mesh(es) selected but the target JSON only defines "
                f"{len(submeshes)} submesh(es). Make sure you are exporting to the correct file.")
            return {"CANCELLED"}

        # The Check Models error checks on the selected model, before anything
        # is encoded (ModelCheck is imported above, in the function: it
        # imports this module).
        check_errors = ModelCheck.export_errors(
            context, data["SluggiesModel"], self.filepath,
            candidates + custom_submesh_candidates + [
                obj for obj in selected if obj.type == 'ARMATURE'
            ],
            self.reimport_textures,
        )
        if check_errors:
            for message in check_errors:
                self.report({"ERROR"}, message)
            return {"CANCELLED"}
        try:
            size_line = ModelCheck.export_size_line(
                context, data["SluggiesModel"], self.filepath,
                candidates + custom_submesh_candidates,
            )
        except Exception as exc:  # the estimate must never stop an export
            size_line = f"Size estimate failed: {exc}"

        written = 0
        warnings = []
        # Expected, harmless notes (e.g. faces per surface, mirrored UV 1).
        infos = []
        # Non-fatal but severe conditions: the export still completes, yet part
        # of the user's edit was discarded. Reported at ERROR level so it is not
        # lost among ordinary warnings.
        errors = []
        object_submeshes = []
        matched_objects = {}
        for obj in candidates:
            # match by VertexBufferOffset (unique per submesh)
            target_submesh = next(
                (sm for sm in submeshes
                 if str(obj["VertexBufferOffset"]) == str(sm.get("VertexBuffer", {}).get("VertexBufferOffset"))),
                None
            )
            if target_submesh is None:
                warnings.append(
                    f"{obj.name}: no submesh with VertexBufferOffset="
                    f"{obj['VertexBufferOffset']} found in JSON — skipped."
                )
                continue
            submesh_index = next(i for i, sm in enumerate(submeshes) if sm is target_submesh)
            # Two selected objects for one submesh (e.g. a mesh and its
            # re-imported `_edit` copy) would silently let the last one win.
            if submesh_index in matched_objects:
                self.report({"ERROR"},
                    f"{matched_objects[submesh_index].name} and {obj.name} both belong to "
                    f"submesh {submesh_index}. Select only one of them and export again."
                )
                return {"CANCELLED"}
            matched_objects[submesh_index] = obj
            object_submeshes.append((obj, target_submesh))

            # Every material must be a surface of this submesh: imported, or
            # added with Add material (rigid submeshes only).
            new_materials = _find_new_materials(obj, target_submesh, submesh_index)
            if new_materials:
                names = ", ".join(f"'{n}' ({r})" for n, r in new_materials)
                self.report({"ERROR"},
                    f"Error: {obj.name} uses material(s) that are not surfaces of this "
                    f"submesh: {names}. Use its imported materials or Add material, and "
                    f"reassign or remove the other faces."
                )
                return {"CANCELLED"}

        # an empty Image Texture node blocks the export, whatever
        # the texture toggles say.
        image_errors = _empty_image_node_errors(candidates + custom_submesh_candidates)
        if image_errors:
            for message in image_errors:
                self.report({"ERROR"}, message)
            return {"CANCELLED"}

        local_texture_descriptors = (
            data["SluggiesModel"].get("TextureDescriptors") or []
        )
        owns_texture_section = bool(local_texture_descriptors)
        additions, desired_assignments, changed_materials = [], {}, []
        # tex/ file name -> source PNG linked from outside tex/, copied in
        # once nothing can cancel the export.
        planned_texture_copies = {}
        # A material showing another texture (a new PNG, or another of the
        # model's textures) is exported whatever the Reimport textures toggle
        # says: the toggle only decides whether the original textures are
        # re-encoded from tex/. A `_L_` model binds its High model's textures
        # by index (Manage texture slots sets these images).
        try:
            texture_descriptors, texture_dir, owns_texture_section, texture_owner_path = (
                _resolve_export_texture_context(
                    self.filepath, data["SluggiesModel"], with_owner=True)
            )
            if owns_texture_section or texture_descriptors:
                additions, desired_assignments, changed_materials = (
                    _resolve_material_texture_changes(
                        object_submeshes,
                        texture_descriptors,
                        texture_dir,
                        path_resolver=bpy.path.abspath,
                        validate_texture_files=owns_texture_section,
                        skip_unset_images=not owns_texture_section,
                        require_donor_files=self.reimport_textures,
                        planned_copies=planned_texture_copies,
                    )
                )
        except ValueError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        # Names the High file a Low export paired with, so a wrong pairing
        # (file names that don't match) shows in the error.
        paired_main_model = (
            f"paired main model ({os.path.basename(texture_owner_path)})"
            if texture_owner_path else "paired main model"
        )

        if additions and not owns_texture_section:
            self.report(
                {"ERROR"},
                f"Low-poly model textures are owned by the {paired_main_model}. A low-poly "
                "material can only show one of the main model's textures (see Manage "
                "texture slots); add new PNGs on the main model and export it first: "
                f"{', '.join(addition['TextureFileName'] for addition in additions)}",
            )
            return {"CANCELLED"}

        # Added bones (Add Bone) — model-level, written only
        # when the armature has any SluggiesUserAdded bone. Runs before custom
        # submesh encoding below, which resolves host bones against it: a
        # custom submesh may be hosted on a user-added bone that has no
        # BoneHierarchy entry yet.
        # Everything below reads bone ids from bone_<N> names; refuse while an
        # added bone's name and its exported id disagree (a deleted added
        # bone shifts the later ids, 2026-09-29).
        name_error = added_bone_name_error(selected, context)
        if name_error:
            self.report({"ERROR"}, name_error)
            return {"CANCELLED"}
        encode_bone_hierarchy_edited(selected, data, warnings, context)
        warnings.extend(untracked_keys_warnings(selected, context))
        bone_hierarchy_errors = validate_bone_hierarchy_edited_export(
            data["SluggiesModel"], warnings
        )
        if bone_hierarchy_errors:
            for err in bone_hierarchy_errors:
                self.report({"ERROR"}, err)
            return {"CANCELLED"}

        # --- Custom submeshes ---
        # Their PNGs are added whatever the Reimport textures toggle says.
        # CustomSubmeshes always mirrors the current selection, like
        # AdditionalTextureDescriptors.
        custom_submesh_entries = []
        custom_additions = []
        if custom_submesh_candidates:
            model = data["SluggiesModel"]
            try:
                validate_custom_submeshes(
                    custom_submesh_candidates, candidates, model, warnings
                )
                primary_materials = []
                custom_texture_entries = []
                for obj in custom_submesh_candidates:
                    new_materials = _find_new_materials(obj, None)
                    if new_materials:
                        names = ", ".join(f"'{n}' ({r})" for n, r in new_materials)
                        raise ValueError(
                            f"{obj.name}: custom submeshes support only their own surface "
                            f"materials ({names})"
                        )
                    material = _custom_submesh_material(obj)
                    if material is None:
                        raise ValueError(
                            f"{obj.name}: custom submesh has no material with its own "
                            f"SurfaceId '{obj.get('CustomSubmeshId')}_ds0'"
                        )
                    template_texture_index = _custom_submesh_template_texture_index(
                        model, str(obj.get("TemplateSource") or "")
                    )
                    primary_materials.append(material)
                    custom_texture_entries.append((material, template_texture_index))
                    # Add-material surfaces on the custom submesh resolve their
                    # images the same way.
                    additional_materials, _unused = _custom_submesh_additional_materials(obj)
                    for extra in additional_materials.values():
                        custom_texture_entries.append(
                            (extra, int(extra.get("TemplateTextureIndex", -1)))
                        )
                (
                    custom_additions, custom_assignments, _copies,
                ) = _resolve_custom_submesh_texture_changes(
                    custom_texture_entries,
                    texture_descriptors,
                    texture_dir,
                    path_resolver=bpy.path.abspath,
                    planned_copies=planned_texture_copies,
                )
                if custom_additions and not owns_texture_section:
                    raise ValueError(
                        f"Low-poly model textures are owned by the {paired_main_model}; "
                        "a custom submesh on it can only use an existing texture: "
                        + ", ".join(obj.name for obj in custom_submesh_candidates)
                    )
                for obj, material in zip(custom_submesh_candidates, primary_materials):
                    custom_submesh_entries.append(encode_custom_submesh(
                        context, obj, model, custom_assignments[material.name],
                        warnings, use_compression,
                        material.get("SpecularStrength"),
                        texture_assignments=custom_assignments, infos=infos,
                    ))
            except ValueError as exc:
                self.report({"ERROR"}, str(exc))
                return {"CANCELLED"}

        # --- Rigid rebuilds ---
        # Each rigid donor submesh takes the in-place path unless its
        # topology, transform, host bone (world position kept) or surfaces
        # changed, or its positions outgrew the donor's format; then it is
        # exported as a whole RigidRebuild. New
        # Add-material surfaces resolve their images like custom submeshes.
        rigid_plans = {}
        # The skinned body: a whole
        # SkinnedRebuild when its topology, transform or surfaces changed in
        # a way the slot-preserving paths cannot store.
        skinned_plans = {}
        new_surface_additions, new_surface_assignments = [], {}
        try:
            for obj, target_submesh in object_submeshes:
                submesh_index = next(i for i, sm in enumerate(submeshes) if sm is target_submesh)
                if RigidRebuildExport.is_rigid_submesh(target_submesh):
                    plan = _rigid_rebuild_plan(
                        context, obj, submesh_index, target_submesh, data["SluggiesModel"], warnings,
                    )
                    if plan is not None:
                        rigid_plans[submesh_index] = plan
                elif SkinnedRebuildExport.is_skinned_submesh(target_submesh) and submesh_index == 0:
                    plan = _skinned_rebuild_plan(
                        context, obj, submesh_index, target_submesh, data["SluggiesModel"], warnings,
                    )
                    if plan is not None:
                        skinned_plans[submesh_index] = plan
            new_surface_entries = [
                (plan.new_surface_materials[key], int(plan.new_surface_materials[key].get("TemplateTextureIndex", -1)))
                for plan in list(rigid_plans.values()) + list(skinned_plans.values())
                for key in plan.routing.new_keys
            ]
            if new_surface_entries:
                (
                    new_surface_additions, new_surface_assignments, _copies,
                ) = _resolve_custom_submesh_texture_changes(
                    new_surface_entries, texture_descriptors, texture_dir,
                    path_resolver=bpy.path.abspath,
                    planned_copies=planned_texture_copies,
                )
                new_names = ", ".join(mat.name for mat, _index in new_surface_entries)
                if new_surface_additions and not owns_texture_section:
                    raise ValueError(
                        f"Low-poly model textures are owned by the {paired_main_model}; a new "
                        f"material on it can only use an existing texture: {new_names}"
                    )
        except ValueError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        # Unselected original meshes are left out of the patched model (option).
        # Not on stadiums: a collision-only export selects no mesh at all.
        stadium_model = TemplateSources.is_stadium_chunk(data["SluggiesModel"].get("ChunkNumber"))
        excluded_indices = ExportMode.exclude_unselected_submeshes(
            submeshes, [next(i for i, sm in enumerate(submeshes) if sm is target)
                        for _obj, target in object_submeshes],
            self.exclude_unselected and not stadium_model,
        )
        if self.exclude_unselected and stadium_model:
            infos.append("Stadium: unselected meshes are kept (Exclude all unselected meshes is for characters)")
        for index in excluded_indices:
            _drop_facial_edits_for_submesh(data, index)
        excluded_names = [submeshes[i].get("MeshName") or f"submesh {i}" for i in excluded_indices]
        if excluded_names:
            infos.append(f"Excluded from the patched model (not selected): {', '.join(excluded_names)}")
        if hidden_meshes:
            warnings.append("Armature selected: its hidden meshes are not exported: "
                            + ", ".join(obj.name for obj in hidden_meshes))

        # --- Export mode: in-place when nothing would be lost, else Hammerspace ---
        # Model-level reasons skip the in-place attempt. Otherwise the meshes
        # are first encoded in place on a copy; any edit that attempt cannot
        # store adds a reason, and the meshes are encoded again in Hammerspace
        # mode on the real data.
        hammerspace_reasons = ExportMode.model_level_reasons(
            data["SluggiesModel"],
            custom_submesh_names=[obj.name for obj in custom_submesh_candidates],
            has_new_bones=armature_has_new_bones(selected, context),
            changed_materials=changed_materials,
            resized_textures=(
                ExportMode.texture_size_changes(local_texture_descriptors, texture_dir)
                if self.reimport_textures and owns_texture_section else []
            ),
            stale_submeshes=ExportMode.stale_hammerspace_submeshes(
                submeshes, [obj["VertexBufferOffset"] for obj, _sm in object_submeshes]
            ),
            excluded_submeshes=excluded_names,
        ) + [
            RigidRebuildExport.mode_reason(plan.obj.name, plan.reasons)
            for plan in rigid_plans.values()
        ] + [
            SkinnedRebuildExport.mode_reason(plan.obj.name, plan.reasons)
            for plan in skinned_plans.values()
        ]
        use_hammerspace = bool(hammerspace_reasons)
        object_submesh_indices = [
            (obj, next(i for i, sm in enumerate(submeshes) if sm is target_submesh))
            for obj, target_submesh in object_submeshes
        ]
        base_data, base_warnings, base_errors, base_infos = data, warnings, errors, infos
        while True:
            data = base_data if use_hammerspace else copy.deepcopy(base_data)
            warnings, errors, infos = list(base_warnings), list(base_errors), list(base_infos)
            written = 0
            pass_reasons = []

            for obj, submesh_index in object_submesh_indices:
                target_submesh = data["SluggiesModel"]["Submeshes"][submesh_index]
                plan = rigid_plans.get(submesh_index)
                skinned_plan = skinned_plans.get(submesh_index)
                if plan is not None:
                    # Whole-blob rebuild: none of the in-place edit fields may
                    # stay on the submesh (the patcher refuses the mix).
                    try:
                        entry = _rigid_rebuild_entry(plan, new_surface_assignments, use_compression, warnings, infos)
                    except ValueError as exc:
                        self.report({"ERROR"}, str(exc))
                        return {"CANCELLED"}
                    RigidRebuildExport.strip_in_place_edits(target_submesh)
                    target_submesh.pop("SkinnedRebuild", None)
                    target_submesh["RigidRebuild"] = entry
                elif skinned_plan is not None:
                    try:
                        entry = _skinned_rebuild_entry(skinned_plan, new_surface_assignments, use_compression, warnings, infos)
                    except ValueError as exc:
                        self.report({"ERROR"}, str(exc))
                        return {"CANCELLED"}
                    SkinnedRebuildExport.strip_in_place_edits(target_submesh)
                    target_submesh.pop("RigidRebuild", None)
                    target_submesh["SkinnedRebuild"] = entry
                elif use_hammerspace:
                    target_submesh.pop("RigidRebuild", None)
                    target_submesh.pop("SkinnedRebuild", None)
                    try:
                        hs = encode_mesh_hammerspace(
                            obj,
                            target_submesh,
                            use_custom_normals=self.use_custom_normals,
                            use_compression=use_compression,
                        )
                    except ValueError as exc:
                        self.report({"ERROR"}, f"{obj.name}: {exc}")
                        return {"CANCELLED"}
                    target_submesh["VertexBuffer"]["VertexBufferDataEdited"] = hs['VertexBufferDataEdited']
                    target_submesh["FacesDataEdited"] = hs['FacesDataEdited']
                    target_submesh["FacesCountEdited"] = hs['FacesCountEdited']
                    target_submesh["FaceTextureIndicesEdited"] = hs['FaceTextureIndicesEdited']
                    for json_channel in target_submesh.get("UVChannels", []):
                        ch_ind = json_channel.get("UVChannelIndex", 0)
                        if ch_ind in hs['UVEdits']:
                            uv_data_enc, uv_faces_enc = hs['UVEdits'][ch_ind]
                            json_channel["UVChannelDataEdited"] = uv_data_enc
                            json_channel["UVFacesDataEdited"] = uv_faces_enc
                        else:
                            layer_name = _uv_layer_name(target_submesh.get("UVChannels", []), ch_ind)
                            warnings.append(
                                f"{obj.name}: UV layer '{layer_name}' not found — UV channel {ch_ind} skipped."
                            )

                    # Per-loop normals (standalone NormalBuffer) and per-loop colors
                    # (plan 3.3) — written only when the submesh actually has them.
                    normal_buffer = target_submesh.get("NormalBuffer")
                    if hs.get("NormalEdits") is not None and isinstance(normal_buffer, dict):
                        normal_data_enc, normal_faces_enc = hs["NormalEdits"]
                        normal_buffer["NormalBufferDataEdited"] = normal_data_enc
                        normal_buffer["NormalFacesDataEdited"] = normal_faces_enc
                    elif isinstance(normal_buffer, dict):
                        # Submesh has a NormalBuffer the exporter refused to encode —
                        # drop stale per-loop edits so the original NormalBuffer stays authoritative.
                        if (self.use_custom_normals
                                and normal_buffer.get("NormalBufferData")):
                            # The user asked for normals to be overwritten and the
                            # submesh has a standalone buffer, so encode_normal_edits
                            # bailed out: extended records (CompCount > 3) could not
                            # keep their donor tail mapping. Silently dropping this
                            # ships a model whose lighting is not what was edited.
                            donor_loops = len(_to_bytes(
                                normal_buffer.get("NormalFacesData") or b""
                            )) // 2
                            errors.append(
                                f"{obj.name}: standalone normal overwrite DROPPED — "
                                f"extended normal records (CompCount "
                                f"{normal_buffer.get('NormalBufferCompCount')}) could not "
                                f"preserve their donor mapping ({donor_loops} donor loops). "
                                f"The donor normals were kept; your normal edits are NOT "
                                f"in this export. Keep the original topology or turn "
                                f"Overwrite Normals off."
                            )
                        normal_buffer.pop("NormalBufferDataEdited", None)
                        normal_buffer.pop("NormalFacesDataEdited", None)
                    for json_channel in target_submesh.get("ColorChannels", []):
                        ch_ind = json_channel.get("ColorChannelIndex", 0)
                        if ch_ind in hs["ColorEdits"]:
                            color_data_enc, color_faces_enc = hs["ColorEdits"][ch_ind]
                            json_channel["ColorChannelDataEdited"] = color_data_enc
                            json_channel["ColorFacesDataEdited"] = color_faces_enc
                        else:
                            json_channel.pop("ColorChannelDataEdited", None)
                            json_channel.pop("ColorFacesDataEdited", None)
                            warnings.append(
                                f"{obj.name}: color attribute 'color{ch_ind}' not found — "
                                f"color channel {ch_ind} skipped."
                            )
                else:
                    target_submesh.pop("RigidRebuild", None)
                    target_submesh.pop("SkinnedRebuild", None)
                    mismatches = validate_against_json(obj, target_submesh)
                    if mismatches:
                        warnings.append(
                            f"{obj.name}: metadata mismatch ({'; '.join(mismatches)}) — skipped."
                        )
                        continue

                    length_issues = detect_length_mismatches(obj, target_submesh)
                    if length_issues:
                        pass_reasons.append(f"{obj.name}: " + "; ".join(length_issues))
                    elif ExportMode.topology_changed(
                        (poly.vertices for poly in obj.data.polygons),
                        target_submesh.get("FacesData"),
                    ):
                        pass_reasons.append(f"{obj.name}: faces changed")

                    try:
                        edited_data = encode_vertex_buffer_edited(
                            obj,
                            obj["VertexBufferCompCount"],
                            obj["VertexBufferQuantizeInfo"],
                            use_custom_normals=self.use_custom_normals,
                            use_compression=use_compression,
                            donor_data=target_submesh["VertexBuffer"].get("VertexBufferData"),
                        )
                    except ValueError as exc:
                        self.report({"ERROR"}, f"{obj.name}: {exc}")
                        return {"CANCELLED"}
                    target_submesh["VertexBuffer"]["VertexBufferDataEdited"] = edited_data
                    # Clear any stale hammerspace face data so it can't mismatch the
                    # in-place vertex buffer (which must stay at the original vertex count).
                    target_submesh.pop("FacesDataEdited", None)
                    target_submesh.pop("FacesCountEdited", None)
                    target_submesh.pop("FaceTextureIndicesEdited", None)
                    loop_indices = [
                        li for poly in obj.data.polygons for li in poly.loop_indices
                    ]
                    inplace_normal_buffer = target_submesh.get("NormalBuffer")
                    if (self.use_custom_normals
                            and isinstance(inplace_normal_buffer, dict)
                            and "NormalBufferData" in inplace_normal_buffer):
                        if _apply_inplace_normal_edits(
                            obj,
                            inplace_normal_buffer,
                            loop_indices,
                            errors,
                            use_compression,
                        ):
                            pass_reasons.append(
                                f"{obj.name}: normals split on shared normal slots"
                            )
                    elif isinstance(inplace_normal_buffer, dict):
                        inplace_normal_buffer.pop("NormalBufferDataEdited", None)
                        inplace_normal_buffer.pop("NormalFacesDataEdited", None)
                    # In-place patching cannot write colours: any colour edit
                    # needs Hammerspace.
                    for json_channel in target_submesh.get("ColorChannels", []):
                        json_channel.pop("ColorChannelDataEdited", None)
                        json_channel.pop("ColorFacesDataEdited", None)
                        encoded_colors = encode_color_edits(
                            obj, json_channel, loop_indices, use_compression=False
                        )
                        if encoded_colors is not None and ExportMode.colors_changed(
                            bytes(encoded_colors[0]), json_channel
                        ):
                            pass_reasons.append(
                                f"{obj.name}: vertex colours "
                                f"(color{json_channel.get('ColorChannelIndex', 0)}) edited"
                            )

                    # Re-encode UV channels from Blender UV layers
                    uv_seam_reason_added = False
                    _all_uv_ch = target_submesh.get("UVChannels", [])
                    for json_channel in _all_uv_ch:
                        result = encode_uv_channel_edited(obj, json_channel, use_compression=use_compression, all_uv_channels=_all_uv_ch)
                        ch_ind = json_channel.get("UVChannelIndex", 0)
                        if result is None:
                            layer_name = _uv_layer_name(_all_uv_ch, ch_ind)
                            warnings.append(
                                f"{obj.name}: UV layer '{layer_name}' not found — UV channel {ch_ind} skipped."
                            )
                            continue
                        uv_data_enc, conflicts = result
                        if conflicts and not uv_seam_reason_added:
                            pass_reasons.append(f"{obj.name}: UV seams split")
                            uv_seam_reason_added = True
                        json_channel["UVChannelDataEdited"] = uv_data_enc
                        # UVFacesDataEdited is no longer written: the draw list indices
                        # are unchanged so UVFacesData still applies after patching.

                # Write back DisplayState shader modes (Type-7 FourCC codes) if edited.
                # Prefer mat["ShaderMode"] on the surface material (new path, 2.2+).
                # Fall back to DS_{surface_id}_ShaderMode on the object (legacy path).
                surf_mat = {
                    mat.get("SurfaceId"): mat
                    for slot in obj.material_slots
                    if (mat := slot.material) is not None and mat.get("SurfaceId")
                }
                for ds_idx, ds in enumerate(target_submesh.get("DisplayStates", [])):
                    if ds.get("DisplayStateId") != 7:
                        continue
                    original = ds.get("ShaderMode", "")
                    surface_id = ds.get("SurfaceId") or f"ds{ds_idx}"
                    mat = surf_mat.get(surface_id)
                    if mat is not None:
                        new_val = str(mat.get("ShaderMode") or "")
                    else:
                        prop_val = f"DS_{surface_id}_ShaderMode"
                        new_val = str(obj[prop_val]) if prop_val in obj else None
                    if new_val is not None and new_val != original:
                        ds["ShaderModeEdited"] = new_val
                    else:
                        ds.pop("ShaderModeEdited", None)

                # Write back specular strength (struct offset +1 = index 0 of the
                # 3-byte DisplayStateParamBytes) if edited via the material's
                # "SpecularStrength" custom property. Indices 1 and 2 are preserved.
                for ds_idx, ds in enumerate(target_submesh.get("DisplayStates", [])):
                    if ds.get("DisplayStateId") != 7:
                        continue
                    original_hex = ds.get("DisplayStateParamBytes", "000000")
                    surface_id = ds.get("SurfaceId") or f"ds{ds_idx}"
                    mat = surf_mat.get(surface_id)
                    if mat is None or "SpecularStrength" not in mat:
                        ds.pop("DisplayStateParamBytesEdited", None)
                        continue
                    try:
                        original_bytes = bytes.fromhex(original_hex).ljust(3, b'\x00')[:3]
                    except ValueError:
                        original_bytes = b'\x00\x00\x00'
                    new_strength = max(0, min(255, int(mat["SpecularStrength"])))
                    new_bytes = bytes([new_strength, original_bytes[1], original_bytes[2]])
                    new_hex = new_bytes.hex()
                    if new_hex != original_hex:
                        ds["DisplayStateParamBytesEdited"] = new_hex
                    else:
                        ds.pop("DisplayStateParamBytesEdited", None)

                if plan is not None or skinned_plan is not None:
                    # Faces are routed inside the rebuild entry itself.
                    target_submesh.pop("FaceSurfaceIdsEdited", None)
                    written += 1
                    continue

                # Export per-face draw-state assignment when faces have been moved.
                try:
                    face_sid_data, face_sid_changed = _encode_face_surface_assignment(
                        obj, target_submesh.get("DisplayStates", []),
                        surf_mat, use_compression, warnings,
                    )
                except ValueError as exc:
                    self.report({"ERROR"}, str(exc))
                    return {"CANCELLED"}
                if face_sid_changed and not RigidRebuildExport.is_rigid_submesh(target_submesh):
                    partial_error = _partial_move_error(
                        obj, target_submesh.get("DisplayStates", []), surf_mat,
                    )
                    if partial_error:
                        self.report({"ERROR"}, partial_error)
                        return {"CANCELLED"}
                if face_sid_changed:
                    if not ENABLE_MATERIAL_REASSIGNMENT_EXPORT:
                        self.report({"ERROR"},
                            f"{obj.name}: material reassignment is currently disabled. "
                            "Dolphin testing found unresolved runtime corruption even "
                            "for complete moves between compatible donor surfaces. "
                            "Restore every face to its originally imported material "
                            "before exporting."
                        )
                        return {"CANCELLED"}
                    target_submesh["FaceSurfaceIdsEdited"] = face_sid_data
                    if not use_hammerspace:
                        pass_reasons.append(f"{obj.name}: faces moved to other materials")
                else:
                    target_submesh.pop("FaceSurfaceIdsEdited", None)

                written += 1

            # The in-place skin encoder assumes the donor vertex layout, so a
            # mesh edit that already needs Hammerspace switches before it runs.
            if not use_hammerspace and pass_reasons:
                hammerspace_reasons = pass_reasons
                use_hammerspace = True
                continue

            # Skin data is model-level — purge stale edited fields, then re-encode.
            # Both only make sense when a skinned donor mesh is actually part of
            # this export: purging and re-encoding without one would drop the
            # model's whole SK1/SK2/SKAcc structure (and any skin edit from an
            # earlier run) on, say, a custom-submesh-only export.
            encode_unskinned_bone_reassignments(candidates, data, warnings)
            if skinned_plans:
                # The rebuilt body carries its own weights; SkinDataEdited
                # describes the donor's slots and must not be written.
                _purge_skn_edited(data)
            elif skinned_donor_objects(candidates, data):
                _purge_skn_edited(data)
                if use_hammerspace:
                    try:
                        skn_ok, skn_msg = encode_skin_hammerspace(
                            candidates,
                            data,
                            warnings,
                            use_custom_normals=self.use_custom_normals,
                        )
                    except ValueError as exc:
                        self.report({"ERROR"}, str(exc))
                        return {"CANCELLED"}
                    if not skn_ok:
                        self.report({"ERROR"}, skn_msg)
                        return {"CANCELLED"}
                    if skn_msg:
                        self.report({"INFO"}, skn_msg)
                elif encode_skin_weights_inplace(
                    candidates, data, warnings, use_custom_normals=self.use_custom_normals
                ) is None:
                    pass_reasons.append("skin data no longer fits its original size")
            elif data["SluggiesModel"].get("SkinData") and _skin_data_edited_is_empty(data):
                # Only an export from before this guard existed can have left
                # an empty SkinDataEdited on a skinned model; it would unskin
                # the model. Drop it so the donor structure is used again.
                _purge_skn_edited(data)
                warnings.append(
                    "Removed an empty SkinDataEdited left by an earlier export that "
                    "included no skinned mesh; the model's donor skinning is used again."
                )

            rebuilt_objects = [p.obj for p in list(skinned_plans.values()) + list(rigid_plans.values())]
            update_facial_pose_edits(
                [obj for obj in candidates if not any(rebuilt is obj for rebuilt in rebuilt_objects)],
                data, warnings,
            )
            for rebuilt_plan in list(skinned_plans.values()) + list(rigid_plans.values()):
                _drop_facial_edits_for_submesh(data, rebuilt_plan.submesh_index)

            # Whole-model root-bone scale — model-level, written only when edited.
            root_scale = encode_root_bone_scale_edited(candidates, data, warnings, context)

            if use_hammerspace or not pass_reasons:
                break
            hammerspace_reasons = pass_reasons
            use_hammerspace = True

        self.report({"INFO"}, ExportMode.mode_message(hammerspace_reasons))
        if size_line:
            self.report({"INFO"}, size_line)
        for obj, submesh_index in object_submesh_indices:
            plan = rigid_plans.get(submesh_index)
            if plan is not None:
                self.report({"INFO"},
                    f"{obj.name}: rigid rebuild ({', '.join(plan.reasons)}): "
                    f"{len(plan.donor.faces)} -> {len(plan.geometry.faces)} faces, "
                    f"{len(plan.geometry.positions)} vertices on bone_{plan.host_bone_id}; "
                    + RigidRebuildExport.surface_report(obj.name, plan.routing)
                )
            elif submesh_index in skinned_plans:
                skinned_plan = skinned_plans[submesh_index]
                self.report({"INFO"},
                    f"{obj.name}: body rebuild ({', '.join(skinned_plan.reasons)}): "
                    f"{len(skinned_plan.donor.faces)} -> {len(skinned_plan.geometry.faces)} faces, "
                    f"{len(skinned_plan.geometry.positions)} vertices; "
                    + RigidRebuildExport.surface_report(obj.name, skinned_plan.routing)
                )
            elif RigidRebuildExport.is_rigid_submesh(data["SluggiesModel"]["Submeshes"][submesh_index]):
                self.report({"INFO"}, f"{obj.name}: in-place rigid edit (no rebuild needed).")
        if use_hammerspace:
            ExportMode.promote_inplace_uv_edits(
                data["SluggiesModel"]["Submeshes"],
                [obj["VertexBufferOffset"] for obj, _index in object_submesh_indices],
            )

        # StadiumCollision mirrors the selection once a file has it; a file that
        # never had collision gets no field, so exporting a night model leaves the
        # collision file it shares with the day model alone.
        model = data["SluggiesModel"]
        collision_error = StadiumCollisionExport.chunk_error(
            model.get("ChunkNumber"), [obj.name for obj in collision_objects])
        if collision_error:
            self.report({"ERROR"}, collision_error)
            return {"CANCELLED"}
        if original_colliders:
            model[StadiumCollisionExport.REPLACE_FIELD] = True
        else:
            model.pop(StadiumCollisionExport.REPLACE_FIELD, None)
        if collision_objects or original_colliders or model.get(StadiumCollisionExport.FIELD):
            try:
                model[StadiumCollisionExport.FIELD] = encode_stadium_collision(
                    context, collision_objects, arm_obj, warnings)
            except ValueError as exc:
                self.report({"ERROR"}, str(exc))
                return {"CANCELLED"}
            if original_colliders:
                infos.append(
                    f"Stadium collision rebuilt from the scene: {len(original_colliders)} original "
                    "collider(s) in the scene (deleted or unticked ones are removed from the game)")
            if collision_objects:
                infos.append(
                    f"Stadium collision: {len(collision_objects)} object(s) "
                    f"({', '.join(obj.name for obj in collision_objects)})")
                if invisible_objects:
                    infos.append("Collision only, not drawn: "
                                 + ", ".join(obj.name for obj in invisible_objects))
            else:
                infos.append("Stadium collision: no collision object selected; "
                             "the patcher restores the stadium's vanilla collision")
        else:
            model.pop(StadiumCollisionExport.FIELD, None)

        # INFO stays out of the report popup: the file browser shows only
        # WARNING and above there; the Info editor still lists these.
        for i in infos:
            self.report({"INFO"}, i)
        for w in warnings:
            self.report({"WARNING"}, w)
        for e in errors:
            self.report({"ERROR"}, e)

        written += len(custom_submesh_entries)
        if written == 0 and not collision_objects:
            self.report({"ERROR"}, "No submeshes written. Check the warnings above.")
            return {"CANCELLED"}

        data["SluggiesModel"]["UseHammerspace"] = use_hammerspace
        data["SluggiesModel"]["ReimportTextures"] = (
            self.reimport_textures and bool(local_texture_descriptors)
        )
        # A RigidRebuild left on an unselected submesh by an earlier export
        # keeps its bone move and its PNGs (the two model-level fields above
        # are rebuilt from the selection on every export).
        carry_tex_dir = texture_dir or os.path.join(os.path.dirname(os.path.abspath(self.filepath)), 'tex')

        def _recover_addition(file_name, template_source):
            if not os.path.isfile(os.path.join(carry_tex_dir, file_name)):
                return None
            try:
                return _custom_submesh_template_texture_index(data["SluggiesModel"], template_source)
            except ValueError:
                return None

        carried = RigidRebuildExport.carry_unselected_rebuilds(
            data["SluggiesModel"],
            [index for _obj, index in object_submesh_indices],
            data["SluggiesModel"].get("AdditionalTextureDescriptors") or [],
            recover_addition=_recover_addition,
        )
        if carried.errors:
            for message in carried.errors:
                self.report({"ERROR"}, message)
            return {"CANCELLED"}
        for message in carried.messages:
            self.report({"INFO"}, message)
        additions = _merge_texture_additions(
            additions, custom_additions + new_surface_additions + carried.additions,
        )
        texture_copies = [
            (source_path, os.path.join(texture_dir, name))
            for name, source_path in planned_texture_copies.items()
        ]
        if additions:
            data["SluggiesModel"]["AdditionalTextureDescriptors"] = additions
        else:
            data["SluggiesModel"].pop("AdditionalTextureDescriptors", None)
        if desired_assignments:
            data["SluggiesModel"]["DesiredTextureAssignments"] = desired_assignments
        else:
            data["SluggiesModel"].pop("DesiredTextureAssignments", None)
        if custom_submesh_entries:
            data["SluggiesModel"]["CustomSubmeshes"] = custom_submesh_entries
        else:
            data["SluggiesModel"].pop("CustomSubmeshes", None)
        # A vanilla texture no surface shows any more takes the first new PNG
        # shown in its place instead of appending it.
        reused = TextureSlotsCore.reuse_freed_texture_slots(data["SluggiesModel"])
        for message in reused:
            self.report({"INFO"}, message)
        if reused:
            self.report({"INFO"},
                "Texture slots were refilled: a paired low-poly (_L_) model may now show other "
                "textures; check it with Manage texture slots.")

        # PNGs linked from outside tex/ (and other formats' PNG conversions)
        # are copied in now, once nothing can cancel the export, so the
        # patcher finds them by name.
        try:
            for source_path, target_path in texture_copies:
                os.makedirs(os.path.dirname(target_path), exist_ok=True)
                shutil.copyfile(source_path, target_path)
        except OSError as exc:
            self.report({"ERROR"}, f"Could not copy texture into tex/: {exc}")
            return {"CANCELLED"}
        for source_path, target_path in texture_copies:
            original = TextureConvert.source_of(source_path)
            if original:
                self.report({"INFO"}, f"Converted {original} to the PNG {target_path}")
            else:
                self.report({"INFO"}, f"Copied {source_path} to {target_path}")

        FieldCodec.dump_sluggie(data, self.filepath)
        # The scene now belongs to the written file (a new name, or the
        # target an armature with a lost source read): the next export,
        # Check Models and Texture slots use it.
        if arm_obj is not None:
            SluggiePath.remember(arm_obj, self.filepath)
        if save_as and arm_obj is not None:
            self.report({"INFO"},
                f"Saved as a new file; {arm_obj.name} now uses {self.filepath} "
                f"({os.path.basename(source_path)} is unchanged).")

        context.window_manager.clipboard = ModelCheckCore.clipboard_text(self.filepath)
        scale_note = (
            f" (root bone scale {root_scale[0]:.4f}, {root_scale[1]:.4f}, {root_scale[2]:.4f})"
            if root_scale else ""
        )
        self.report({"INFO"},
            f"Wrote edited vertex data for {written} submesh(es){scale_note} to {self.filepath}")
        return {"FINISHED"}


def menu_func_export(self, context):
    self.layout.operator(SLUGGIES_OT_export.bl_idname, text="Sluggers intermediate (.sluggie)")


def register():
    bpy.utils.register_class(SLUGGIES_OT_export)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)


def unregister():
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    bpy.utils.unregister_class(SLUGGIES_OT_export)
