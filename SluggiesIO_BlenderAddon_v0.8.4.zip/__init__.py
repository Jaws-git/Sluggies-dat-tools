# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

from . import ImportSluggies
from . import ExportSluggies
from . import SluggiesToolsPanel

bl_info = {
    "name": "Sluggies IO",
    "author": "JawSFM",
    "description": "Import/Export Sluggers intermediate JSON files (Mario Super Sluggers - Wii)",
    "blender": (4, 2, 0),
    "version": (0, 8, 4),
    "location": "File > Import/Export > Sluggers intermediate (.sluggie)",
    "warning": "",
    "category": "Import-Export",
}


def register():
    ImportSluggies.register()
    ExportSluggies.register()
    SluggiesToolsPanel.register()


def unregister():
    SluggiesToolsPanel.unregister()
    ImportSluggies.unregister()
    ExportSluggies.unregister()
