"""Check / Repair Models: scope, checks and fixes on the Blender scene.

The rules on plain data live in the bpy-free ``ModelCheckCore``; this module
reads the scene into them. Two callers: the Check Models dialog
(``ModelCheckUI``, every Sluggies armature in the scene) and the exporter
(:func:`export_errors`, the selected model only, error-severity checks).
"""

import json
import math
import os
import shutil
from dataclasses import dataclass, field
from typing import Optional

import bpy

from . import AnmExport
from . import CustomSubmeshExport
from . import ExportMode
from . import ExportBones
from . import ExportRebuildGlue
from . import ExportTextures
from . import FieldCodec
from . import HostBones
from . import ModelCheckCore as core
from . import RigidRebuildExport
from . import SkinnedRebuildExport
from . import SluggiePath
from . import HostBoneScene
from . import SubmeshOps
from . import SurfacePlans
from . import StadiumCollisionExport
from . import TemplateSources
from . import TextureConvert
from .SurfaceMaterials import _set_surface_material_metadata
from .ImportBones import restore_donor_bones
from .ModelCheckCore import ERROR, INFO, WARNING, Finding


@dataclass
class ModelScope:
    armature: object                         # bpy armature object, or None
    meshes: list                             # mesh objects of the model
    model: Optional[dict]                    # the .sluggie's SluggiesModel
    sluggie_path: str = ""
    load_error: str = ""
    for_export: bool = False
    reimport_textures: bool = True           # export option; the dialog assumes on
    unparented: list = field(default_factory=list)  # meshes tied only by VertexBufferOffset
    colliders: list = field(default_factory=list)   # collision-only meshes: never drawn, not in `meshes`
    texture_error: str = ""                  # why the texture context can't be resolved
    _textures: object = None

    @property
    def name(self):
        return self.armature.name if self.armature is not None else "Model"

    @property
    def stadium(self):
        return TemplateSources.is_stadium_chunk((self.model or {}).get("ChunkNumber"))

    @property
    def folder(self):
        return os.path.basename(os.path.dirname(os.path.abspath(self.sluggie_path))) if self.sluggie_path else ""

    def texture_context(self):
        """(descriptors, tex dir, owns its textures), or (None, None, False)."""
        if self._textures is None:
            self._textures = (None, None, False)
            if self.model is not None and self.sluggie_path:
                try:
                    self._textures = ExportTextures._resolve_export_texture_context(self.sluggie_path, self.model)
                except ValueError as exc:
                    self.texture_error = str(exc)
        return self._textures


# ---------------------------------------------------------------------------
# Scope gathering
# ---------------------------------------------------------------------------

def is_sluggies_armature(obj):
    """Armatures the .sluggie importer made (its markers on the object or bones)."""
    if obj is None or obj.type != 'ARMATURE':
        return False
    if SluggiePath.PATH_PROP in obj or 'SluggiesBoneMetadataVersion' in obj:
        return True
    return any(b.get('SluggiesGeoIdRaw') is not None for b in obj.data.bones)


def _parent_armature(obj):
    node = obj.parent
    while node is not None:
        if node.type == 'ARMATURE':
            return node
        node = node.parent
    return None


def _modifier_armatures(obj):
    return [m.object for m in obj.modifiers if m.type == 'ARMATURE' and m.object is not None]


def _load_model(path, cache):
    if path not in cache:
        try:
            cache[path] = (FieldCodec.load_sluggie(path)["SluggiesModel"], "")
        except FileNotFoundError:
            cache[path] = (None, "missing")
        except (OSError, ValueError, KeyError) as exc:
            cache[path] = (None, f"unreadable ({exc})")
    return cache[path]


def gather_scopes(context):
    """One scope per Sluggies armature in the scene (hidden collections
    included): its child meshes, meshes whose Armature modifier targets it,
    and unparented meshes whose VertexBufferOffset matches a submesh of its
    .sluggie. Objects only in deactivated collections (unticked in the
    Outliner) are not part of the view layer and are left out: they are
    references or set-aside copies. Collision-only meshes go to the scope's
    ``colliders``, not its ``meshes`` (``core.is_collision_only``)."""
    cache = {}
    scopes = {}
    excluded = core.excluded_collections(_layer_exclusion_tree(context.view_layer.layer_collection))
    objects = [obj for obj in context.scene.objects
               if core.in_active_collection((c.name for c in obj.users_collection), excluded)]
    for obj in objects:
        if is_sluggies_armature(obj):
            path = SluggiePath.resolve(obj)
            if path:
                model, error = _load_model(path, cache)
            else:   # the recorded file is gone and the search found nothing
                path, model, error = SluggiePath.stored(obj), None, "missing" if SluggiePath.stored(obj) else ""
            scopes[obj.name] = ModelScope(armature=obj, meshes=[], model=model,
                                          sluggie_path=path, load_error=error)
    loose = []
    for obj in objects:
        if obj.type != 'MESH':
            continue
        owner = _parent_armature(obj)
        if owner is None or owner.name not in scopes:
            owner = next((a for a in _modifier_armatures(obj) if a.name in scopes), None)
        if owner is not None:
            scope = scopes[owner.name]
            (scope.colliders if _is_collision_only(obj) else scope.meshes).append(obj)
        elif all(prop in obj for prop in core.REQUIRED_PROPS):
            loose.append(obj)
    for obj in loose:
        matches = [s for s in scopes.values() if s.model is not None
                   and core.submesh_index_by_offset(s.model, obj["VertexBufferOffset"]) is not None]
        if len(matches) == 1:
            matches[0].unparented.append(obj)
    return list(scopes.values())


def _layer_exclusion_tree(layer_collection):
    """The view layer's collections as core.excluded_collections reads them."""
    return (layer_collection.collection.name, layer_collection.exclude,
            [_layer_exclusion_tree(child) for child in layer_collection.children])


def _is_collision_only(obj):
    collision = getattr(obj, 'sluggies_collision', None)
    return core.is_collision_only(
        collision is not None and collision.enabled, bool(obj.get('SluggiesCustomSubmesh')),
        all(prop in obj for prop in core.REQUIRED_PROPS))


def _sluggies_meshes(objects):
    return [
        obj for obj in objects
        if obj.type == 'MESH' and (obj.get('SluggiesCustomSubmesh')
                                   or all(prop in obj for prop in core.REQUIRED_PROPS))
    ]


def selection_armature(objects):
    """The Sluggies armature *objects* (a selection) name: the parent or
    Armature modifier target of a selected Sluggies mesh, else a selected
    armature. Only one the selection itself names: a scene-wide fallback
    could pick another model's armature (High and Low in one scene). Its
    ``SluggieFilePath`` is the exporter's source file."""
    objects = list(objects)
    for obj in _sluggies_meshes(objects):
        candidates = [_parent_armature(obj)] + _modifier_armatures(obj)
        armature = next((a for a in candidates if is_sluggies_armature(a)), None)
        if armature is not None:
            return armature
    return next((o for o in objects if is_sluggies_armature(o)), None)


def export_scope(context, model, filepath, objects, reimport_textures):
    """The exporter's scope: the armature the exporter itself uses and the
    selected meshes it exports."""
    meshes = _sluggies_meshes(objects)
    return ModelScope(
        armature=selection_armature(objects), meshes=meshes, model=model,
        sluggie_path=filepath, for_export=True, reimport_textures=reimport_textures,
    )


# ---------------------------------------------------------------------------
# Reading helpers
# ---------------------------------------------------------------------------

def _is_custom(obj):
    return bool(obj.get('SluggiesCustomSubmesh'))


def _submesh_index(scope, obj):
    if scope.model is None or _is_custom(obj) or "VertexBufferOffset" not in obj:
        return None
    return core.submesh_index_by_offset(scope.model, obj["VertexBufferOffset"])


def _added_bones(arm):
    return [b for b in arm.data.bones if b.get('SluggiesUserAdded')] if arm is not None else []


def _materials(obj):
    seen = []
    for slot in obj.material_slots:
        if slot.material is not None and slot.material not in seen:
            seen.append(slot.material)
    return seen


def _image_path(image):
    path = getattr(image, "filepath_raw", "") or getattr(image, "filepath", "")
    return bpy.path.abspath(path) if path else ""


def _same_dir(a, b):
    return os.path.normcase(os.path.normpath(a)) == os.path.normcase(os.path.normpath(b))


def _same_file_bytes(a, b):
    try:
        with open(a, 'rb') as fa, open(b, 'rb') as fb:
            return fa.read() == fb.read()
    except OSError:
        return False


def _used_materials(obj):
    used = {poly.material_index for poly in obj.data.polygons}
    return {slot.material for i, slot in enumerate(obj.material_slots)
            if i in used and slot.material is not None}


def _used_vertices(mesh):
    return {v for poly in mesh.polygons for v in poly.vertices}


def _rigid_index(scope, obj):
    """The submesh index of a donor rigid (CompCount 3) mesh, else None."""
    index = _submesh_index(scope, obj)
    if index is None or not RigidRebuildExport.is_rigid_submesh(scope.model["Submeshes"][index]):
        return None
    return index


def _owner_bone_id(model, submesh_index):
    return next((int(b["BoneId"]) for b in model.get("BoneHierarchy") or []
                 if ExportBones._bone_geo_id_raw(b) == submesh_index), None)


def _ownerless_rigid(scope, index, vertex_bone_ids):
    """Exports before 2026-10-18 left submesh 0's owner without influences
    when the model also has mesh-less bones, so the mesh imported with no
    bone_<id> group at all; the exporter keeps it on its owner bone."""
    return bool(vertex_bone_ids) and not any(vertex_bone_ids) \
        and _owner_bone_id(scope.model, index) is not None


def _export_bone_records(scope):
    """The bones the exporter checks host bones against: the .sluggie's,
    plus the armature's added bones it exports (by their bone_<id> names)."""
    model = scope.model
    records = HostBones.bone_records_from_hierarchy(model.get("BoneHierarchy") or [], model.get("SkinData"))
    for bone in _added_bones(scope.armature):
        bone_id = core.bone_id_from_name(bone.name)
        parent_id = core.bone_id_from_name(bone.parent.name) if bone.parent is not None else None
        if bone_id is None or (parent_id is None and (bone.parent is not None or not scope.stadium)):
            continue   # not exported; check_donor_bones / check_added_bone_names tell
        records.append(HostBones.BoneRecord(
            bone_id, parent_id, int(bone.get('SluggiesGeoIdRaw', HostBones.GEO_ID_FREE)), False, True))
    return records


def _single_image_path(mat):
    """The file path of a material's one connected image, or ''."""
    nodes = ExportTextures._connected_image_texture_nodes(mat)
    if len(nodes) != 1 or getattr(nodes[0], "image", None) is None:
        return ""
    return _image_path(nodes[0].image)


def _export_file_name(path, tex_dir, plan_copy, reserved=()):
    """The tex/ name the exporter binds *path* by: a PNG outside tex/ (or
    another format's PNG conversion) is copied in under a free (or
    byte-identical) name when *plan_copy*."""
    if plan_copy and tex_dir and os.path.isfile(path) and (
            TextureConvert.needs_conversion(path) or not _same_dir(os.path.dirname(path), tex_dir)):
        try:
            return ExportTextures._plan_external_texture_copy(path, tex_dir, {}, reserved)
        except ValueError:
            pass   # cannot be converted: check_textures tells
    return os.path.basename(path)


def _usable_image_path(path):
    """True when export can read the image at *path*: a PNG, or another
    format it converts (missing files included: check_textures tells)."""
    return bool(path) and (not TextureConvert.needs_conversion(path)
                           or TextureConvert.convert_problem(path) is None)


def _texture_size(path, image=None):
    """``(width, height)`` of the texture at *path*: a PNG's header, else the
    size Blender reads for *image* (a format export converts); or None."""
    size = ExportMode.png_dimensions(path)
    if size is None and image is not None and TextureConvert.needs_conversion(path) \
            and os.path.isfile(path):
        width, height = image.size
        size = (width, height) if width and height else None
    return size


def _used_new_surfaces(obj):
    """The Add-material surfaces faces use: the ones export resolves."""
    used = {poly.material_index for poly in obj.data.polygons}
    found = []
    for i, slot in enumerate(obj.material_slots):
        mat = slot.material
        if i in used and mat is not None and mat.get("SluggiesNewSurface") and mat not in found:
            found.append(mat)
    return found


# ---------------------------------------------------------------------------
# Checks: model level (object_name = the armature)
# ---------------------------------------------------------------------------

def check_edit_mode(context, scope):
    for obj in [scope.armature] + scope.meshes + scope.colliders:
        if obj is not None and obj.mode == 'EDIT':
            yield Finding("edit_mode", ERROR, obj.name, "In Edit Mode",
                          "Export is not possible in Edit Mode. Switch to Object Mode (Tab) and "
                          "export again.", "object_mode", {})


def check_sluggie_file(context, scope):
    if scope.for_export or scope.armature is None:
        return
    locate = {"object": scope.armature.name}
    if not scope.sluggie_path:
        yield Finding("sluggie_path", WARNING, scope.name, "No source .sluggie",
                      "The armature does not record the .sluggie it was imported from, so most "
                      "checks and Add New Submesh/Add material can't run. "
                      + SluggiePath.LOCATE_HINT + ", or re-import the model.",
                      action_id="locate_sluggie", action_args=locate)
    elif scope.load_error:
        yield Finding("sluggie_path", ERROR, scope.name, "Source .sluggie " + scope.load_error.split(' ')[0],
                      f"The armature's source file {scope.sluggie_path} is {scope.load_error}. "
                      "Restore the file, " + SluggiePath.LOCATE_HINT[0].lower() + SluggiePath.LOCATE_HINT[1:]
                      + ", or re-import the model.",
                      action_id="locate_sluggie", action_args=locate)


def check_bone_metadata(context, scope):
    arm = scope.armature
    if arm is None or HostBones.bone_metadata_is_current(arm.get('SluggiesBoneMetadataVersion')):
        return
    blocking = any(_is_custom(o) for o in scope.meshes) or bool(_added_bones(arm))
    yield Finding("bone_metadata", ERROR if blocking else WARNING, arm.name, "Old import: re-import",
                  f"{arm.name}: armature has no current bone metadata (imported with an older "
                  f"add-on). {HostBones.RE_IMPORT_MESSAGE}.")


def check_wrong_model(context, scope):
    arm = scope.armature
    if arm is None or scope.model is None:
        return
    if not HostBones.bone_metadata_is_current(arm.get('SluggiesBoneMetadataVersion')):
        return
    records = ExportBones._armature_donor_bone_records(arm)
    present = {r.bone_id for r in records}
    sluggie = [r for r in HostBones.bone_records_from_hierarchy(
        scope.model.get("BoneHierarchy") or [], scope.model.get("SkinData")) if r.bone_id in present]
    mismatches = HostBones.bone_metadata_mismatches(records, sluggie)
    if mismatches:
        shown = "; ".join(mismatches[:5])
        yield Finding("wrong_model", ERROR, arm.name, "Armature from other model",
                      f"{arm.name}: armature does not match the target .sluggie ({shown}). It was "
                      "imported from a different model; export to the .sluggie it came from.")


def check_added_bone_names(context, scope):
    arm = scope.armature
    if arm is None:
        return
    bones = arm.data.bones
    hand_made = HostBoneScene._hand_made_bones(arm)
    if hand_made:
        yield Finding("hand_made_bones", ERROR, arm.name,
                      core.plural(len(hand_made), "Hand-made bone") + " not in the model",
                      f"{', '.join(hand_made)}: made with Blender's own bone tools, so no mesh can be "
                      "attached to them and they are not exported. 'Renumber Added Bones' in the "
                      "Sluggies sidebar (the fix here) takes them into the model as added bones "
                      "(bone_<id> names). Untick Deform on a helper bone that should stay out of "
                      "the game.",
                      "renumber_bones", {"armature": arm.name})
        return
    donor_count = HostBoneScene._donor_bone_count(arm)
    renames = HostBones.added_bone_renames(donor_count, [
        (b.name, int(b.get('SluggiesCreationOrder', 0))) for b in bones if b.get('SluggiesUserAdded')])
    message = HostBones.added_bone_name_error(renames)
    if message:
        yield Finding("bone_names", ERROR, arm.name, "Added bones need renumbering", message,
                      "renumber_bones", {"armature": arm.name})


def check_donor_bones(context, scope):
    arm = scope.armature
    if arm is None or scope.model is None or scope.for_export:
        return
    # Bones made with Blender's own tools are no renamed originals: the ones that deform are
    # check_added_bone_names' finding, helpers (Deform off) are left alone.
    hand_made = set(HostBoneScene._hand_made_bones(arm))
    bones = [core.BoneInfo(b.name, b.parent.name if b.parent else None, bool(b.get('SluggiesUserAdded')))
             for b in arm.data.bones
             if 'SluggiesUserAdded' in b.keys() and b.name not in hand_made]
    problems = core.donor_bone_problems(bones, scope.model.get("BoneHierarchy") or [], stadium=scope.stadium)
    texts = {
        "renamed": ("Original bone renamed", "Original bones renamed",
                    "keep their bone_<id> names: vertex groups follow the bone name, so weights on "
                    "a renamed bone are ignored on export. Rename them back"),
        "missing": ("Original bone deleted", "Original bones deleted",
                    "are missing from the armature. Export keeps them (they come from the "
                    ".sluggie), but weights on them and their animation are lost in Blender"),
        "reparented": ("Original bone re-parented", "Original bones re-parented",
                       "have another parent in Blender than in the game. Export ignores the "
                       "change; the game keeps the original hierarchy"),
        "orphan": ("Added bone without parent", "Added bones without parent",
                   "have no parent bone and are not exported. Parent them to a bone"),
    }
    # A renamed bone would come back twice (as itself and as its re-created
    # bone_<id>), so the skeleton is restored only once the names are back.
    restore = {"armature": arm.name, "sluggie": scope.sluggie_path}
    restore_note = (". Rename the renamed bones back first; then the fix restores the original "
                    "skeleton from the .sluggie" if problems["renamed"] else
                    ". The fix restores the original skeleton from the .sluggie (deleted bones with "
                    "their track, original parents); added bones stay as they are")
    for kind, names in problems.items():
        if names:
            one, many, why = texts[kind]
            fixable = kind in ("missing", "reparented")
            if fixable:
                why += restore_note
                fixable = not problems["renamed"]
            action = {"object": arm.name, "bones": names} if kind == "orphan" else {}
            yield Finding(f"donor_bones_{kind}", WARNING, arm.name, one if len(names) == 1 else many,
                          f"{', '.join(names[:8])}{' ...' if len(names) > 8 else ''}: these bones {why}.",
                          "restore_skeleton" if fixable else None, restore if fixable else {},
                          action_id="goto_bones" if action else None, action_args=action)


def check_untracked_keys(context, scope):
    arm = scope.armature
    if arm is None or scope.for_export or not _added_bones(arm):
        return
    actions = [a for group in AnmExport.anm_groups().values() for a in group]
    if arm.animation_data is not None and arm.animation_data.action not in actions:
        actions.append(arm.animation_data.action)
    names = AnmExport.untracked_keyed_bones(arm, actions)
    if names:
        yield Finding("untracked_keys", WARNING, arm.name,
                      f"{core.plural(len(names), 'keyed bone')} without track",
                      f"{', '.join(names)}: {HostBones.UNTRACKED_KEYS_MESSAGE}",
                      "bone_track", {"armature": arm.name, "bones": names})


def check_root_scale(context, scope):
    arm = scope.armature
    if arm is None or 'RootBoneScale' not in arm:
        return
    if not core.root_bone_scale_ok(arm['RootBoneScale']):
        yield Finding("root_scale", WARNING, arm.name, "Root bone scale invalid",
                      f"{arm.name}: RootBoneScale must be three numbers; it is ignored on export.",
                      "reset_root_scale", {"armature": arm.name})


def check_texture_reimport_hint(context, scope):
    if scope.for_export or scope.model is None:
        return
    # New PNGs are added on every export; only edits to the model's own
    # textures need the toggle. A changed size is the edit that shows.
    _descriptors, tex_dir, owns = scope.texture_context()
    if not tex_dir or not owns:
        return
    resized = ExportMode.texture_size_changes(scope.model.get("TextureDescriptors") or [], tex_dir)
    if resized:
        yield Finding("reimport_hint", INFO, scope.name, "Export with Reimport textures",
                      "Original textures with a new size: " + ", ".join(sorted(resized)[:8])
                      + ". Enable 'Reimport textures from tex folder' when exporting to write them.")


# ---------------------------------------------------------------------------
# Checks: mesh level
# ---------------------------------------------------------------------------

# A mesh brought in without Sluggies properties.
MAKE_SUBMESH_HINT = "Make it part of a model with Make into submesh (rigid, on one bone)"
MERGE_HINT = "merge it into the main body (select it, then the body, and join with Ctrl+J)"


def _weighted_bones(obj):
    """The bone ids *obj*'s vertices carry positive bone_<id> weights on."""
    return set().union(*ExportRebuildGlue._rigid_vertex_bone_ids(obj))


def _foreign_groups_note(obj):
    """A sentence on vertex groups that name no bone_<id> (weights from
    another rig), or ''."""
    if not obj.vertex_groups or any(core.bone_id_from_name(g.name) is not None for g in obj.vertex_groups):
        return ""
    names = [g.name for g in obj.vertex_groups]
    return (f" Its vertex groups ({', '.join(names[:3])}{' ...' if len(names) > 3 else ''}) name no "
            "bone_<id> of the armature; weights from another rig don't carry over.")


def check_mesh_props(context, scope):
    if scope.for_export:
        return
    for obj in scope.meshes:
        if _is_custom(obj):
            continue
        if not all(prop in obj for prop in core.REQUIRED_PROPS):
            index = None
            if scope.model is not None:
                surfaces = {core.donor_surface_submesh(m.get("SurfaceId")) for m in _materials(obj)}
                surfaces.discard(None)
                index = core.match_submesh(obj.name, len(obj.data.vertices), surfaces, scope.model)
            bones = sorted(_weighted_bones(obj)) if index is None else []
            make_submesh = {"object": obj.name}
            if len(bones) > 1:
                # Only the skinned body (submesh 0) may follow several bones.
                shown = ", ".join(f"bone_{b}" for b in bones[:6]) + (" ..." if len(bones) > 6 else "")
                yield Finding("static_several_bones", WARNING, obj.name, "Static mesh on several bones",
                              f"{obj.name} has no Sluggies properties, so it is not exported, and its "
                              f"vertices are weighted to {len(bones)} bones ({shown}). Only the main "
                              "body may follow several bones; every other mesh follows exactly one. "
                              "Remove all but one bone influence (Make into submesh does that and "
                              f"makes it part of the model), or {MERGE_HINT}.",
                              action_id="make_submesh", action_args=make_submesh)
            elif index is None and scope.model is not None:
                yield Finding("mesh_props", WARNING, obj.name, "Not linked to a submesh",
                              f"{obj.name} lacks the VertexBuffer* properties that tie it to a "
                              "submesh of the .sluggie, and no submesh matches it, so it is not "
                              f"exported. {MAKE_SUBMESH_HINT}, or {MERGE_HINT}."
                              + _foreign_groups_note(obj),
                              action_id="make_submesh", action_args=make_submesh)
            elif index is not None:
                yield Finding("mesh_props", WARNING, obj.name, "Submesh link lost",
                              f"{obj.name} lacks the VertexBuffer* properties that tie it to "
                              f"submesh {index}, so it is not exported. The fix restores them "
                              "from the .sluggie.",
                              "restore_mesh_props", {"object": obj.name, "sluggie": scope.sluggie_path,
                                                     "index": index})
        elif scope.model is not None and _submesh_index(scope, obj) is None:
            yield Finding("mesh_props", WARNING, obj.name, "Not in this .sluggie",
                          f"{obj.name}: no submesh with VertexBufferOffset={obj['VertexBufferOffset']} "
                          f"in {os.path.basename(scope.sluggie_path)}; it is skipped on export.")


def check_duplicate_claims(context, scope):
    by_index = {}
    for obj in scope.meshes:
        index = _submesh_index(scope, obj)
        if index is not None:
            by_index.setdefault(index, []).append(obj)
    for index, objs in by_index.items():
        if len(objs) < 2:
            continue
        names = ", ".join(o.name for o in objs)
        if scope.for_export:
            yield Finding("duplicate_claim", ERROR, objs[1].name, "Same submesh twice",
                          f"{objs[0].name} and {objs[1].name} both belong to submesh {index}. Select "
                          "only one of them and export again. To keep both in the game, turn one into "
                          "a submesh of its own first: 'Make Active Mesh into a Submesh' in the "
                          "Sluggies sidebar.")
        else:
            # The one that stays the imported submesh: an imported edit (`_edit`), else the first.
            keeper = next((o for o in objs if o.name.split('.')[0].endswith('_edit')), objs[0])
            for obj in objs:
                if obj is keeper:
                    continue
                yield Finding("duplicate_claim", INFO, obj.name, f"Same submesh as {keeper.name}",
                              f"{names} all belong to submesh {index} (a copy or a separated part keeps "
                              "the properties of the mesh it came from); only one of them can export as "
                              f"it. Make into submesh turns {obj.name} into a submesh of its own on a "
                              f"bone you pick: its link to submesh {index} is removed, its materials "
                              f"keep their look, and {keeper.name} stays the imported submesh. Or "
                              "export only one of them.",
                              action_id="make_submesh", action_args={"object": obj.name})
    by_custom = {}
    for obj in scope.meshes:
        if _is_custom(obj):
            by_custom.setdefault(str(obj.get('CustomSubmeshId')), []).append(obj)
    for custom_id, objs in by_custom.items():
        if len(objs) > 1:
            yield Finding("duplicate_custom", ERROR, objs[1].name, "Duplicated custom submesh",
                          f"{', '.join(o.name for o in objs)} share CustomSubmeshId {custom_id} "
                          "(copied with Shift+D?). Make each new part with Add New Submesh.")


def check_armature_link(context, scope):
    arm = scope.armature
    for obj in scope.meshes:
        targets = _modifier_armatures(obj)
        follows = ExportRebuildGlue._custom_submesh_armature(obj)
        if follows is None and _is_custom(obj):
            yield Finding("armature_link", ERROR, obj.name, "No Armature modifier",
                          f"{obj.name}: custom submesh has no Armature modifier or armature parent; "
                          "it can't be placed relative to its host bone.",
                          "armature_modifier" if arm is not None else None,
                          {"object": obj.name, "armature": arm.name} if arm is not None else {})
        elif arm is not None and not scope.for_export and targets[:1] != [arm]:
            fix = ("armature_modifier", {"object": obj.name, "armature": arm.name})
            if not targets:
                yield Finding("armature_link", WARNING, obj.name, "No Armature modifier",
                              f"{obj.name} has no Armature modifier on {arm.name}, so it does not follow "
                              "the bones in Blender (and a rebuilt mesh can't be placed).", *fix)
                continue
            # Export places a mesh by its first Armature modifier (a
            # downloaded mesh may still carry one on its own rig); a custom
            # submesh there is refused or misplaced.
            yield Finding("armature_link", ERROR if _is_custom(obj) else WARNING, obj.name,
                          "Armature modifier points to wrong armature",
                          f"{obj.name}: its {'first ' if len(targets) > 1 else ''}Armature modifier "
                          f"follows {targets[0].name}, not {arm.name}. Export places the mesh by that "
                          "armature, so it does not follow the bones (and a rebuilt mesh can't be "
                          f"placed). The fix points it at {arm.name} and removes other Armature "
                          "modifiers.", *fix)
    if arm is None or scope.for_export:
        return
    for obj in scope.meshes + scope.unparented:
        if _parent_armature(obj) is not arm:
            yield Finding("parent", WARNING, obj.name, "Not parented to armature",
                          f"{obj.name} belongs to {arm.name} but is not its child. The fix parents "
                          "it to the armature and keeps its world position.",
                          "reparent", {"object": obj.name, "armature": arm.name})


def check_modifiers(context, scope):
    if scope.for_export:
        return
    for obj in scope.meshes:
        names = CustomSubmeshExport.unsupported_modifier_names((m.name, m.type) for m in obj.modifiers)
        if names:
            text = f"{names[0]} modifier not applied" if len(names) == 1 else \
                f"{len(names)} modifiers not applied"
            yield Finding("modifiers", WARNING, obj.name, text,
                          f"{obj.name}: modifier(s) {', '.join(names)} are not evaluated on export; "
                          "apply them first or their geometry is missing in game.")


def check_geometry(context, scope):
    for obj in scope.meshes:
        mesh = obj.data
        scale = obj.matrix_world.to_scale()
        if any(abs(v) < 1e-8 for v in scale):
            yield Finding("zero_scale", ERROR, obj.name, "Scaled to zero",
                          f"{obj.name} is scaled to zero on an axis; its geometry can't be exported. "
                          "Fix the object's scale.")
        coords = [0.0] * (len(mesh.vertices) * 3)
        mesh.vertices.foreach_get("co", coords)
        if not all(math.isfinite(c) for c in coords):
            yield Finding("bad_coords", ERROR, obj.name, "Invalid vertex positions",
                          f"{obj.name} has vertices with invalid (NaN or infinite) positions.")
        if not mesh.polygons:
            index = _submesh_index(scope, obj)
            donor_faces = 0
            if index is not None:
                donor_faces = int(scope.model["Submeshes"][index].get("FacesCount") or 0)
            # A donor submesh that never had faces exports fine as it is.
            if _is_custom(obj) or donor_faces:
                yield Finding("no_faces", ERROR, obj.name, "No faces",
                              f"{obj.name}: mesh has no faces.")


def check_mesh_limits(context, scope):
    """The uint16 indices every rebuild writes: the vertices faces use and
    the triangle count (a downloaded high-poly mesh). Every rebuild and the
    patcher refuse more than U16_LIMIT triangles, not only custom submeshes.
    Runs on export too: the encoders pack these indices before their own
    count checks in some orders."""
    for obj in scope.meshes:
        custom = _is_custom(obj)
        if not custom and _submesh_index(scope, obj) is None:
            continue
        over = []
        vertices = len(_used_vertices(obj.data))
        if vertices > core.U16_LIMIT:
            over.append(f"{vertices:,} vertices")
        triangles = _triangle_count(obj.data)
        if triangles > core.U16_LIMIT:
            over.append(f"{triangles:,} triangles")
        if over:
            yield Finding("mesh_limits", ERROR, obj.name, f"Too many {over[0].split(' ')[1]}",
                          f"{obj.name}: {' and '.join(over)}; the game indexes at most "
                          f"{core.U16_LIMIT:,} per mesh. Reduce it (Decimate modifier, applied) or "
                          "split it into several submeshes.")


def check_rebuild_format(context, scope):
    """A changed topology needs the rigid or body rebuild, which reads int16
    positions only. (A move or new surfaces need it too; those show only on
    export.)"""
    if scope.model is None:
        return
    for obj in scope.meshes:
        index = _submesh_index(scope, obj)
        if index is None:
            continue
        sub = scope.model["Submeshes"][index]
        if (int((sub.get("VertexBuffer") or {}).get("VertexBufferQuantizeInfo", 0x30)) >> 4) == 3:
            continue   # int16: both rebuilds take it
        if RigidRebuildExport.is_rigid_submesh(sub):
            donor = RigidRebuildExport.donor_rigid_submesh(index, sub)
            error = RigidRebuildExport.donor_position_format_error(donor, obj.name)
        elif index == 0 and SkinnedRebuildExport.is_skinned_submesh(sub):
            donor = SkinnedRebuildExport.donor_skinned_submesh(index, sub, scope.model.get("SkinData"))
            error = SkinnedRebuildExport.donor_position_format_error(donor, obj.name)
        else:
            continue
        if error and ExportMode.topology_changed((poly.vertices for poly in obj.data.polygons),
                                                 sub.get("FacesData")):
            yield Finding("rebuild_format", ERROR, obj.name, "Faces can't change here", error)


def check_collision(context, scope):
    """Stadium collision settings the exporter refuses."""
    if scope.model is None:
        return
    enabled = [obj for obj in scope.meshes + scope.colliders
               if getattr(obj, 'sluggies_collision', None) is not None and obj.sluggies_collision.enabled]
    for obj in enabled:
        if obj.sluggies_collision.invisible and not _is_custom(obj) \
                and all(prop in obj for prop in core.REQUIRED_PROPS):
            yield Finding("collision_invisible", ERROR, obj.name, "Original mesh made invisible",
                          StadiumCollisionExport.invisible_model_mesh_error([obj.name]))
    message = StadiumCollisionExport.chunk_error(scope.model.get("ChunkNumber"), [obj.name for obj in enabled])
    if message:
        yield Finding("collision_chunk", ERROR, scope.name, "Collision not possible here", message)
    elif scope.colliders:
        # One line for all of them: the checks of a drawn mesh do not apply to a collider.
        count = len(scope.colliders)
        shown = ", ".join(obj.name for obj in scope.colliders[:4]) + (" ..." if count > 4 else "")
        yield Finding("collision_only", INFO, scope.name,
                      core.plural(count, "collision mesh", "collision meshes") + ": not drawn, fine as they are",
                      f"{shown}: exported as stadium collision only (their triangles and Solid for the "
                      "ball settings). They need no submesh link, Armature modifier, material or UV map.")


def check_custom_host_bone(context, scope):
    for obj in scope.meshes:
        if not _is_custom(obj):
            continue
        ok, majority = core.host_bone_vote(ExportRebuildGlue._rigid_vertex_bone_ids(obj))
        if not ok:
            yield Finding("one_bone", ERROR, obj.name, "Not on one bone",
                          f"{obj.name}: every vertex must belong to exactly one bone_<id> vertex "
                          "group (the host bone), all the same bone."
                          + (f" The fix puts every vertex on bone_{majority}." if majority is not None else ""),
                          "one_bone" if majority is not None else None,
                          {"object": obj.name, "bone_id": majority} if majority is not None else {})


def check_rigid_one_bone(context, scope):
    """The exporter's rule for an original rigid mesh (_rigid_rebuild_plan):
    every vertex on the same one bone_<id> group."""
    if scope.model is None:
        return
    for obj in scope.meshes:
        index = _rigid_index(scope, obj)
        if index is None:
            continue
        vertex_bone_ids = ExportRebuildGlue._rigid_vertex_bone_ids(obj)
        if _ownerless_rigid(scope, index, vertex_bone_ids):
            continue
        problem = RigidRebuildExport.vertex_bone_problem(obj.name, vertex_bone_ids)
        if problem:
            _ok, majority = core.host_bone_vote(vertex_bone_ids)
            yield Finding("rigid_one_bone", ERROR, obj.name, "Rigid mesh not on one bone",
                          problem + (f" The fix puts every vertex on bone_{majority}." if majority is not None else ""),
                          "one_bone" if majority is not None else None,
                          {"object": obj.name, "bone_id": majority} if majority is not None else {})


def check_host_bones(context, scope):
    """Host bones as the exporter re-checks them: a rigid mesh's bone must
    exist, a moved rigid mesh needs a free bone, and a custom submesh's bone
    must exist, own no mesh and host no other custom submesh."""
    arm = scope.armature
    if arm is None or scope.model is None \
            or not HostBones.bone_metadata_is_current(arm.get('SluggiesBoneMetadataVersion')):
        return
    records = _export_bone_records(scope)
    known = {r.bone_id for r in records}
    donors = [obj for obj in scope.meshes if _submesh_index(scope, obj) is not None]
    retargets, issues, obj_by_submesh = ExportBones._candidate_rigid_retargets(donors, scope.model)
    for obj in donors:
        index = _rigid_index(scope, obj)
        if index is None:
            continue
        bone_id = ExportBones._detect_uniform_vertex_bone_id(obj)
        if bone_id is not None and bone_id not in known:
            yield Finding("host_bone", ERROR, obj.name, "Host bone missing",
                          f"{obj.name}: host bone {bone_id} does not exist in the target .sluggie "
                          "BoneHierarchy. Move the mesh to an existing bone.")
    for issue in issues:
        obj = obj_by_submesh.get(issue.submesh_index)
        if obj is None or issue.reason == "unknown_bone":
            continue
        if issue.reason == "target_claimed_by_other_submesh":
            detail = (f"{obj.name}: bone_{issue.target_bone_id} is already requested by submesh "
                      f"{issue.detail}; one non-skinned bone can own only one GeoId.")
        else:
            detail = (f"{obj.name}: bone_{issue.target_bone_id} currently owns submesh {issue.detail}; "
                      "the move is skipped to avoid a GeoId collision.")
        yield Finding("host_bone_taken", WARNING, obj.name, "Moved onto a taken bone",
                      detail + " Use Reassign bone to move it to a free bone.",
                      action_id="reassign_bone", action_args={"object": obj.name})
    hosts_by_bone = {}
    for obj in scope.meshes:
        if _is_custom(obj):
            bone_id = ExportBones._detect_uniform_vertex_bone_id(obj)
            if bone_id is not None:
                hosts_by_bone.setdefault(bone_id, []).append(obj)
    names = {index: obj.name for index, obj in obj_by_submesh.items()}
    for bone_id, objs in hosts_by_bone.items():
        hosts = [HostBones.CustomSubmeshHost(obj.name, bone_id) for obj in objs]
        for message in HostBones.custom_submesh_host_errors(records, retargets, hosts, names):
            yield Finding("custom_host_bone", ERROR, objs[0].name, f"Host bone_{bone_id} not usable", message)


def check_body_weights(context, scope):
    model = scope.model
    if model is None or not model.get("SkinData"):
        return
    arm = scope.armature
    for obj in scope.meshes:
        index = _submesh_index(scope, obj)
        if index != 0 or obj.get("VertexBufferCompCount") != 6:
            continue
        weights = ExportRebuildGlue._vertex_bone_weights(obj)
        hierarchy = model.get("BoneHierarchy") or []
        parent_of = {int(b["BoneId"]): b.get("ParentBoneId") for b in hierarchy if "BoneId" in b}
        added = set()
        for bone in _added_bones(arm):
            bone_id = core.bone_id_from_name(bone.name)
            if bone_id is not None:
                added.add(bone_id)
                parent_of[bone_id] = core.bone_id_from_name(bone.parent.name) if bone.parent else None
        allowed = core.allowed_skin_bones(parent_of, added)
        donor_count = core.vertex_buffer_vertex_count(model["Submeshes"][0].get("VertexBuffer") or {})
        covered = core.donor_covered_vertices(hierarchy, 0) if donor_count == len(obj.data.vertices) else None
        unweighted = core.unweighted_vertices(weights, _used_vertices(obj.data), allowed, parent_of, covered)
        # Vertices weighted only to bones this model doesn't have are
        # reported by bone.
        bare, by_bone = SkinnedRebuildExport.split_unweighted(unweighted, weights)
        if by_bone:
            bones = (SkinnedRebuildExport.bone_list(by_bone) if len(by_bone) <= 2
                     else f"{len(by_bone)} bones")
            yield Finding("unskinnable_bones", ERROR, obj.name, f"{bones} can't be used for skinning",
                          SkinnedRebuildExport.unskinnable_error(obj.name, by_bone))
        if bare:
            yield Finding("unweighted", ERROR, obj.name, f"{core.plural(len(bare), 'vert')} unweighted",
                          f"{obj.name}: {len(bare)} vertex(es) have no weight on any bone of this "
                          "model. Assign them to bone_<id> vertex groups.")
        over = core.overweighted_vertices(weights)
        if over and not scope.for_export:
            yield Finding("overweighted", WARNING, obj.name,
                          f"{core.plural(len(over), 'vert')} on > {core.MAX_BONE_INFLUENCES} bones",
                          f"{obj.name}: {len(over)} vertex(es) are weighted to more than "
                          f"{core.MAX_BONE_INFLUENCES} bones; more did not work in-game. The fix "
                          f"keeps the strongest {core.MAX_BONE_INFLUENCES} and normalizes them.",
                          "limit_weights", {"object": obj.name})


def check_materials(context, scope):
    arm = scope.armature
    for obj in scope.meshes:
        index = _submesh_index(scope, obj)
        custom = _is_custom(obj)
        if not custom and index is None:
            continue
        used_slots = {poly.material_index for poly in obj.data.polygons}
        if not scope.for_export:
            empty = [i for i, slot in enumerate(obj.material_slots) if slot.material is None]
            empty_used = [i for i in empty if i in used_slots]
            if empty_used:
                yield Finding("empty_slot", WARNING, obj.name, "Faces on empty slot",
                              f"{obj.name}: faces use a material slot without a material; they keep "
                              "their original surface or are refused. Assign a material.")
            if set(empty) - set(empty_used):
                yield Finding("empty_slot_unused", WARNING, obj.name, "Empty material slot",
                              f"{obj.name} has empty material slots no face uses. The fix removes them.",
                              "remove_slots", {"object": obj.name,
                                               "slots": sorted(set(empty) - set(empty_used))})
        target = scope.model["Submeshes"][index] if index is not None else None
        foreign = ExportTextures._find_new_materials(obj, target, index)
        if foreign:
            names = ", ".join(f"'{n}' ({r})" for n, r in foreign)
            detail = (f"{obj.name}: custom submeshes support only their own surface materials ({names})"
                      if custom else
                      f"Error: {obj.name} uses material(s) that are not surfaces of this submesh: "
                      f"{names}. Use its imported materials or Add material, and reassign or remove "
                      "the other faces.")
            plain = [n for n, _r in foreign
                     if not bpy.data.materials[n].get("SurfaceId")
                     and not bpy.data.materials[n].get("SluggiesNewSurface")]
            if scope.for_export or not plain or arm is None or scope.model is None:
                yield Finding("foreign_material", ERROR, obj.name, "Material not of this submesh", detail)
            else:
                yield Finding("plain_material", ERROR, obj.name,
                              "Plain Blender material" if len(plain) == 1 else
                              f"{len(plain)} plain Blender materials",
                              detail + " The fix turns " + ", ".join(plain) + " into new surfaces "
                              f"(as Add material, template {core.default_template(scope.stadium)}).",
                              "material_defaults", {"object": obj.name, "materials": plain,
                                                    "armature": arm.name,
                                                    "template": core.default_template(scope.stadium)})
                if len(plain) < len(foreign):
                    yield Finding("foreign_material", ERROR, obj.name, "Material of other submesh", detail)
        if scope.for_export:
            continue
        missing = []
        for mat in _materials(obj):
            if mat.get("SluggiesNewSurface"):
                if any(prop not in mat for prop in core.NEW_SURFACE_PROPS):
                    missing.append((mat.name, False))
            elif core.donor_surface_submesh(mat.get("SurfaceId")) is not None:
                if any(prop not in mat for prop in core.DONOR_MATERIAL_PROPS):
                    missing.append((mat.name, True))
        fixable = [n for n, ok in missing if ok]
        if fixable and scope.model is not None:
            yield Finding("material_props", WARNING, obj.name, "Material properties missing",
                          f"{', '.join(fixable)}: Sluggies material properties are missing; export "
                          "can't map the texture/shader. The fix restores them from the .sluggie.",
                          "restore_material_props", {"object": obj.name, "materials": fixable,
                                                     "sluggie": scope.sluggie_path})
        broken = [n for n, ok in missing if not ok]
        if broken:
            yield Finding("material_props_new", ERROR, obj.name, "New material broken",
                          f"{', '.join(broken)}: Add-material properties are missing. Delete the "
                          "material and make it again with Add material.")
        sids = {}
        for slot in obj.material_slots:
            sid = slot.material.get("SurfaceId") if slot.material is not None else None
            if sid:
                sids[sid] = sids.get(sid, 0) + 1
        doubled = [sid for sid, n in sids.items() if n > 1]
        if doubled:
            yield Finding("duplicate_surface", WARNING, obj.name, "Surface on two slots",
                          f"{obj.name}: SurfaceId {', '.join(doubled)} is on several material slots; "
                          "only the first slot is used.")
        unused_new = [i for i, slot in enumerate(obj.material_slots)
                      if slot.material is not None and slot.material.get("SluggiesNewSurface")
                      and i not in used_slots]
        if unused_new:
            yield Finding("unused_surface", INFO, obj.name, "Unused new material",
                          f"{obj.name}: new material(s) "
                          f"{', '.join(obj.material_slots[i].material.name for i in unused_new)} are "
                          "used by no face and not exported. The fix removes their slots.",
                          "remove_slots", {"object": obj.name, "slots": unused_new})


def check_custom_uvs(context, scope):
    for obj in scope.meshes:
        if not _is_custom(obj):
            continue
        layers = obj.data.uv_layers
        if not len(layers):
            yield Finding("no_uv", ERROR, obj.name, "No UV map",
                          f"{obj.name}: custom submesh has no UV map; add one and unwrap it.")
        elif len(layers) > 1 and not scope.for_export:
            yield Finding("extra_uv", WARNING, obj.name, "Extra UV maps ignored",
                          f"{obj.name}: only the render-active UV map is exported; other UV maps "
                          "are ignored.")
        if obj.data.shape_keys and not scope.for_export:
            yield Finding("shape_keys", WARNING, obj.name, "Shape keys ignored",
                          f"{obj.name}: shape keys on a custom submesh are not exported.")


def check_textures(context, scope):
    descriptors, tex_dir, _owns = scope.texture_context()
    reserved = [d.get("TextureFileName") for d in descriptors or [] if d.get("TextureFileName")]
    for obj in scope.meshes:
        custom = _is_custom(obj)
        used = _used_materials(obj)
        for mat in _materials(obj):
            new = bool(mat.get("SluggiesNewSurface")) or custom
            if not (mat.get("SurfaceId") or mat.get("SluggiesNewSurface")):
                continue
            nodes = ExportTextures._connected_image_texture_nodes(mat)
            if any(getattr(node, "image", None) is None for node in nodes):
                yield Finding("empty_node", ERROR, obj.name, "Texture node empty",
                              f"'{mat.name}' on {obj.name} has an Image Texture node without an image; "
                              "load an image into it (or remove the node) before exporting")
                continue
            if not nodes:
                if new:
                    yield Finding("empty_node", ERROR, obj.name, "No texture image",
                                  f"'{mat.name}' on {obj.name} has no image in its texture node; "
                                  "load an image before exporting")
                continue
            if len(nodes) > 1:
                yield Finding("multi_image", ERROR, obj.name, "Several textures in material",
                              f"Multiple textures in one material are not supported: {mat.name}")
                continue
            # A texture problem blocks the export when the export reads the
            # PNG: a new PNG always, the model's own textures only with
            # Reimport textures.
            gate = scope.reimport_textures or new \
                or os.path.basename(_image_path(nodes[0].image)) not in reserved
            primary = custom and str(mat.get("SurfaceId") or "").startswith(f"{obj.get('CustomSubmeshId')}_ds")
            if scope.for_export and (not gate or (new and mat not in used and not primary)):
                # Export resolves only the new surfaces faces use.
                continue
            yield from _image_findings(scope, obj, mat, nodes[0].image, new, tex_dir, reserved)


def _image_findings(scope, obj, mat, image, new, tex_dir, reserved):
    path = _image_path(image)
    fix_tex = {"image": image.name, "tex_dir": tex_dir} if tex_dir else {}
    if not path:
        yield Finding("image_path", ERROR, obj.name, "Image not saved",
                      f"Material image has no file path: {mat.name}. The fix saves it as a PNG "
                      "into the model's tex/ folder.", "image_to_tex" if tex_dir else None, fix_tex)
        return
    if image.is_dirty and not scope.for_export:
        yield Finding("unsaved_image", WARNING, obj.name, "Unsaved image",
                      f"'{image.name}' ({mat.name}) was edited in Blender but not saved; export reads "
                      "the PNG from disk, so the edit is lost. The fix saves it.",
                      "save_image", {"image": image.name})
    convert = TextureConvert.needs_conversion(path)
    problem = TextureConvert.convert_problem(path) if convert else None
    if problem:
        yield Finding("not_png", ERROR, obj.name, "Image format not supported",
                      f"Material '{mat.name}' image must be a {TextureConvert.FORMAT_NAMES}: "
                      f"{os.path.basename(path)} {problem}. The fix saves it as a PNG into tex/.",
                      "image_to_tex" if tex_dir else None, fix_tex)
        return
    if not os.path.isfile(path):
        packed = image.packed_file is not None
        what = "image" if convert else "PNG"
        yield Finding("image_missing", ERROR, obj.name, f"{what.capitalize()} file missing",
                      f"'{mat.name}': the {what} {path} does not exist."
                      + (" It is packed into the .blend; the fix writes it into tex/." if packed else ""),
                      "image_to_tex" if packed and tex_dir else None, fix_tex if packed else {})
        return
    if convert and not scope.for_export:
        target = _export_file_name(path, tex_dir, True, reserved) if tex_dir \
            else TextureConvert.converted_name(os.path.basename(path))
        yield Finding("converted_image", INFO, obj.name, "Image converted to PNG",
                      f"'{mat.name}': {os.path.basename(path)} is not a PNG; the export converts it and "
                      f"writes tex/{target}. The fix saves it as a PNG into tex/ now and points the "
                      "image at it.", "image_to_tex" if tex_dir else None, fix_tex)
    elif tex_dir and not new and not scope.for_export and not _same_dir(os.path.dirname(path), tex_dir) \
            and not _same_file_bytes(path, os.path.join(tex_dir, os.path.basename(path))):
        # The patcher reads tex/<name>; the export copies a PNG from
        # elsewhere in (a free name if taken), so this only tells.
        yield Finding("outside_tex", WARNING, obj.name, "PNG outside tex/",
                      f"Texture PNG for material '{mat.name}' is not in the resolved tex folder: "
                      f"{os.path.join(tex_dir, os.path.basename(path))}. The export copies it there; "
                      f"the fix copies {path} now (a free name if taken) and points the image at the copy.",
                      "copy_to_tex", {**fix_tex, "reserved": reserved})
    size = _texture_size(path, image) if not scope.for_export else None
    if size and max(size) > core.GX_MAX_TEXTURE_DIMENSION:
        yield Finding("big_texture", WARNING, obj.name, f"Texture over {core.GX_MAX_TEXTURE_DIMENSION} px",
                      f"{os.path.basename(path)} is {size[0]}x{size[1]}; the patcher scales it down to "
                      f"fit {core.GX_MAX_TEXTURE_DIMENSION}x{core.GX_MAX_TEXTURE_DIMENSION} (GX limit).",
                      action_id="show_name", action_args={"name": os.path.basename(path)})


def check_texture_owner(context, scope):
    if scope.model is None:
        return
    scope.texture_context()
    if scope.texture_error:
        yield Finding("texture_owner", ERROR, scope.name, "Texture folder not found", scope.texture_error)


def check_texture_bindings(context, scope):
    """The exporter's texture index rules (_resolve_material_texture_changes,
    _resolve_custom_submesh_texture_changes): templates that resolve, donor
    TextureIndex in range, one rebind per surface, and a Low model showing
    only its High model's textures."""
    if scope.model is None:
        return
    descriptors, tex_dir, owns = scope.texture_context()
    if descriptors is None:
        return
    count = len(descriptors)
    index_by_name = {d.get("TextureFileName"): int(d["TextureIndex"])
                     for d in descriptors if d.get("TextureFileName")}
    low_hint = ("Low-poly model textures are owned by the paired main model; a low-poly material can only "
                "show one of the main model's textures (see Manage texture slots). Add new PNGs on the "
                "main model and export it first")
    for obj in scope.meshes:
        custom = _is_custom(obj)
        new_pngs = []
        if custom:
            source = str(obj.get("TemplateSource") or "")
            template = None
            try:
                CustomSubmeshExport.attribute_plan(scope.model, source)
                template = ExportTextures._custom_submesh_template_texture_index(scope.model, source)
            except ValueError as exc:
                yield Finding("template", ERROR, obj.name, "Template not in this model", f"{obj.name}: {exc}")
            primary = ExportTextures._custom_submesh_material(obj)
            if primary is None:
                yield Finding("own_material", ERROR, obj.name, "Own material missing",
                              f"{obj.name}: custom submesh has no material with its own SurfaceId "
                              f"'{obj.get('CustomSubmeshId')}_ds0'. Make the part again with Add New Submesh.")
            elif template is not None and not 0 <= template < count:
                yield Finding("template", ERROR, obj.name, "Template texture invalid",
                              f"Material '{primary.name}' has invalid template texture index {template}")
            new_materials = ([primary] if primary is not None else []) \
                + [m for m in _used_new_surfaces(obj) if m is not primary]
        elif _submesh_index(scope, obj) is not None:
            new_materials = _used_new_surfaces(obj)
            rebound = {}
            # The exporter resolves donor materials only with textures to bind.
            for slot in obj.material_slots if (owns or descriptors) else ():
                mat = slot.material
                if mat is None or not mat.get("SurfaceId") or mat.get("SluggiesNewSurface"):
                    continue
                path = _single_image_path(mat)
                if not _usable_image_path(path):
                    continue   # no image or a format export cannot convert: check_textures tells
                original = int(mat.get("TextureIndex", -1))
                if not 0 <= original < count:
                    yield Finding("texture_index", ERROR, obj.name, "Invalid texture index",
                                  f"Material '{mat.name}' has invalid donor TextureIndex {original}. "
                                  "Pick its texture in Manage texture slots, or re-import the model "
                                  "to get the imported value back.",
                                  action_id="texture_slots", action_args={"object": obj.name})
                    continue
                file_name = _export_file_name(path, tex_dir, owns)
                desired = index_by_name.get(file_name)
                if desired is None and not owns:
                    new_pngs.append(file_name)
                if desired != original:
                    rebound.setdefault(mat["SurfaceId"], []).append(mat.name)
            for surface_id, names in rebound.items():
                if len(names) > 1:
                    yield Finding("surface_rebound_twice", ERROR, obj.name, "Surface rebound twice",
                                  f"SurfaceId '{surface_id}' is assigned by multiple materials "
                                  f"({', '.join(names)}) that show another texture. Keep one slot "
                                  "for the surface.")
        else:
            continue
        for mat in new_materials:
            if mat.get("SluggiesNewSurface"):
                template = int(mat.get("TemplateTextureIndex", -1))
                if not 0 <= template < count:
                    yield Finding("template", ERROR, obj.name, "Template texture invalid",
                                  f"Material '{mat.name}' has invalid template texture index {template}. "
                                  "Delete the material and make it again with Add material.")
            path = _single_image_path(mat)
            if not owns and _usable_image_path(path) \
                    and _export_file_name(path, tex_dir, True, index_by_name) not in index_by_name:
                new_pngs.append(os.path.basename(path))
        if new_pngs:
            yield Finding("low_new_png", ERROR, obj.name, "New PNG on a Low model",
                          f"{obj.name}: {low_hint}: {', '.join(dict.fromkeys(new_pngs))}",
                          action_id="export_high")


# (function, run on export). Export-run checks report their ERROR findings
# only; checks that make no sense on a selection skip themselves there. The
# dialog-only checks marked "mirror" repeat errors the exporter raises itself
# while encoding.
CHECKS = [
    (check_edit_mode, True),
    (check_sluggie_file, False),
    (check_bone_metadata, True),
    (check_wrong_model, True),
    (check_added_bone_names, True),
    (check_donor_bones, False),
    (check_untracked_keys, False),
    (check_root_scale, False),
    (check_mesh_props, False),
    (check_duplicate_claims, True),
    (check_armature_link, True),
    (check_modifiers, False),
    (check_geometry, True),
    (check_mesh_limits, True),
    (check_rebuild_format, False),      # mirror
    (check_collision, False),           # mirror
    (check_custom_host_bone, True),
    (check_rigid_one_bone, False),      # mirror
    (check_host_bones, False),          # mirror
    (check_body_weights, True),
    (check_materials, True),
    (check_custom_uvs, True),
    (check_textures, True),
    (check_texture_owner, False),       # mirror
    (check_texture_bindings, False),    # mirror
    (check_texture_reimport_hint, False),
]


def check_low_high_bones(scopes):
    """A Low model's added bones that its High model in the scene lacks:
    the patcher refuses a Low model drawing on bones its High model does not
    have."""
    for low in scopes:
        if low.armature is None or not core.is_low_folder(low.folder):
            continue
        used = set()
        for obj in low.meshes:
            used.update(vg.name for vg in obj.vertex_groups)
        low_added = {b.name for b in _added_bones(low.armature)} & used
        highs = [high for high in scopes
                 if high.armature is not None and core.low_partner_matches(low.folder, high.folder)]
        # Several variants of the High model loaded: only the one that pairs
        # with this Low file (all of them when the rule cannot tell).
        partner = core.pick_partner([high.sluggie_path for high in highs], low.sluggie_path)
        if partner is not None and len(highs) > 1:
            highs = [high for high in highs if high.sluggie_path == partner][:1]
        for high in highs:
            missing = sorted(low_added - {b.name for b in _added_bones(high.armature)})
            if missing:
                yield Finding("low_high_bones", WARNING, low.name, "Added bones missing on High",
                              f"{', '.join(missing)}: the Low model uses these added bones but its "
                              f"High model {high.name} lacks them; the patcher refuses that pair. "
                              "Add the same bones to the High model.")


# Object types that look like model parts but export never reads.
_NON_MESH_GEOMETRY = {'CURVE': "curve", 'SURFACE': "surface", 'FONT': "text", 'META': "metaball",
                      'CURVES': "hair curves", 'POINTCLOUD': "point cloud", 'VOLUME': "volume"}


def _layer_collection_tree(layer_collection):
    collection = layer_collection.collection
    hidden = layer_collection.exclude or layer_collection.hide_viewport or collection.hide_viewport
    return (collection.name, hidden, [_layer_collection_tree(c) for c in layer_collection.children])


def check_stray_objects(context, scopes):
    """Meshes in no model: no Sluggies armature above them (none at all, or
    a downloaded rig's), so export never reads them; and other geometry
    (curves, text, ...) on a Sluggies armature, which it never reads either.
    Objects only in hidden or excluded collections are references: skipped."""
    claimed = {obj.name for scope in scopes for obj in scope.meshes + scope.unparented + scope.colliders}
    visible = core.visible_collections(_layer_collection_tree(context.view_layer.layer_collection))
    for obj in context.scene.objects:
        if not any(c.name in visible for c in obj.users_collection):
            continue
        rig = _parent_armature(obj)
        owner = rig if is_sluggies_armature(rig) else None
        if obj.type == 'MESH':
            collision = getattr(obj, 'sluggies_collision', None)
            if owner is not None or obj.name in claimed or (collision is not None and collision.enabled) \
                    or obj.get(core.BACKUP_PROP):
                continue
            where = (f"is parented to {rig.name}, which is not an imported Sluggies armature"
                     if rig is not None else "is not parented to a Sluggies armature")
            yield Finding("stray_mesh", WARNING, obj.name, "Not part of any model",
                          f"{obj.name} {where}, so it belongs to no model and is never exported. "
                          f"{MAKE_SUBMESH_HINT}, or {MERGE_HINT}. Hide its collection if it is only "
                          "a reference." + _foreign_groups_note(obj),
                          action_id="make_submesh", action_args={"object": obj.name})
        elif obj.type in _NON_MESH_GEOMETRY and owner is not None:
            yield Finding("stray_geometry", WARNING, obj.name,
                          f"{_NON_MESH_GEOMETRY[obj.type].capitalize()} object is not exported",
                          f"{obj.name} is a {_NON_MESH_GEOMETRY[obj.type]} object on {owner.name}; "
                          "only meshes are exported. Convert it (Object > Convert > Mesh), then "
                          f"{MAKE_SUBMESH_HINT[0].lower()}{MAKE_SUBMESH_HINT[1:]}.")


# (path, mtime) -> ModelLength of a LOD partner's .sluggie that is not loaded
# in the scene. Keyed by the file's version, so a changed or repaired file is
# read again; only the length is kept, not the parsed model.
_PARTNER_MODELS = {}


def _partner_model_length(path):
    """``ModelLength`` of the .sluggie at *path*, 0 when it is missing or unreadable."""
    try:
        key = (path, os.path.getmtime(path))
    except OSError:
        return 0
    if key not in _PARTNER_MODELS:
        for old in [k for k in _PARTNER_MODELS if k[0] == path]:
            del _PARTNER_MODELS[old]
        model, _error = _load_model(path, {})
        _PARTNER_MODELS[key] = int((model or {}).get("ModelLength") or 0)
    return _PARTNER_MODELS[key]


def _partner_on_disk(scope, low):
    """The .sluggie of *scope*'s partner on disk: its `_L_` model (*low*) or
    its main model, from the sibling folders, or None."""
    model_dir = os.path.dirname(os.path.abspath(scope.sluggie_path))
    parent = os.path.dirname(model_dir)
    paths = []
    try:
        names = sorted(os.listdir(parent))
    except OSError:
        return None
    for name in names:
        folder = os.path.join(parent, name)
        if folder == model_dir or not os.path.isdir(folder):
            continue
        if core.low_partner_matches(name, scope.folder) if low else core.low_partner_matches(scope.folder, name):
            try:
                paths += [os.path.join(folder, f) for f in sorted(os.listdir(folder))
                          if f.lower().endswith('.sluggie')]
            except OSError:
                continue
    return core.pick_partner(paths, scope.sluggie_path) if paths else None


def _scene_partner(scope, scopes, low):
    """*scope*'s partner among the scene's *scopes*, or None."""
    found = [other for other in scopes if other is not scope and other.armature is not None and other.sluggie_path
             and (core.low_partner_matches(other.folder, scope.folder) if low
                  else core.low_partner_matches(scope.folder, other.folder))]
    if len(found) > 1:
        path = core.pick_partner([other.sluggie_path for other in found], scope.sluggie_path)
        found = [other for other in found if other.sluggie_path == path]
    return found[0] if len(found) == 1 else None


def _player_memory_text(need, parts):
    level = core.player_heap_level(need)
    files = " + ".join(parts) + f" + {core.PLAYER_BLOCK_OVERHEAD} = {need:,} bytes"
    stock = core.player_heap_usable(0)
    if level is None:
        top = core.player_heap_usable(core.PLAYER_HEAP_MAX_KB)
        return (ERROR, "Too big for player memory", f"Over {core.format_heap_kb(core.PLAYER_HEAP_MAX_KB)}",
                f"This character needs about {files}: {need - top:,} bytes more than the largest player memory "
                f"(Player memory {core.format_heap_kb(core.PLAYER_HEAP_MAX_KB)}, {top:,} bytes), so the game "
                "crashes when it loads onto the field. Make the meshes or textures smaller. Export still works.")
    extra_kb, big = level
    name = core.format_heap_kb(extra_kb)
    detail = (f"This character needs about {files}; the stock player memory holds {stock:,}, so the game "
              f"crashes when it loads onto the field. Pick Player memory {name} or more "
              f"({core.player_heap_usable(extra_kb):,} bytes) in the SluggiesTools character grid.")
    if big:
        detail += (f" That level needs Dolphin with MEM2 at 128 MB: without the override (and on a real Wii) "
                   f"the game keeps +{core.PLAYER_HEAP_SAFE_KB} KB and crashes.")
    elif extra_kb > core.PLAYER_HEAP_SAFE_KB:
        detail += " That is past the stock-memory budget: a busy scene may run out of game memory."
    if extra_kb in core.EXPERIMENTAL_HEAP_LEVELS_KB:
        detail += " That level is experimental."
    return WARNING, f"Needs player memory {name}", f"Player memory {name}", detail


def check_player_memory(scopes):
    """Each character's High + Low + a bat or glove against the player heap
    levels (game_memory's rule, on the size estimates): the smallest level it
    needs, or too big above +PLAYER_HEAP_MAX_KB. Only told here: export
    never refuses an oversized model."""
    done = set()
    for scope in scopes:
        if scope.armature is None or scope.model is None or not scope.sluggie_path or scope.stadium \
                or id(scope) in done:
            continue
        low = core.is_low_folder(scope.folder)
        partner = _scene_partner(scope, scopes, not low)
        parts, sizes = {}, {}
        for role, other in (("Low" if low else "High", scope), ("High" if low else "Low", partner)):
            if other is not None:
                done.add(id(other))
                estimate = estimate_scope_size(other)
                if estimate is not None:
                    sizes[role] = sum(estimate)
                    parts[role] = f"{role} {sizes[role]:,} (estimate)"
        missing = "High" if low else "Low"
        if missing not in sizes:
            path = _partner_on_disk(scope, not low)
            length = _partner_model_length(path) if path else 0
            if not length:
                continue   # no partner: not a character (a bat, a glove, an object)
            sizes[missing] = length
            parts[missing] = f"{missing} {length:,} (its .sluggie, not loaded)"
        if "High" not in sizes or "Low" not in sizes:
            continue
        need = core.player_heap_need(sizes["High"], sizes["Low"])
        if core.player_heap_level(need) == (0, False):
            continue
        ordered = [parts["High"], parts["Low"], f"bat/glove {core.PLAYER_GEAR_ALLOWANCE:,} (the largest stock one)"]
        severity, text, label, detail = _player_memory_text(need, ordered)
        owner = partner if low and partner is not None else scope
        yield Finding("player_memory", severity, owner.name, text, detail,
                      action_id="show_name", action_args={"name": label, "icon": 'MEMORY'})


def run_checks(context, scopes):
    findings = []
    for scope in scopes:
        for check, _export in CHECKS:
            findings.extend(check(context, scope))
    findings.extend(check_low_high_bones(scopes))
    findings.extend(check_player_memory(scopes))
    findings.extend(check_stray_objects(context, scopes))
    return core.sort_findings(findings)


def export_errors(context, model, filepath, objects, reimport_textures):
    """Error messages of the checks the exporter runs on the selected model."""
    scope = export_scope(context, model, filepath, objects, reimport_textures)
    messages = []
    for check, on_export in CHECKS:
        if on_export:
            messages.extend(f.detail for f in check(context, scope) if f.severity == ERROR)
    return messages


# ---------------------------------------------------------------------------
# Size estimate
# ---------------------------------------------------------------------------

def _triangle_count(mesh):
    mesh.calc_loop_triangles()
    return len(mesh.loop_triangles)


def _custom_mesh_counts(obj):
    mesh = obj.data
    mesh.calc_loop_triangles()
    return core.MeshCounts(
        vertices=len(mesh.vertices), triangles=len(mesh.loop_triangles), uv_channels=2,
        color_channels=1 if len(mesh.color_attributes) else 0, has_normal_buffer=True,
        comp_count=3, comp_size=2,
    )


def estimate_scope_size(scope, objects=None):
    """(model bytes, texture bytes) of *scope*'s model as Blender holds it
    (or of *objects* only, the export selection), or None without a .sluggie."""
    model = scope.model
    if model is None:
        return None
    objects = scope.meshes if objects is None else objects
    mesh_counts, custom = {}, 0
    for obj in objects:
        if _is_custom(obj):
            custom += core.mesh_bytes(_custom_mesh_counts(obj))
            continue
        index = _submesh_index(scope, obj)
        if index is None:
            continue
        # The original and its `_edit` copy (or backups) both claim the
        # submesh: an `_edit` wins, else the first one.
        if index in mesh_counts and not obj.name.split('.')[0].endswith('_edit'):
            continue
        mesh_counts[index] = (len(obj.data.vertices), _triangle_count(obj.data))
    descriptors, tex_dir, owns = scope.texture_context()
    texture_sizes, new_textures = {}, []
    if owns and tex_dir:
        names = {d.get("TextureFileName") for d in descriptors or []}
        for name in names:
            size = ExportMode.png_dimensions(os.path.join(tex_dir, name or ""))
            if size:
                texture_sizes[name] = size
        seen = set()
        for obj in objects:
            for mat in _materials(obj):
                for node in ExportTextures._connected_image_texture_nodes(mat):
                    path = _image_path(node.image) if node.image is not None else ""
                    file_name = os.path.basename(path)
                    if not path or file_name in names or file_name in seen:
                        continue
                    size = _texture_size(path, node.image)
                    if size:
                        seen.add(file_name)
                        template = mat.get("TemplateTextureIndex", mat.get("TextureIndex", -1))
                        new_textures.append((size[0], size[1], int(template)))
    return core.estimate_size(model if owns else {**model, "TextureDescriptors": []},
                              mesh_counts, custom, texture_sizes, new_textures)


def export_size_line(context, model, filepath, objects):
    scope = export_scope(context, model, filepath, objects, True)
    sizes = estimate_scope_size(scope, scope.meshes)
    return core.size_line(*sizes) if sizes else None


# ---------------------------------------------------------------------------
# Fixes: fix_id -> function(context, **fix_args); raise ValueError on failure
# ---------------------------------------------------------------------------

def _object(name):
    obj = bpy.data.objects.get(name)
    if obj is None:
        raise ValueError(f"object {name} is gone")
    return obj


def _image(name):
    image = bpy.data.images.get(name)
    if image is None:
        raise ValueError(f"image {name} is gone")
    return image


_FIX_MODELS = {}


def _fix_model(path):
    model, error = _load_model(path, _FIX_MODELS)
    if model is None:
        raise ValueError(f".sluggie {error or 'missing'}")
    return model


def fix_object_mode(context):
    if context.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')


def fix_reparent(context, object, armature):
    obj, arm = _object(object), _object(armature)
    world = obj.matrix_world.copy()
    obj.parent = arm
    obj.parent_type = 'OBJECT'
    obj.matrix_world = world


def fix_armature_modifier(context, object, armature):
    SubmeshOps._ensure_armature_modifier(_object(object), _object(armature))


def fix_restore_mesh_props(context, object, sluggie, index):
    obj = _object(object)
    for prop, value in core.mesh_props_for_submesh(_fix_model(sluggie), index).items():
        if value is None:
            raise ValueError(f"submesh {index} has no {prop}")
        obj[prop] = value


def fix_restore_material_props(context, object, materials, sluggie):
    model = _fix_model(sluggie)
    for name in materials:
        mat = bpy.data.materials.get(name)
        if mat is None:
            raise ValueError(f"material {name} is gone")
        sid = mat.get("SurfaceId")
        index = core.donor_surface_submesh(sid)
        ds = core.display_state_for_surface(model, sid)
        if ds is None or index is None:
            raise ValueError(f"{name}: surface {sid} not in the .sluggie")
        if "TextureIndex" not in mat:
            mat["TextureIndex"] = ExportTextures._custom_submesh_template_texture_index(model, f"rigid:{sid}")
        wrap_s, wrap_t = core.wrap_modes_for_texture(model, index, mat["TextureIndex"])
        if "WrapS" not in mat:
            mat["WrapS"] = wrap_s
        if "WrapT" not in mat:
            mat["WrapT"] = wrap_t
        if "DisplayStateId" not in mat or "ShaderMode" not in mat:
            kept = {k: mat[k] for k in ("ShaderMode", "SpecularStrength") if k in mat}
            _set_surface_material_metadata(mat, ds)
            for key, value in kept.items():
                mat[key] = value


def fix_material_defaults(context, object, materials, armature, template):
    obj, arm = _object(object), _object(armature)
    for name in materials:
        mat = bpy.data.materials.get(name)
        if mat is None:
            raise ValueError(f"material {name} is gone")
        plan = SurfacePlans._new_surface_plan(context, arm, obj, template)
        if mat.users > 1:
            # Shared with another object: that one keeps the plain material.
            copy = mat.copy()
            for slot in obj.material_slots:
                if slot.material == mat:
                    slot.material = copy
            mat = copy
        SurfacePlans._apply_new_surface_plan(mat, plan)


def fix_save_image(context, image):
    img = _image(image)
    if not _image_path(img):
        raise ValueError(f"{image} has no file path")
    img.save()


def _safe_stem(name):
    stem = os.path.splitext(name)[0]
    return "".join(c if c.isalnum() or c in "-_." else "_" for c in stem) or "texture"


def fix_image_to_tex(context, image, tex_dir):
    """Save an image without a usable PNG file (generated, packed, not a
    PNG) as a PNG into tex/ and point it there. A packed image is saved
    too (unpacking would write its packed bytes, a JPEG under a .png name)
    and then unpacked onto that PNG. On a failure the image keeps its old
    path and format, and no half-written file stays in tex/."""
    img = _image(image)
    os.makedirs(tex_dir, exist_ok=True)
    file_name = core.free_file_name(_safe_stem(img.name) + ".png", os.listdir(tex_dir))
    path = os.path.join(tex_dir, file_name)
    old_path, old_format = img.filepath_raw, img.file_format
    try:
        img.filepath_raw = path
        img.file_format = 'PNG'
        img.save()
        if img.packed_file is not None:
            # Drop the packed bytes without writing them (every other unpack
            # method writes them over the PNG) and read the PNG back.
            img.unpack(method='REMOVE')
            img.reload()
    except BaseException:
        img.filepath_raw, img.file_format = old_path, old_format
        if os.path.isfile(path):
            os.remove(path)     # a free name: the file is this fix's own
        raise


def fix_copy_to_tex(context, image, tex_dir, reserved=()):
    img = _image(image)
    source = _image_path(img)
    if not os.path.isfile(source):
        raise ValueError(f"{source} not found")
    os.makedirs(tex_dir, exist_ok=True)
    planned = {}
    file_name = ExportTextures._plan_external_texture_copy(source, tex_dir, planned, tuple(reserved))
    target = os.path.join(tex_dir, file_name)
    if not os.path.isfile(target):
        # The planned source: another format's PNG conversion.
        shutil.copyfile(planned.get(file_name, source), target)
    img.filepath = target


def fix_one_bone(context, object, bone_id):
    obj = _object(object)
    for vg in list(obj.vertex_groups):
        if core.bone_id_from_name(vg.name) is not None:
            obj.vertex_groups.remove(vg)
    group = obj.vertex_groups.new(name=f"bone_{bone_id}")
    group.add(list(range(len(obj.data.vertices))), 1.0, 'REPLACE')


def fix_limit_weights(context, object):
    obj = _object(object)
    bone_groups = {g.index: g for g in obj.vertex_groups if core.bone_id_from_name(g.name) is not None}
    for vertex in obj.data.vertices:
        weights = {e.group: e.weight for e in vertex.groups if e.group in bone_groups and e.weight > 0}
        if len(weights) <= core.MAX_BONE_INFLUENCES:
            continue
        kept = core.limited_weights(weights)
        for group_index in weights:
            if group_index in kept:
                bone_groups[group_index].add([vertex.index], kept[group_index], 'REPLACE')
            else:
                bone_groups[group_index].remove([vertex.index])


def fix_remove_slots(context, object, slots):
    obj = _object(object)
    for index in sorted(set(slots), reverse=True):
        if index >= len(obj.material_slots):
            continue
        obj.active_material_index = index
        with context.temp_override(object=obj, active_object=obj):
            bpy.ops.object.material_slot_remove()


def fix_restore_skeleton(context, armature, sluggie):
    model = _fix_model(sluggie)
    fix_object_mode(context)
    restore_donor_bones(context, _object(armature), model.get("BoneHierarchy") or [], model.get("SkinData"))


def fix_renumber_bones(context, armature):
    HostBoneScene._renumber_added_bones(_object(armature))


def fix_reset_root_scale(context, armature):
    _object(armature)['RootBoneScale'] = [1.0, 1.0, 1.0]


def fix_bone_track(context, armature, bones):
    arm = _object(armature)
    for name in bones:
        bone = arm.data.bones.get(name)
        if bone is None:
            raise ValueError(f"bone {name} is gone")
        HostBoneScene._set_added_bone_track(arm, bone, True)


FIXES = {
    "object_mode": fix_object_mode,
    "reparent": fix_reparent,
    "armature_modifier": fix_armature_modifier,
    "restore_mesh_props": fix_restore_mesh_props,
    "restore_material_props": fix_restore_material_props,
    "material_defaults": fix_material_defaults,
    "save_image": fix_save_image,
    "image_to_tex": fix_image_to_tex,
    "copy_to_tex": fix_copy_to_tex,
    "one_bone": fix_one_bone,
    "limit_weights": fix_limit_weights,
    "remove_slots": fix_remove_slots,
    # Before renumbering: a restored original bone changes the donor count.
    "restore_skeleton": fix_restore_skeleton,
    "renumber_bones": fix_renumber_bones,
    "reset_root_scale": fix_reset_root_scale,
    "bone_track": fix_bone_track,
}
# Fixes affect each other (a mode switch first, renaming bones last), so
# they run in this order whatever order the findings were ticked in.
FIX_ORDER = list(FIXES)


def run_fixes(context, requests):
    """Run ``(fix_id, fix_args)`` pairs in FIX_ORDER; one call per distinct
    pair. Returns (requests fixed, requests failed, failure messages)."""
    _FIX_MODELS.clear()
    try:
        return _run_fixes(context, requests)
    finally:
        _FIX_MODELS.clear()     # the parsed models are not kept after the run


def _run_fixes(context, requests):
    # Any fix runs in Object Mode: the dialog's "Go to bones" enters Edit Mode
    # under it, where vertex group and bone writes fail or are overwritten.
    requests = list(requests)
    if requests and context.mode != 'OBJECT':
        try:
            fix_object_mode(context)
        except RuntimeError as exc:     # no fix can run safely then
            return 0, len(requests), [f"object mode: {exc}"]
    calls = {}
    for fix_id, args in requests:
        if fix_id == "remove_slots":
            # One call per object with every slot to remove: the slot numbers are those of check time, and
            # a second call would use them after the first one shifted the slots (and take a used material).
            key = json.dumps({"object": args["object"]})
        else:
            key = json.dumps(args, sort_keys=True)
        calls.setdefault((fix_id, key), []).append(args)
    fixed, failed, messages = 0, 0, []
    for (fix_id, _key), group in sorted(calls.items(), key=lambda item: FIX_ORDER.index(item[0][0])):
        arguments = group[0]
        if fix_id == "remove_slots":
            arguments = {"object": group[0]["object"],
                         "slots": sorted({slot for args in group for slot in args["slots"]})}
        try:
            FIXES[fix_id](context, **arguments)
        except Exception as exc:  # each fix reports its own failure, the run goes on
            failed += len(group)
            messages.append(f"{fix_id.replace('_', ' ')}: {exc}")
        else:
            fixed += len(group)
    return fixed, failed, messages
